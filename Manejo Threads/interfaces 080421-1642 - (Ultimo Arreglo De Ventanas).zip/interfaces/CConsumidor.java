package interfaces;

public class CConsumidor extends Thread {

	private CColaEntrada Cola1;
	private boolean Conexion; 
	public CMessage msg;
	public CIncomingMessage msginput;
	public CProtocolMessage DatosIH;
	public int flag = 0;
	public CBaseDatos BD;
	public CInicio Inicio;
	public CParseo Parseo;
	public CDatos Datos;
	
	public CConsumidor(CColaEntrada Cola11, CBaseDatos BD, CInicio Inicio) {
		Cola1 = Cola11;
		this.BD = BD;
		this.Inicio = Inicio;
		Parseo = new CParseo();
		Datos = new CDatos();
		msginput = null;
		DatosIH = null;
	}
	
	public void ModificarFlag(int alta) {
		flag = alta;
	}
	
	public int ObtenerFlag() {
		return flag;
	}
	
	public void Desconectar() {
		Conexion = false;
		Inicio.EscriboLog("Desactivando Consumidor De SMS");
		System.out.println("Consumidor : Comenzando Desconexi�n");
	}
	
	public void run() {
		Conexion = true;
//		int superid = 0, memIndexVar = 1;
//		Inicio.FinProcesoSMS();
		//boolean Conexion = false;
		//CIncomingMessage msg;
		//System.out.println("Tama�o Cola: "+Cola1.Tama�oCola());
		//System.out.println("Consumidor: Duermo Consumidor 30 Segundos...");
		//try { sleep(30000); } catch (Exception e) {}
		while (Conexion || Cola1.Tama�oCola()>0) {
		//while (corrida < 4) {
//			if (flag == 1) {
			if (Cola1.Tama�oCola()>0) {
//				msgprotocol = (CProtocolMessage) Cola1.UltimoCola();		
//				Saco el mensaje de la cola y lo imprimo en pantalla
				msg = Cola1.Sacar();
//				msg = Cola1.UltimoCola();
				if (msg.getMemIndex() != 0) {
					msginput = (CIncomingMessage) msg;
//					superid = msginput.getId();
//					memIndexVar = msginput.getMemIndex();		
					Inicio.ImprimirConsolaConsumidor(msginput.toString());
					Inicio.MensajeRecibido();
					if (Inicio.XMLin) { Inicio.CreoArchivoXML(msginput); }
					Inicio.EscriboLogDatosSMS(msginput);
					Datos.Limpiar();
					Datos = Parseo.Parsear(msginput, Datos);
					BD.AlmacenoSMSEntrantes(msginput, Datos);
//					Almaceno en Base Datos el SMS
					if (Datos.ObtenerTipoDato() == 1) {
						Inicio.ProcesarSMSTipo1(Datos);
//						int aux = BD.buscovuelo(Datos);
//						Inicio.ImprimirConsolaConsumidor("Usted Puede viajar en vuelo nro: " + aux);
//						Pedido de Vuelo con fecha unica de ida								
					}
					else if (Datos.ObtenerTipoDato() == 2) {
						Inicio.ProcesarSMSTipo2(Datos);
//						Pedido de Vuelo con fecha de ida y de retorno (2 vuelos)										
					}
					else if (Datos.ObtenerTipoDato() == 4) {
						Inicio.ProcesarSMSTipo4(Datos);
//						Generar SMS Ayuda Pedido Vuelos (Palabra IguazuAir)
					}
					else if (Datos.ObtenerTipoDato() == 5) {
						Inicio.ProcesarSMSTipo5(Datos);
//						Generar SMS Final Confirmaci�n Vuelo
					}
					else if (Datos.ObtenerTipoDato() == 6) {
//						Inicio.ProcesarSMSTipo6(Datos);
//						Generar SMS Mas Vuelos Pedidos
					}
					else if (Datos.ObtenerTipoDato() == 7) {
						Inicio.ProcesarSMSTipo7(Datos);
//						Generar SMS Estado Vuelo
					}
					else if (Datos.ObtenerTipoDato() == 8) {
						Inicio.ProcesarSMSTipo8(Datos);
//						Generar SMS Ayuda Pedido Vuelos (Mal Envio de SMS de Pedido de Vuelo)
					}
					else if (Datos.ObtenerTipoDato() == 9) {
						Inicio.ProcesarSMSTipo9(Datos);
//						Generar SMS Ayuda Confirmaci�n Vuelos (Mal Envio de SMS de Confirmaci�n de Vuelo)
					}
					else if (Datos.ObtenerTipoDato() == 10) {
						Inicio.ProcesarSMSTipo10(Datos);
//						Generar SMS Ayuda de Pedido de Estados De Vuelos
					}
					else if (Datos.ObtenerTipoDato() == 3) { 
						Inicio.ProcesarSMSTipo3(Datos);
//						Inicio.EnviarAyudaTipo2(Datos);
//						Generar SMS Ayuda Si Es Necesario (Si el SMS no es basura)							
					}
					//Inicio.FinProcesoSMS();
				}
				else {
//					escribe mensaje de protocolo en LOG
					DatosIH = (CProtocolMessage) msg;
//					superid = DatosIH.getId();
//					memIndexVar = DatosIH.getMemIndex();
					Inicio.ImprimirConsolaConsumidor(DatosIH.toString());
					Inicio.CreoArchivoXML(DatosIH);
					if (Inicio.InfoProtocolo) { Inicio.EscriboLog(DatosIH); }								// InfoProtocolo Me Indica Si El Usuario Quiere Almacenar Datos De Protocolo En El Log
					if (!DatosIH.getConexion()) {
						if (!DatosIH.getText().contains("Dispositivo GSM Desconectado")) {
							Conexion = false;
							Inicio.DesactivoServidor(DatosIH.getText());
						}
						else { Inicio.V1.jTextField7.setText("Desconectado"); }
					}
					else {
						if (DatosIH.getText().contains("Dispositivo GSM Conectado")) { Inicio.CelularConectado(); }
						if (DatosIH.getSe�al() != 0) {Inicio.ActualizoDatosTC(DatosIH.getSe�al(),DatosIH.getBateria());}
					}
				}
//				Inicio.ImprimirConsolaConsumidor(" Se sac� un SMS de la cola de entrada");
				Inicio.ImprimirConsolaConsumidor(" Tama�o De La Cola De Entrada: " + Cola1.Tama�oCola());
				Inicio.ImprimirConsolaConsumidor(" Se Detiene El Consumidor Por " + Inicio.TiempoConsu + " Segundos");
				try { sleep(Inicio.TiempoConsu*1000); } catch (Exception e) {}
				Inicio.LimpiarConsolaConsumidor();
			}
			else {
				Inicio.ImprimirConsolaConsumidor(" No Hay Mensajes SMS En La Cola De Entrada");
				Inicio.ImprimirConsolaConsumidor(" Se Detiene El Consumidor Por " + Inicio.TiempoConsu + " Segundos");
				try { sleep(Inicio.TiempoConsu*2000); } catch (Exception e) {}
				Inicio.LimpiarConsolaConsumidor();
			}
		}
		Inicio.FinalizaConsumidor();
		System.out.println("Finaliza Ejecuci�n Consumidor");
	}
}
	

