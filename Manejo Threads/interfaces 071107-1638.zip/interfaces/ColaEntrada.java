package interfaces;

import java.util.*;

public class ColaEntrada {
	
	ColaEntrada(){};
	LinkedList<CIncomingMessage> ColaEnt = new LinkedList<CIncomingMessage>();
	public CIncomingMessage Temporal;
	
	public void Agregar(CIncomingMessage Mensaje)
		{
		ColaEnt.add(Mensaje);
		}
	
//	public void AgregarPro(CProtocolMessage Info)
//		{
//		ColaEnt.add(Info);
//		}
		
	public CIncomingMessage Obtener(int i)
	{
		Temporal = ColaEnt.get(i);
		return Temporal;
	}
	
	public CIncomingMessage Sacar()
	{
		Temporal = ColaEnt.remove();
		return Temporal;
	}
	
	public void Limpiar()
	{
		ColaEnt.clear();	
	}
	
	public int Tama�oCola()
	{
		return ColaEnt.size();
	}

	public CIncomingMessage UltimoCola()
	{
		return ColaEnt.getLast();
	}
	
	public boolean EstaVacio()
	{
		return ColaEnt.isEmpty();
	}
}
