package interfaces;

public class Exe2 {

	public Exe2(){};
	
	public void Conexion(InterfazPreFinal V1) {

		String Temporal;
		ColaEntrada Cola1 = new ColaEntrada();
		Temporal = "Cola de Entrada: Activado\n";
		ColaSalida  Cola2 = new ColaSalida();
		Temporal = Temporal + "Cola de Salida : Activado\n";	
		InterfazHWVer3 Maurix = new InterfazHWVer3(Cola1, Cola2);
		Temporal = Temporal + "Interfaz HW : Activado\n";
		//Consumidor Consu = new Consumidor(Cola1);
		//Temporal = Temporal + "Consumidor : Activado\n";
		Productor Prod = new Productor(Cola2, V1);
		V1.AjustoProd(Prod);
		Temporal = Temporal + "Productor : Activado\n";
		//V1.FijoTexto3(Temporal);
		Maurix.start();
		Temporal = "Interfaz de Hardware Con Cel Iniciado\n";
		//Consu.start();
		//Temporal = Temporal + "Consumidor Mensajes Iniciado\n";
		//Prod.start();
		//Temporal = Temporal + "Productor Mensajes Iniciado\n";
		V1.FijoTexto1(Temporal);
		
	}
}	


