package interfaces;

//import CMessage;
//import CService;

public class Productor {
	
	private ColaSalida Cola2;
	public int idsal = 100;
	public CInicio Inicio;
	
	public Productor (ColaSalida Cola11, CInicio Inicio) {
		Cola2 = Cola11;
		this.Inicio = Inicio;
	}

	public void EnvioSMS(String Envio, String Cel) {
//		System.out.println("Productor: Duermo Productor 23 Segundos...");
//		try { sleep(23000); } catch (Exception e) {}
//		String Envio = "Mauro, al final te quedas para la despedida del gordo? Saludos.";
//		String NroCel = "+";
//		System.out.println("Cel: " + Cel);
//		Nrocel.concat(Cel);
//		NroCel = "+" + Cel;
//		System.out.println("NroCel: " + NroCel);
		COutgoingMessage msgsal = new COutgoingMessage(Cel, Envio, idsal);
		Inicio.ImprimirConsolaProductor("Envio Mensaje: \n" + Envio);
		Inicio.ImprimirConsolaProductor("Envio Mensaje a: " + Cel);
//		msgsal.setMessageEncoding(CMessage.MESSAGE_ENCODING_UNICODE);
		msgsal.setMessageEncoding(CMessage.MESSAGE_ENCODING_7BIT);
		Inicio.ImprimirConsolaProductor(msgsal.toString());
		Cola2.Agregar(msgsal);
		Inicio.ImprimirConsolaProductor("Productor: Mande Mensaje a la Cola...");
		Inicio.ImprimirConsolaProductor("Productor: Tama�o Cola Salida: "+Cola2.Tama�oCola());
	}
	
	
	//public static void main(String[] args) {
	//}

}
