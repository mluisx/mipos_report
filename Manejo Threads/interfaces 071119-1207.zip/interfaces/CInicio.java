package interfaces;

public class CInicio {

	public CInicio(InterfazPreFinal V1){
		
		this.V1 = V1;
		
	};
	
	public InterfazPreFinal V1;
	public Consumidor Consu;
	public Productor Prod;
	public BaseDatos BD;
	
	public void Conexion() {

		String Temporal;
		ColaEntrada Cola1 = new ColaEntrada();
		Temporal = "Cola de Entrada: Activado\n";
		ColaSalida  Cola2 = new ColaSalida();
		Temporal = Temporal + "Cola de Salida : Activado\n";	
		InterfazHWVer3 Maurix = new InterfazHWVer3(Cola1, Cola2);
		Temporal = Temporal + "Interfaz HW : Activado\n";
		this.BD = V1.BD;
		Consumidor Consu = new Consumidor(Cola1,BD);
		AjustoConsu(Consu);
		Temporal = Temporal + "Consumidor : Activado\n";
		Productor Prod = new Productor(Cola2, this);
		V1.AjustoProd(Prod);
		Temporal = Temporal + "Productor : Activado";
		FijoTexto3(Temporal);
		Maurix.start();
		Temporal = "Interfaz de Hardware Con Cel Iniciado";
		Consu.start();
		//Temporal = Temporal + "Consumidor Mensajes Iniciado\n";
		//Prod.start();
		//Temporal = Temporal + "Productor Mensajes Iniciado\n";
		FijoTexto1(Temporal);
		
	}
	
	public void AjustoConsu(Consumidor Consu){this.Consu = Consu;}
	public void AjustoProd(Productor Prod){this.Prod = Prod;}

	public void ActivoConsumidor() {
		int i = Consu.ObtenerFlag();
		if (i == 0) { 
			Consu.ModificarFlag(1);
			System.out.println("Consumidor Activado");
			V1.jRadioButton1.setSelected(true);
		}
		else { 
			Consu.ModificarFlag(0);
			System.out.println("Consumidor Desactivado");
			V1.jRadioButton1.setSelected(false);
		}
	}
	
    public void FijoTexto1(String Texto){
    	//jTextArea1.setText(Texto);
    	String Temp = V1.jTextArea1.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	V1.jTextArea1.setText(Temp);
    }
    
    public void FijoTexto2(String Texto){
    	String Temp = V1.jTextArea2.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	V1.jTextArea2.setText(Temp);
    }
    
    public void FijoTexto3(String Texto){
    	//jTextArea3.setText(Texto);
    	String Temp = V1.jTextArea3.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	V1.jTextArea3.setText(Temp);
    }
    
    public void HabilitoConexion(){
    	V1.jMenuItem2.setEnabled(false);
    	V1.jMenuItem1.setEnabled(true);	
    }
	
	public void EnviarMensaje() {
    	String Envio = V1.jTextArea4.getText();
    	String Cel = V1.jTextField1.getText();
    	Prod.EnvioSMS(Envio,Cel);
	}
}	




