package interfaces;

public class CParseo {
	
	String Texto;
	String MiniTexto;
	int Index,Index2;
	
	public CParseo() {
		Index = 0;
	};

	public void Parsear(CMessage msg) {
		Texto = msg.getText().trim();
		while (Index < Texto.length()) {
			Index2 = Texto.indexOf(" ",Index) - 1;
			MiniTexto = MiniTexto + Index + Texto.substring(Index, Index2);
			Index = Index2 + 2;
		}
	}
}
