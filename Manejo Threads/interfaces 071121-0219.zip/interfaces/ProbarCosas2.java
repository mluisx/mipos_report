package interfaces;

public class ProbarCosas2 {

	public static void main(String[] args) {

		String Texto, FechaIdaDia = "", FechaIdaMes = "", FechaIdaAnio = "";
		String MiniTexto = "";
		String MiniTexto2 = "";
		String TipoTicket = "", CiudadOrigen = "", CiudadDestino = "", FechaIda = "";
		int Index1 = 0,Index2 = 1;
		int flag1 = 0, flag2 = 0, flag3 = 0;
		
		Texto = "Vuelo desde Buenos Aires a Posadas el 4 de Noviembre del 2007";
		Texto = Texto + " ";
		Texto = Texto.toUpperCase();
		System.out.println("Mensaje : " + Texto);
		while (Index1 < Texto.length()) {
			Index2 = Texto.indexOf(" ",Index1);
			//System.out.println("Index1: " + Index1);
			//System.out.println("Index2: " + Index2);
			if (Index2 > 0) {
				MiniTexto = MiniTexto + "#" + Texto.substring(Index1, Index2);
				MiniTexto2 = Texto.substring(Index1, Index2);
				//Comienzo Parseo
				if (MiniTexto2.compareTo("VUELO") == 0) {TipoTicket = MiniTexto2;}
				else if (MiniTexto2.compareTo("DESDE") == 0) {flag1 = 1;}
				else if (MiniTexto2.compareTo("A") == 0) {flag2 = 1; flag1 = 0;}
				else if (MiniTexto2.compareTo("EL") == 0) {flag2 = 0; flag3 = 1;}
				else if (flag1 == 1) {CiudadOrigen = CiudadOrigen + MiniTexto2 + " ";}
				else if (flag2 == 1) {CiudadDestino = CiudadDestino + MiniTexto2 + " ";}
				else if (flag3 == 1) {FechaIda = FechaIda + MiniTexto2 + " ";}
				//Fin Parseo
				Index1 = Index2 + 1;
			}
			else {
				Index1 = Texto.length();
			}
		}
		
		Index1 = 0;
		Index2 = 1;
		MiniTexto = "";
		MiniTexto2 = "";
		flag1 = 1;
		flag2 = 0;
		flag3 = 0;
		
		while (Index1 < FechaIda.length()) {
			Index2 = FechaIda.indexOf(" ",Index1);
			if (Index2 > 0) {
				MiniTexto = MiniTexto + "#" + FechaIda.substring(Index1, Index2);
				MiniTexto2 = FechaIda.substring(Index1, Index2);
				//Comienzo Parseo
				if (flag1 == 1) {FechaIdaDia = MiniTexto2; flag1 = 0; flag2 = 1;}
				else if (flag2 == 1 && MiniTexto2.compareTo("DE") != 0) {FechaIdaMes = MiniTexto2; flag2 = 0; flag3 = 1;}
				else if (flag3 == 1 && MiniTexto2.compareTo("DEL") != 0) {FechaIdaAnio = MiniTexto2; flag3 = 0;}
				//Fin Parseo
				Index1 = Index2 + 1;
			}
			else {
				Index1 = FechaIda.length();
			}
		}
		
		CiudadOrigen = CiudadOrigen.trim();
		CiudadDestino = CiudadDestino.trim();
		FechaIda = FechaIda.trim();
		System.out.println("Mensaje Parseado Completo : " + MiniTexto);
		System.out.println("Mensaje Parseado TipoTicket : " + TipoTicket);
		System.out.println("Mensaje Parseado CiudadOrigen : " + CiudadOrigen);
		System.out.println("Mensaje Parseado CiudadDestino : " + CiudadDestino);
		System.out.println("Mensaje Parseado FechaIda : " + FechaIda);
		System.out.println("Mensaje Parseado Dia : " + FechaIdaDia);
		System.out.println("Mensaje Parseado Mes : " + FechaIdaMes);
		System.out.println("Mensaje Parseado A�o : " + FechaIdaAnio);
	}
}
