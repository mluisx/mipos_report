package interfaces;

public class Consumidor extends Thread {

	private ColaEntrada Cola1;
	public CMessage msg;
	public CIncomingMessage msginput;
	public CProtocolMessage msgprotocol;
	public int flag = 0;
	public CBaseDatos BD;
	public CInicio Inicio;
	public CParseo Parseo;
	public CDatos Datos;
	
	public Consumidor (ColaEntrada Cola11, CBaseDatos BD, CInicio Inicio) {
		Cola1 = Cola11;
		this.BD = BD;
		this.Inicio = Inicio;
		Parseo = new CParseo();
		Datos = new CDatos();
		msginput = null;
		msgprotocol = null;
	}
	
	public void ModificarFlag (int alta) {
		flag = alta;
	}
	
	public int ObtenerFlag () {
		return flag;
	}
	
	public void run(){
		
		int corrida = 1, superid = 0, memIndexVar = 1;
		//boolean Conexion = false;
		//CIncomingMessage msg;
		//System.out.println("Tama�o Cola: "+Cola1.Tama�oCola());
		//System.out.println("Consumidor: Duermo Consumidor 30 Segundos...");
		//try { sleep(30000); } catch (Exception e) {}
		while (corrida < 250) {
		//while (corrida < 4) {
			if (flag == 1) {
				if (Cola1.Tama�oCola()>0) {
// 					Saco el mensaje de la cola y lo imprimo en pantalla
					for (int i = 1; i < 2 ; i++){
						msg = Cola1.Sacar();
						if (msg.getMemIndex() != 0) {
							msginput = (CIncomingMessage) msg;
							superid = msginput.getId();
							memIndexVar = msginput.getMemIndex();		
							Inicio.ImprimirConsolaConsumidor("Consumidor: ID SMS: "+superid);
							Inicio.ImprimirConsolaConsumidor("Consumidor: MEM INDEX: "+memIndexVar);
							Inicio.ImprimirConsolaConsumidor(msginput.toString());
							if (msginput.getText().contains("Vuelo")){
								Inicio.ImprimirConsolaConsumidor("Ringgggggggg...Alarma...!!!");
//								int aux = BD.buscodato("Maurix");
								Datos.Limpiar();
								Datos = Parseo.Parsear(msginput, Datos);
								if (Datos.ObtenerTipoDato() <= 2) { Inicio.ProcesarSMS(Datos); }
								int aux = BD.buscovuelo(Datos);
								Inicio.ImprimirConsolaConsumidor("Usted Puede viajar en vuelo nro: " + aux);							
//								Mandar Mensaje Con Respuesta
							}
						}
						else {
							msgprotocol = (CProtocolMessage) msg;
							superid = msgprotocol.getId();
							memIndexVar = msgprotocol.getMemIndex();		
							Inicio.ImprimirConsolaConsumidor("Consumidor: ID SMS: "+superid);
							Inicio.ImprimirConsolaConsumidor("Consumidor: MEM INDEX: "+memIndexVar);
							Inicio.ImprimirConsolaConsumidor(msgprotocol.toString());
						}
						Inicio.ImprimirConsolaConsumidor("Consumidor: Saque un mensaje de la cola");
						Inicio.ImprimirConsolaConsumidor("Consumidor: Tama�o Cola: " + Cola1.Tama�oCola());
					}
				}
			}
			Inicio.ImprimirConsolaConsumidor("Consumidor: Duermo Consumidor 10 Segundos...");
			try { sleep(10000); } catch (Exception e) {}
			corrida++;
		}
		Inicio.ImprimirConsolaConsumidor("Termina Consumidor");
	}
}
	

