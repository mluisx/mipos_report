package interfaces;

public class CParseo {
	
	String Texto;
	String MiniTexto, MiniTexto2, TipoTicket, CiudadOrigen, CiudadDestino, FechaIda, FechaRetorno;
	int Index1, Index2;
	int flag1, flag2, flag3, flag4, flag5;
	public static String FechaDia = "", FechaMes = "", FechaAnio = "";
	
	public CParseo() {
		Index1 = 0;
		Index2 = 1;		
		flag1 = flag2 = flag3 = flag4 = flag5 = 0;
		MiniTexto = MiniTexto2 = TipoTicket = CiudadOrigen = CiudadDestino = FechaIda = FechaRetorno = "";
	};

	public String ParsearFecha(String Fecha, int tipofecha) {
		
		int Index1 = 0, Index2 = 1, Index3 = 0;
		String MiniTexto = "", MiniTexto2 = "";
		int flag1 = 1, flag2 = 0, flag3 = 0;
		String Simbolo = "", Anio = "2007";
		
		if (Fecha.contains("/") || Fecha.contains("-") || Fecha.contains("\\") || Fecha.contains("_")) {
			
			if (Fecha.contains("200")) {
				Index3 = Fecha.lastIndexOf("200") - 1;
				Simbolo = Fecha.substring(Index3, Index3+1);
				Fecha = Fecha.substring(0, Index3+5);
				//System.out.println("Simbolo : " + Simbolo);
			}
			else {
				Index3 = Fecha.lastIndexOf("07");
				if (Index3 == -1 || Index3 <= 4) {
					Index3 = Fecha.lastIndexOf("08");
					Anio = "2008";
				}
				Index3--;
				Simbolo = Fecha.substring(Index3, Index3+1);
				Fecha = Fecha.substring(0, Index3+1);
				Fecha = Fecha.concat(Anio);
//				System.out.println("Simbolo : " + Simbolo);
			}

			Fecha = Fecha.concat(Simbolo);
			
			for (int i = 1 ; i<=3 ; i++) {
				Index2 = Fecha.indexOf(Simbolo,Index1);
				//System.out.println("Index2 : " + Index2 + "FechaIDA : " + FechaIda);
				MiniTexto = MiniTexto + "#" + Fecha.substring(Index1, Index2);
				MiniTexto2 = Fecha.substring(Index1, Index2);
				//Comienzo Parseo
				if (i == 1) {FechaDia = MiniTexto2;}
				else if (i == 2) {FechaMes = MiniTexto2;}
				else if (i == 3) {FechaAnio = MiniTexto2;}
				//Fin Parseo
				Index1 = Index2 + 1;
			}
		}
		else {
			while (Index1 < Fecha.length()) {
				Index2 = Fecha.indexOf(" ",Index1);
				if (Index2 > 0) {
					MiniTexto = MiniTexto + "#" + Fecha.substring(Index1, Index2);
					MiniTexto2 = Fecha.substring(Index1, Index2);
					//Comienzo Parseo
					if (flag1 == 1) {FechaDia = MiniTexto2; flag1 = 0; flag2 = 1;}
					else if (flag2 == 1 && MiniTexto2.compareTo("DE") != 0) {FechaMes = MiniTexto2; flag2 = 0; flag3 = 1;}
					else if (flag3 == 1 && MiniTexto2.compareTo("DEL") != 0) {FechaAnio = MiniTexto2; flag3 = 0;}
					//Fin Parseo
					Index1 = Index2 + 1;
				}
				else {
					Index1 = Fecha.length();
				}
			}
		}
/*		if (tipofecha == 0) {
			System.out.println("Mensaje Parseado Ida Dia : " + FechaDia);
			System.out.println("Mensaje Parseado Ida Mes : " + FechaMes);
			System.out.println("Mensaje Parseado Ida A�o : " + FechaAnio);
		}
		if (tipofecha == 1) {
			System.out.println("Mensaje Parseado Vuelta Dia : " + FechaDia);
			System.out.println("Mensaje Parseado Vuelta Mes : " + FechaMes);
			System.out.println("Mensaje Parseado Vuelta A�o : " + FechaAnio);
			}
*///	Fecha = Fecha.substring(0, Fecha.length()-1);
		Fecha = "";
		if (FechaDia.length()<2) { Fecha = "0" + FechaDia; }
		else { Fecha = FechaDia; }
		if (FechaMes.length()<2) { Fecha = Fecha + "/0" + FechaMes + "/"; }
		else { Fecha = Fecha + "/" + FechaMes + "/"; }
		Fecha = Fecha.concat(Anio);
		return Fecha;
	}

	public CDatos Parsear(CIncomingMessage msg, CDatos Datos) {

		Datos.FijoNroCelOrigen(msg.getOriginator());
		Texto = msg.getText().trim();
//		Texto = "Vuelo de Posadas a Buenos Aires fecha de ida 10/12/2007 fecha de retorno 10/1/07- Maurix";
		Texto = Texto + " ";
		Texto = Texto.toUpperCase();
		System.out.println("Mensaje : " + Texto);
		
		while (Index1 < Texto.length()) {
			Index2 = Texto.indexOf(" ",Index1);
			//System.out.println("Index1: " + Index1);
			//System.out.println("Index2: " + Index2);
			if (Index2 > 0 && flag5 == 0) {
				MiniTexto = MiniTexto + "#" + Texto.substring(Index1, Index2);
				MiniTexto2 = Texto.substring(Index1, Index2);
				//Comienzo Parseo
				if (MiniTexto2.compareTo("VUELO") == 0) {TipoTicket = MiniTexto2;}
				else if (MiniTexto2.compareTo("COLECTIVO") == 0) {TipoTicket = MiniTexto2;}
				else if (MiniTexto2.compareTo("DESDE") == 0 || MiniTexto2.compareTo("ORIGEN") == 0 || (MiniTexto2.compareTo("DE") == 0 && flag3 == 0)) {flag1 = 1;}
				else if (MiniTexto2.compareTo("A") == 0 || MiniTexto2.compareTo("DESTINO") == 0 || MiniTexto2.compareTo("HACIA") == 0) {flag2 = 1; flag1 = 0;}
				else if ((MiniTexto2.compareTo("EL") == 0) || (MiniTexto2.compareTo("FECHA") == 0) || (MiniTexto2.compareTo("DE") == 0 && flag3 == 1) || 
						(MiniTexto2.compareTo("IDA") == 0) || (MiniTexto2.compareTo("Y") == 0) || (MiniTexto2.compareTo("RETORNO") == 0)) {flag2 = 0; flag3 = 1;}
				else if (flag1 == 1) {CiudadOrigen = CiudadOrigen + MiniTexto2 + " ";}
				else if (flag2 == 1) {CiudadDestino = CiudadDestino + MiniTexto2 + " ";}
				else if (flag3 == 1 && flag4 == 0) {FechaIda = FechaIda + MiniTexto2 + " "; flag4 = 1;}
				else if (flag4 == 1) {FechaRetorno = FechaRetorno + MiniTexto2 + " "; flag5 = 1;}
				//Fin Parseo
				Index1 = Index2 + 1;
			}
			else {
				Index1 = Texto.length();
			}
		}
		
		if (!TipoTicket.isEmpty() && !CiudadOrigen.isEmpty() && !CiudadDestino.isEmpty() && !FechaIda.isEmpty()) {
			if (FechaRetorno.isEmpty()) {Datos.FijoTipoDato(1);}
			else {Datos.FijoTipoDato(2);}
		}
		else { Datos.FijoTipoDato(3); }
		
		if (Datos.ObtenerTipoDato() == 1 || Datos.ObtenerTipoDato() == 2) {
			Datos.FijoTipoTicket(TipoTicket);
			CiudadOrigen = CiudadOrigen.trim();
			Datos.FijoCiudadOrigen(CiudadOrigen);
			CiudadDestino = CiudadDestino.trim();
			Datos.FijoCiudadDestino(CiudadDestino);
			FechaIda = FechaIda.trim();
			FechaIda = ParsearFecha(FechaIda,0);
			Datos.FijoFechaIda(FechaIda);
		}

		//System.out.println("Mensaje Parseado Completo : " + MiniTexto);
		System.out.println("Mensaje Parseado TipoTicket : " + Datos.ObtenerTipoTicket());
		System.out.println("Mensaje Parseado CiudadOrigen : " + Datos.ObtenerCiudadOrigen());
		System.out.println("Mensaje Parseado CiudadDestino : " + Datos.ObtenerCiudadDestino());
		System.out.println("Mensaje Parseado FechaIda : " + Datos.ObtenerFechaIda());
		
		//if (!FechaRetorno.isEmpty()) {System.out.println("Mensaje Parseado FechaRetorno : " + FechaRetorno);}
        
//		FechaIda = ParsearFecha(FechaIda,0);
		//System.out.println("Mensaje Parseado Ida Dia : " + FechaDia);
		//System.out.println("Mensaje Parseado Ida Mes : " + FechaMes);
		//System.out.println("Mensaje Parseado Ida A�o : " + FechaAnio);
		//System.out.println("Mensaje Parseado Ida FechaIDA : " + FechaIda);
        if (Datos.ObtenerTipoDato() == 2) {
    		FechaRetorno = FechaRetorno.trim();
        	FechaRetorno = ParsearFecha(FechaRetorno,1);
			Datos.FijoFechaRetorno(FechaRetorno);
        	//System.out.println("Mensaje Parseado Vuelta Dia : " + FechaDia);
        	//System.out.println("Mensaje Parseado Vuelta Mes : " + FechaMes);
        	//System.out.println("Mensaje Parseado Vuelta A�o : " + FechaAnio);
        	System.out.println("Mensaje Parseado Ida FechaRETORNO : " + Datos.ObtenerFechaRetorno());
        }
        
        if (Datos.ObtenerTipoDato() == 3) {
        	System.out.println("Faltan Datos Necesarios Para Realizar la Busqueda");
        }
        
        return Datos;
	}
}
