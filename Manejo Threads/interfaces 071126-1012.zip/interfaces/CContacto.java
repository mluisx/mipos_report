package interfaces;

public class CContacto {

	public String Nombre;
	public String CodigoArea;
	public String NumeroCel;
	
	public CContacto(String Nombre, String CodigoArea, String NumeroCel) {
		
		this.Nombre = Nombre;
		this.CodigoArea = CodigoArea;
		this.NumeroCel = NumeroCel;

	}
	
	public String ObtenerNombre() {return Nombre;}
	public String ObtenerCodigoArea() {return CodigoArea;}
	public String ObtenerNumeroCel() {return NumeroCel;}

}
