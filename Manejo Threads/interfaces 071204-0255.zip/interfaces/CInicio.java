package interfaces;

import java.util.LinkedList;

public class CInicio {

	public CInicio(InterfazGrafica V1){
		
		this.V1 = V1;
		ListaContactos = new LinkedList<CContacto>();
		BD = V1.BD;
		Cola1 = new ColaEntrada();
		Cola2 = new ColaSalida();
		Maurix = new InterfazHard(Cola1, Cola2);
		Consu = new Consumidor(Cola1,BD,this);
		Prod = new Productor(Cola2, this);
	
	};
	
	public InterfazGrafica V1;
	public Consumidor Consu;
	public Productor Prod;
	public CBaseDatos BD;
	public ColaEntrada Cola1;
	public ColaSalida  Cola2;
	public LinkedList<CContacto> ListaContactos;
	public CContacto Contacto;
	public InterfazHard Maurix;
	
	public void Conexion() {
		FijoTexto3("Cola de Entrada: Activado");
		FijoTexto3("Cola de Salida : Activado");
		FijoTexto3("Interfaz HW : Activado");
		FijoTexto3("Consumidor : Activado");
		FijoTexto3("Productor : Activado");
		Maurix.start();
		Consu.start();
		FijoTexto1("Interfaz de Hardware Con Cel Iniciado");		
	}
	
	public void Desconexion(){
		Maurix.Desconectar();
	}
	
//	public void AjustoConsu(Consumidor Consu){this.Consu = Consu;}
//	public void AjustoProd(Productor Prod){this.Prod = Prod;}

	public void ActivoConsumidor() {
		int i = Consu.ObtenerFlag();
		if (i == 0) { 
			Consu.ModificarFlag(1);
			System.out.println("Consumidor Activado");
			V1.jRadioButton1.setSelected(true);
		}
		else { 
			Consu.ModificarFlag(0);
			System.out.println("Consumidor Desactivado");
			V1.jRadioButton1.setSelected(false);
		}
	}
	
    public void FijoTexto1(String Texto){
    	String Temp = V1.jTextArea1.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	V1.jTextArea1.setText(Temp);
    }
    
    public void FijoTexto2(String Texto){
    	String Temp = V1.jTextArea2.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	V1.jTextArea2.setText(Temp);
    }
    
    public void FijoTexto3(String Texto){
    	String Temp = V1.jTextArea3.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	V1.jTextArea3.setText(Temp);
    }
    
    public void HabilitoConexion(){
    	V1.jMenuItem2.setEnabled(false);
    	V1.jMenuItem1.setEnabled(true);	
    }
	
	public void EnviarMensaje(int indice[]) {
		String Envio = V1.jTextArea4.getText();
		for (int i=0;i<indice.length;i++) {
			Contacto = ListaContactos.get(indice[i]);
			String Cel = Contacto.ObtenerCodigoArea() + Contacto.ObtenerNumeroCel();
			System.out.println("Numero a Enviar : " + Cel);
			Cel = "+" + Cel;
			Prod.EnvioSMS(Envio,Cel);
		}
	}
	
	public void ProcesarSMS(CDatos Datos) {
		String Envio, Cel;
		Cel = Datos.ObtenerNroCelOrigen();
		System.out.println("NUMERO DE CEL DE PERSONA QUE HIZO PEDIDO: +" + Cel);
		Envio = BD.BuscoVuelo(Datos);
		System.out.println("Envio Al Que Hizo Pedido: " + Envio);
//		Prod.EnvioSMS(Envio,Cel);
	}
	
	public void EnviarAyudaTipo1(CDatos Datos) {
		String Envio, Cel;
		Cel = Datos.ObtenerNroCelOrigen();
		System.out.println("NUMERO DE CEL DE PERSONA QUE HIZO PEDIDO ERRONEO: +" + Cel);
		Envio = "Enviar SMS de la sgte forma: \" Vuelo NroVuelo CiudadOrigen CiudadDestino Fecha \" - Para Reservar Envie \" Reservar Vuelo NroVuelo \"";
		System.out.println("Envio Al Que Hizo Pedido: " + Envio);
//		Prod.EnvioSMS(Envio,Cel);
	}
	
	public void IngresoContacto(String Nombre, String CodigoArea, String NumeroCel, javax.swing.DefaultListModel SModel) {
		Contacto = new CContacto(Nombre, CodigoArea, NumeroCel);
		ListaContactos.add(Contacto);
		String Agrego = Contacto.ObtenerNombre() + " : " + Contacto.ObtenerCodigoArea() + Contacto.ObtenerNumeroCel();
	    SModel.addElement(Agrego);
    }

	public void BorrarContacto(int indice[], javax.swing.DefaultListModel SModel) {
		for (int i=0;i<indice.length;i++) {
			System.out.println("Indice: " + indice[i]);
			ListaContactos.remove(indice[i]-i);
			SModel.remove(indice[i]-i);
		}
	}
	
	public void ImprimirConsolaConsumidor(String Texto) {
		String TextoFull;
		TextoFull = V1.jTextArea6.getText();
    	if (TextoFull.length() > 0) {TextoFull = TextoFull + "\n";}
    	TextoFull = TextoFull + Texto;
    	V1.jTextArea6.setText(TextoFull);
	}
	
	public void ImprimirConsolaProductor(String Texto) {
		String TextoFull;
		TextoFull = V1.jTextArea7.getText();
    	if (TextoFull.length() > 0) {TextoFull = TextoFull + "\n";}
    	TextoFull = TextoFull + Texto;
    	V1.jTextArea7.setText(TextoFull);
	}
	
/*	public void EscriboLog(String S) throws IOException {
		FileOutputStream MyLog;
		MyLog = new FileOutputStream("Log.txt");
        int b = 0;
        int i = 0;
        while ((i < ( -1)) && 
                ( ( b = System.in.read() ) != '\n' ) )
                linea[i++] = (byte)b;
            linea[i] = (byte)0;
        }
        
		MyLog.write(b);
	}*/
}	




