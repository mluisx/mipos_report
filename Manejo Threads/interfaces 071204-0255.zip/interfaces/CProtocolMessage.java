package interfaces;

import java.util.*;

public class CProtocolMessage extends CMessage {
	/**
		This class represents a Protocol Message Between The InterfazHWVer3 & Consumidor
	*/
	public static final int CLASS_ALL = 0;	
	public static final int CLASS_REC_UNREAD = 1;
	public static final int CLASS_REC_READ = 2;
	public static final int CLASS_STO_UNSENT = 3;
	public static final int CLASS_STO_SENT = 4;
	int NroLectura, SMSLeidos, SMSEnviados;
	
	public CProtocolMessage(Date date, String originator, String text, int memindex, int superid, int NroLectura, int SMSLeidos, int SMSEnviados) {
		super(TYPE_PROTOCOL, date, originator, null, text, memindex , superid);
		this.NroLectura  = NroLectura;
		this.SMSLeidos   = SMSLeidos;
		this.SMSEnviados = SMSEnviados;
	}

	public void setOriginator(String originator) { this.originator = originator; }
	
	public String getOriginator() { return originator; }

}


