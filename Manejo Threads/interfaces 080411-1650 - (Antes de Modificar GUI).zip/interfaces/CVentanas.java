package interfaces;

import java.util.LinkedList;
import javax.swing.*;

// Heredarla de interfaz gr�fica (MODIF)

public class CVentanas {

	private static final long serialVersionUID = 1L;
	
	public VentanaAeropuertos Aeropuertos;
	public VentanaAviones Aviones;
	public VentanaClientes Clientes;
	public VentanaDestinos Destinos;
	public VentanaVuelos Vuelos;
	public VentanaVentas Ventas;	
	public VentanaOpcionesGSM OpcionesGSM;
	public VentanaAccesoBD AccesoBD;
	public VentanaCargarContactos CargarContactos;
	public VentanaGuardarContactos GuardarContactos;
	public VentanaArchivosXML ArchivosXML;
	public VentanaTiemposLectura TiemposLectura;
	public VentanaArchivoLog ArchivoLog;
	public VentanaAcercaDe AcercaDe;
	public CInicio Inicio;
	public CInterfazGrafica GUI;
	
	public CVentanas(CInicio Inicio, CInterfazGrafica GUI) {
		this.Inicio = Inicio;
		this.GUI = GUI;
		Aeropuertos = null;
		Aviones = null;
		Clientes = null;
		Destinos = null;
		Vuelos = null;
		Ventas = null;
		OpcionesGSM = null;
		AccesoBD = null;
		CargarContactos = null;
		GuardarContactos = null;
		ArchivosXML = null;
		TiemposLectura = null;
		ArchivoLog = null;
		AcercaDe = null;
	}
	
//  Creo Un M�todo Para Pasar Un Valor de String a Objetos y Poder Grabarlos En Una Cola De Objetos
	
	public Object makeObj(final String item) { 
	return new Object() { 
		public String toString() { return item; } };
	}	
	
	public class VentanaAeropuertos extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JLabel jLabel1, jLabel2, jLabel3, jLabel4, jLabel5;
		private JTextField jTextField1, jTextField6;
		private JComboBox jComboBox1, jComboBox2, jComboBox3;
		private JButton jButton1, jButton2;
		private JPanel jPanel1;
		private LinkedList<Object> Ciudades, Provincias;
		
		public VentanaAeropuertos() {

//	 		Opciones De Ventana "Agregar Aeropuertos"
			
	        jPanel1 = new JPanel();
	        jLabel1 = new JLabel();
	        jTextField1 = new JTextField();
	        jLabel2 = new JLabel();
	        jLabel3 = new JLabel();
	        jButton1 = new JButton();
	        jButton2 = new JButton();
	        jLabel4 = new JLabel();
	        jLabel5 = new JLabel();
	        jTextField6 = new JTextField();
	        jComboBox1 = new JComboBox();
	        jComboBox2 = new JComboBox();
	        jComboBox3 = new JComboBox();
	        Provincias = new LinkedList<Object>();
	        Ciudades = new LinkedList<Object>();

	        
	        setTitle("Agregar Aeropuertos A Base De Datos");
			setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(308, 250, 363, 287));
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");
	        jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel1.setText("Nombre");

	        jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel2.setText("Cantidad De Pistas");

	        jLabel3.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel3.setText("Ciudad");

	        jButton1.setText("Agregar");
	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton1ActionPerformed(evt);
	            }
	        });

	        jButton2.setText("Salir");
	        jButton2.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton2ActionPerformed(evt);
	            }
	        });

	        jLabel4.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel4.setText("Provincia");

	        jLabel5.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel5.setText("C�digo");
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });
	        
	        for (int i=1;i<9;i++) {
				jComboBox1.addItem(makeObj(Integer.toString(i)));
			}
	        
	        Ciudades = GUI.BD.BuscoCiudades();
			for (int i=0;i<Ciudades.size();i++) {
				jComboBox2.addItem(Ciudades.get(i));
			}
			jComboBox2.setSelectedIndex(7);
			
	        Provincias = GUI.BD.BuscoProvincias();
			for (int i=0;i<Provincias.size();i++) {
				jComboBox3.addItem(Provincias.get(i));
			}
			jComboBox3.setSelectedIndex(4);
			
	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addComponent(jLabel4, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(jComboBox3, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addComponent(jLabel5, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(jTextField6, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addComponent(jLabel2, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()       
	                        .addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addComponent(jLabel3, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(jComboBox2, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)))
	                .addContainerGap())
	            .addGroup(jPanel1Layout.createSequentialGroup()
	            	.addGap(60, 60, 60)
	                .addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
	                .addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                .addGap(60, 60, 60))                
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel1)
	                    .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jComboBox2, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel3))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jComboBox3, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel4))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jTextField6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel5))
	                .addGap(14, 14, 14)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jButton1)
	                    .addComponent(jButton2))
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap())
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
		}
		
		private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
			int Resultado = GUI.BD.AgregoAeropuerto(jTextField1.getText(), Integer.parseInt(jComboBox1.getSelectedItem().toString()), jComboBox2.getSelectedItem().toString(), 
					jComboBox3.getSelectedItem().toString(), jTextField6.getText());
    	  	if (Resultado == 0) { GUI.jTextArea2.setText("Los Datos Del Aeropuerto " + jTextField1.getText() + " Han Sido Cargados En La Base De Datos"); }
    	  	else { GUI.jTextArea2.setText("No Se Pudo Almacenar Los Datos Del Aeropuerto En La Base De Datos, Por Favor, Reingreselos"); }
    	  	jTextField1.setText("");
			jTextField6.setText("");
			jComboBox1.setSelectedIndex(0);
			jComboBox2.setSelectedIndex(7);
			jComboBox3.setSelectedIndex(4);
			dispose();
        }
        
        private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
			jTextField1.setText("");
			jTextField6.setText("");
			jComboBox1.setSelectedIndex(0);
        	jComboBox2.setSelectedIndex(7);
			jComboBox3.setSelectedIndex(4);
        	dispose();
        }
        
        public void CerrarVentana(java.awt.event.WindowEvent event) {
			jTextField1.setText("");
			jTextField6.setText("");
			jComboBox1.setSelectedIndex(0);
			jComboBox2.setSelectedIndex(7);
			jComboBox3.setSelectedIndex(4);
        	dispose();
        }
	}
    
	public class VentanaAviones extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JLabel jLabel1, jLabel2, jLabel3;
		private JTextField jTextField1 ,jTextField2 ,jTextField3;
		private JButton jButton1, jButton2;
		private JPanel jPanel1;
		
		public VentanaAviones() {
			
//	 		Opciones De Ventana "Agregar Aviones"
			
	        jPanel1 = new JPanel();
	        jLabel1 = new JLabel();
	        jTextField1 = new JTextField();
	        jLabel2 = new JLabel();
	        jTextField2 = new JTextField();
	        jLabel3 = new JLabel();
	        jTextField3 = new JTextField();
	        jButton1 = new JButton();
	        jButton2 = new JButton();

	        setTitle("Agregar Aviones A Base De Datos");
			setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(300, 269, 400, 299));
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");
	        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel1.setText("Tipo De Avi\u00f3n");

	        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel2.setText("Capacidad (Pasajeros)");

	        jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel3.setText("C\u00f3digo Avi\u00f3n");

	        jButton1.setText("Agregar");
	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton1ActionPerformed(evt);
	            }
	        });

	        jButton2.setText("Salir");
	        jButton2.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton2ActionPerformed(evt);
	            }
	        });
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addContainerGap()
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                            .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
	                            .addComponent(jLabel1, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
	                            .addComponent(jLabel3, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE))
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
	                            .addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addContainerGap()
	                        .addGroup(jPanel1Layout.createSequentialGroup()
	                            .addGap(56, 56, 56)
	                            .addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
	                            .addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                            .addGap(56, 56, 56))))
	                .addContainerGap())
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel1)
	                    .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel3))
	                .addGap(14, 14, 14)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jButton1)
	                    .addComponent(jButton2))
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
	                .addContainerGap())
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
	                .addContainerGap())
	        );
	        pack();
		}
		
		private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
			int Resultado = GUI.BD.AgregoAvion(jTextField1.getText(), Integer.parseInt(jTextField2.getText()), jTextField3.getText());
    	  	if (Resultado == 0) { GUI.jTextArea2.setText("Los Datos Del Avi�n " + jTextField1.getText() + " Han Sido Cargados En La Base De Datos"); }
    	  	else { GUI.jTextArea2.setText("No Se Pudo Almacenar Los Datos Del Avi�n En La Base De Datos, Por Favor, Reingreselos"); }
    	  	jTextField1.setText("");
			jTextField2.setText("");
			jTextField3.setText("");
			dispose();
        }
        
        private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
    	  	jTextField1.setText("");
			jTextField2.setText("");
			jTextField3.setText("");
        	dispose();
        }
        
        public void CerrarVentana(java.awt.event.WindowEvent event) {
    	  	jTextField1.setText("");
			jTextField2.setText("");
			jTextField3.setText("");
        	dispose();
        }   
	}
	
	public class VentanaClientes extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JLabel jLabel1, jLabel2, jLabel3, jLabel4, jLabel5, jLabel6, jLabel7, jLabel8, jLabel9;
		private JTextField jTextField1, jTextField3, jTextField6, jTextField7;
		private JComboBox jComboBox1, jComboBox2, jComboBox3, jComboBox4;
		private JButton jButton1, jButton2;
		private JPanel jPanel1;
		
		public VentanaClientes() {

//	 		Opciones De Ventana "Agregar Clientes"
			
	        jPanel1 = new JPanel();
	        jLabel1 = new JLabel();
	        jTextField1 = new JTextField();
	        jLabel2 = new JLabel();
	        jLabel3 = new JLabel();
	        jTextField3 = new JTextField();
	        jButton1 = new JButton();
	        jButton2 = new JButton();
	        jLabel4 = new JLabel();
	        jLabel5 = new JLabel();
	        jTextField6 = new JTextField();
	        jLabel6 = new JLabel();				// Apellido 
	        jTextField7 = new JTextField();		// Colocar Apellido Del Cliente 
	        jComboBox1 = new JComboBox();
	        jComboBox2 = new JComboBox();
	        jComboBox3 = new JComboBox();
	        jComboBox4 = new JComboBox();		// Tipo de Documento
	        jLabel7 = new JLabel();
	        jLabel8 = new JLabel();
	        jLabel9 = new JLabel();
	        
			for (int i=1;i<32;i++) {
				if (i<10) {
					jComboBox1.addItem(makeObj("0" + Integer.toString(i)));
					jComboBox2.addItem(makeObj("0" + Integer.toString(i)));
				}
				else {
					if (i<13) {jComboBox2.addItem(makeObj(Integer.toString(i)));}
					jComboBox1.addItem(makeObj(Integer.toString(i)));
				}
			}
			
			for (int i=0;i<60;i++) {
				jComboBox3.addItem(makeObj("19" + Integer.toString(99-i)));
			}
			
	        jComboBox4.setModel(new DefaultComboBoxModel(new String[] { "DNI", "LE", "LC", "CI" }));
					    
	        setTitle("Agregar Clientes A Base De Datos");
			setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(307, 228, 363, 323));
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");
	        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel1.setText("Nombre");

	        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel2.setText("Documento Tipo");

	        jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel3.setText("Documento N�mero");

	        jButton1.setText("Agregar");
	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton1ActionPerformed(evt);
	            }
	        });

	        jButton2.setText("Salir");
	        jButton2.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton2ActionPerformed(evt);
	            }
	        });
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

	        jLabel4.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel4.setText("Fecha Nac.");

	        jLabel5.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel5.setText("N�mero Celular");
	        
	        jLabel6.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel6.setText("Apellido");
	        
	        jLabel7.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel7.setText("D�a");
	        
	        jLabel8.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel8.setText("Mes");
	        
	        jLabel9.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel9.setText("A�o");

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
		                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
	                    	.addComponent(jLabel4, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
	                        .addComponent(jLabel7, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
	                        .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)	
	                        .addComponent(jLabel8, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
	                        .addComponent(jComboBox2, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
	                        .addComponent(jLabel9, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
	                        .addComponent(jComboBox3, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addComponent(jLabel5, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(jTextField6, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
                    		.addComponent(jLabel1, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    		.addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
                    	.addGroup(jPanel1Layout.createSequentialGroup()	
                       		.addComponent(jLabel6, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    		.addComponent(jTextField7, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()	                        
	                        .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                    	.addComponent(jComboBox4, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
		                    .addComponent(jLabel3, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
	                    	.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
		                    .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)))	                            	                            
	                .addContainerGap())
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addGap(60, 60, 60)
	                .addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
	                .addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                .addGap(60, 60, 60))
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel1)
	                    .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                	.addComponent(jLabel6)
		                .addComponent(jTextField7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
	                .addGap(16, 16, 16)	                
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
		                .addComponent(jTextField6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
			            .addComponent(jLabel5))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel3))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                	.addComponent(jComboBox4, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
		                .addComponent(jLabel2))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel7)
	                    .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel8)
	                    .addComponent(jComboBox2, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel9)
	                    .addComponent(jComboBox3, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel4))
	                .addGap(14, 14, 14)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jButton1)
	                    .addComponent(jButton2))
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap())
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
		}
	
		private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
			int Resultado = GUI.BD.AgregoCliente(jTextField1.getText(), jTextField7.getText(), jTextField6.getText(), Integer.parseInt(jTextField3.getText()),
					jComboBox4.getSelectedItem().toString(), jComboBox3.getSelectedItem().toString() + "-" + jComboBox2.getSelectedItem().toString() + "-" + 
					jComboBox1.getSelectedItem().toString());
    	  	if (Resultado == 0) { GUI.jTextArea2.setText("Los Datos Del Cliente " + jTextField1.getText() + " " + jTextField7.getText() + " Han Sido Cargados En La Base De Datos"); }
    	  	else { GUI.jTextArea2.setText("No Se Pudo Almacenar Los Datos Del Cliente En La Base De Datos, Por Favor, Reingreselos"); }
    	  	jTextField1.setText("");
			jTextField3.setText("");
			jTextField6.setText("");
			jTextField7.setText("");
			jComboBox1.setSelectedIndex(0);
			jComboBox2.setSelectedIndex(0);
			jComboBox3.setSelectedIndex(0);
			jComboBox4.setSelectedIndex(0);
			dispose();
        }
        
        private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
    	  	jTextField1.setText("");
			jTextField3.setText("");
			jTextField6.setText("");
			jTextField7.setText("");
			jComboBox1.setSelectedIndex(0);
			jComboBox2.setSelectedIndex(0);
			jComboBox3.setSelectedIndex(0);
			jComboBox4.setSelectedIndex(0);
        	dispose();
        }
        
        public void CerrarVentana(java.awt.event.WindowEvent event) {
    	  	jTextField1.setText("");
			jTextField3.setText("");
			jTextField6.setText("");
			jTextField7.setText("");
			jComboBox1.setSelectedIndex(0);
			jComboBox2.setSelectedIndex(0);
			jComboBox3.setSelectedIndex(0);
			jComboBox4.setSelectedIndex(0);
        	dispose();
        }      
	}
	
	public class VentanaDestinos extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JLabel jLabel1, jLabel2, jLabel3, jLabel4, jLabel5;
		private JTextField jTextField1 ,jTextField3 ,jTextField4, jTextField5, jTextField6;
		private JButton jButton1, jButton2;
		private JComboBox jComboBox1;
		private JPanel jPanel1;
		
		public VentanaDestinos() {

//	 		Opciones De Ventana "Agregar Destinos"
			
	        jPanel1 = new JPanel();
	        jLabel1 = new JLabel();
	        jTextField1 = new JTextField();
	        jLabel2 = new JLabel();
	        jComboBox1 = new JComboBox();
	        jLabel3 = new JLabel();
	        jTextField3 = new JTextField();
	        jButton1 = new JButton();
	        jTextField4 = new JTextField();
	        jButton2 = new JButton();
	        jLabel4 = new JLabel();
	        jLabel5 = new JLabel();
	        jTextField4 = new JTextField();
	        jTextField5 = new JTextField();
	        jTextField6 = new JTextField();
	        
	        setTitle("Agregar Destinos A Base De Datos");
			setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(308, 224, 363, 321));
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");
	        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel1.setText("Nombre Ciudad");

	        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel2.setText("Zona Horaria");

	        jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel3.setText("Cant. Aeropuertos");

	        jButton1.setText("Agregar");

	        jTextField4.setEditable(false);

	        jButton2.setText("Salir");
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

	        jLabel4.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel4.setText("Provincia");

	        jLabel5.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel5.setText("C�digo Ciudad");
	        
	        jComboBox1.addItem(makeObj("GMT"));
	        
	        for (int i=1;i<=12;i++) {
				jComboBox1.addItem(makeObj("GMT -" + Integer.toString(i)));
			}  
	        
			for (int i=1;i<14;i++) {
				jComboBox1.addItem(makeObj("GMT +" + Integer.toString(i)));
			}

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addComponent(jLabel4, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(jTextField5, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addComponent(jLabel5, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(jTextField6, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                            .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
	                            .addComponent(jLabel1, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
	                            .addComponent(jLabel3, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE))
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
	                            .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))))
	                .addContainerGap())
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addGap(60, 60, 60)
	                .addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
	                .addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                .addGap(60, 60, 60))
	            .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jTextField4, GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
	                .addContainerGap())
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel1)
	                    .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel3))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jTextField5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel4))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jTextField6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel5))
	                .addGap(14, 14, 14)
	                .addComponent(jTextField4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addGap(14, 14, 14)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jButton1)
	                    .addComponent(jButton2))
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap())
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
		}
		
        public void CerrarVentana(java.awt.event.WindowEvent event) {
        	dispose();
        }        
	}
	
	public class VentanaVuelos extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JLabel jLabel1, jLabel2, jLabel3, jLabel4, jLabel5, jLabel6, jLabel7, jLabel8, jLabel9, jLabel10, jLabel11, jLabel12, jLabel13, jLabel14, jLabel15, jLabel16, jLabel17;
		private JLabel jLabel18, jLabel19, jLabel20;
		private JTextField jTextField1, jTextField4, jTextField10, jTextField11;
		private JComboBox jComboBox1, jComboBox2, jComboBox3, jComboBox4, jComboBox5, jComboBox6, jComboBox7, jComboBox8, jComboBox9, jComboBox10, jComboBox11, jComboBox12;
		private JComboBox jComboBox13, jComboBox14, jComboBox15;
		private JButton jButton1, jButton2;
		private JPanel jPanel1;
		private LinkedList<Object> Ciudades, Aviones;
		
		public VentanaVuelos() {

//	 		Opciones De Ventana "Agregar Vuelos"
			
	        jPanel1 = new JPanel();
	        jLabel1 = new JLabel();
	        jTextField1 = new JTextField();
	        jLabel2 = new JLabel();
	        jComboBox1 = new JComboBox();
	        jLabel3 = new JLabel();
	        jComboBox2 = new JComboBox();
	        jButton1 = new JButton();
	        jComboBox3 = new JComboBox(); // Para Elegir C�digo De Avi�n
	        jTextField4 = new JTextField();
	        jComboBox4 = new JComboBox(); // Para Elegir Hora De Salida
	        jComboBox5 = new JComboBox(); // Para Elegir Minutos De Salida
	        jComboBox6 = new JComboBox(); // Para Elegir AM/PM De Salida
	        jComboBox7 = new JComboBox(); // Para Elegir Hora De Llegada
	        jComboBox8 = new JComboBox(); // Para Elegir Minutos De Llegada
	        jComboBox9 = new JComboBox(); // Para Elegir AM/PM De Llegada
	        jComboBox10 = new JComboBox(); // Para Elegir Dia De Salida
	        jComboBox11 = new JComboBox(); // Para Elegir Mes De Salida
	        jComboBox12 = new JComboBox(); // Para Elegir A�o de Salida
	        jComboBox13 = new JComboBox(); // Para Elegir Dia de Llegada
	        jComboBox14 = new JComboBox(); // Para Elegir Mes de Llegada
	        jComboBox15 = new JComboBox(); // Para Elegir A�o de Llegada
	        jButton2 = new JButton();
	        jLabel4 = new JLabel();
	        jLabel5 = new JLabel();
	        jLabel6 = new JLabel();
	        jLabel7 = new JLabel();
	        jLabel8 = new JLabel();
	        jLabel9 = new JLabel();
	        jLabel10 = new JLabel();
	        jLabel11 = new JLabel();
	        jLabel12 = new JLabel();
	        jLabel13 = new JLabel();
	        jLabel14 = new JLabel();
	        jLabel15 = new JLabel();
	        jLabel16 = new JLabel();
	        jLabel17 = new JLabel();
	        jLabel18 = new JLabel();
	        jLabel19 = new JLabel();
	        jLabel20 = new JLabel();
	        jTextField10 = new JTextField();
	        jTextField11 = new JTextField();
	        Ciudades = new LinkedList<Object>();
	        Aviones = new LinkedList<Object>();

	        setTitle("Agregar Vuelos A Base De Datos");
			setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(143, 223, 680, 321));
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");

	        jButton1.setText("Agregar");
	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton1ActionPerformed(evt);
	            }
	        });
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

	        jTextField4.setEditable(false);
	        
	        Ciudades = GUI.BD.BuscoCiudades();
			for (int i=0;i<Ciudades.size();i++) {
				jComboBox1.addItem(Ciudades.get(i));
				jComboBox2.addItem(Ciudades.get(i));
			}
			
			Aviones = GUI.BD.BuscoAviones();
			for (int i=0;i<Aviones.size();i++) {
				jComboBox3.addItem(Aviones.get(i));
			}
			
			for (int i=0;i<13;i++) {
				jComboBox4.addItem(makeObj(Integer.toString(i)));
				jComboBox7.addItem(makeObj(Integer.toString(i)));
				if (i<2) {
					jComboBox5.addItem(makeObj("0" + Integer.toString(i*5)));
					jComboBox8.addItem(makeObj("0" + Integer.toString(i*5)));
				}
				else if (i<12) {
					jComboBox5.addItem(makeObj(Integer.toString(i*5)));
					jComboBox8.addItem(makeObj(Integer.toString(i*5)));
				}
			}
			
			for (int i=1;i<32;i++) {
				if (i<10) {
					jComboBox10.addItem(makeObj("0" + Integer.toString(i)));
					jComboBox11.addItem(makeObj("0" + Integer.toString(i)));
					jComboBox13.addItem(makeObj("0" + Integer.toString(i)));
					jComboBox14.addItem(makeObj("0" + Integer.toString(i)));
				}
				else {
					if (i<13) {
						jComboBox11.addItem(makeObj(Integer.toString(i)));
						jComboBox14.addItem(makeObj(Integer.toString(i)));
					}
					jComboBox10.addItem(makeObj(Integer.toString(i)));
					jComboBox13.addItem(makeObj(Integer.toString(i)));
				}
			}
			
			jComboBox6.addItem(makeObj("AM"));
			jComboBox6.addItem(makeObj("PM"));
			jComboBox9.addItem(makeObj("AM"));
			jComboBox9.addItem(makeObj("PM"));
			jComboBox12.addItem(makeObj("2008"));
			jComboBox12.addItem(makeObj("2009"));
			jComboBox12.addItem(makeObj("2010"));
			jComboBox15.addItem(makeObj("2008"));
			jComboBox15.addItem(makeObj("2009"));
			jComboBox15.addItem(makeObj("2010"));
			
	        jButton2.setText("Salir");

	        jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel1.setText("N�mero De Vuelo");

	        jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel2.setText("Ciudad Origen");

	        jLabel3.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel3.setText("Ciudad Destino");
	        
	        jLabel4.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel4.setText("C�digo De Avi�n");

	        jLabel5.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel5.setText("Horario Salida");

	        jLabel6.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel6.setText("Horario Llegada");

	        jLabel7.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel7.setText("Fecha Salida");

	        jLabel8.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel8.setText("Fecha Llegada");

	        jLabel9.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel9.setText("Precio (Pesos Arg.)");

	        jLabel10.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel10.setText("Asientos Libres");
	        
	        jLabel11.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel11.setText("Hs");
	        
	        jLabel12.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel12.setText("Min");
	        
	        jLabel13.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel13.setText("Hs");
	        
	        jLabel14.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel14.setText("Min");
	        
	        jLabel15.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel15.setText("D�a");
	        
	        jLabel16.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel16.setText("Mes");
	        
	        jLabel17.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel17.setText("A�o");
	        
	        jLabel18.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel18.setText("D�a");
	        
	        jLabel19.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel19.setText("Mes");
	        
	        jLabel20.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel20.setText("A�o");

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING) //Arranca lado izq.
	                            .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
                                    .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                            .addGroup(jPanel1Layout.createSequentialGroup()
	                                .addComponent(jLabel2, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
	                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
	                                .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                            .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel3, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
                                    .addComponent(jComboBox2, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                            .addGroup(jPanel1Layout.createSequentialGroup()
	                                .addComponent(jLabel5, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
	                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
                                   	.addComponent(jComboBox4, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
                                   	.addComponent(jLabel11, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
                                   	.addComponent(jComboBox5, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
                                   	.addComponent(jLabel12, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                  	.addComponent(jComboBox6, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE))	                                
	                            .addGroup(jPanel1Layout.createSequentialGroup()
	                        	    .addComponent(jLabel6, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE)
	                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
                                	.addComponent(jComboBox7, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel13, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox8, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox9, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE))) // Termina Lado Izquierdo
	                        .addGap(8, 8, 8)
                            .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                            .addGroup(jPanel1Layout.createSequentialGroup()
	                                .addComponent(jLabel10, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
	                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
	                                .addComponent(jTextField11, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                            .addGroup(jPanel1Layout.createSequentialGroup()
	                                .addComponent(jLabel9, GroupLayout.PREFERRED_SIZE, 114, GroupLayout.PREFERRED_SIZE)
	                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
	                                .addComponent(jTextField10, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                            .addGroup(jPanel1Layout.createSequentialGroup()
	                                .addComponent(jLabel8, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE)
	                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 3, GroupLayout.PREFERRED_SIZE)
	                               	.addComponent(jLabel18, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
	                                .addComponent(jComboBox13, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel19, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
	                                .addComponent(jComboBox14, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
	                                .addComponent(jLabel20, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox15, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE))
	                            .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel4, GroupLayout.DEFAULT_SIZE, 114, Short.MAX_VALUE)
                                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 6, Short.MAX_VALUE)
                                	.addComponent(jComboBox3, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                            .addGroup(jPanel1Layout.createSequentialGroup()
	                                .addComponent(jLabel7, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE)
	                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 3, GroupLayout.PREFERRED_SIZE)
	                               	.addComponent(jLabel15, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
	                                .addComponent(jComboBox10, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel16, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
	                                .addComponent(jComboBox11, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
	                                .addComponent(jLabel17, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox12, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE)))
	                        .addContainerGap())
	                    .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
		                    .addGap(213, 213, 213)
	                    	.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                    	.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
	                        .addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                        .addGap(213, 213, 213))
	                    .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
	                        .addComponent(jTextField4, GroupLayout.DEFAULT_SIZE, 599, Short.MAX_VALUE)
	                        .addContainerGap())))
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                            .addComponent(jLabel1)
	                            .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jLabel15)
	                            .addComponent(jLabel16)
	                            .addComponent(jLabel17)
	                            .addComponent(jLabel7)
	                            .addComponent(jComboBox10, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jComboBox11, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jComboBox12, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
	                        .addGap(16, 16, 16)
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)

	                            .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
	                            .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jLabel8)
	                            .addComponent(jLabel18)
	                            .addComponent(jLabel19)
	                            .addComponent(jLabel20)
	                            .addComponent(jComboBox13, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jComboBox14, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jComboBox15, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
	                        .addGap(16, 16, 16)
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                            .addComponent(jComboBox2, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
		                        .addComponent(jLabel4)
		                        .addComponent(jComboBox3, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jLabel3))
	                        .addGap(16, 16, 16)
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                            .addComponent(jLabel10)
	                            .addComponent(jTextField11, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jComboBox4, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jComboBox5, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jComboBox6, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jLabel5)
	                            .addComponent(jLabel11)
	                            .addComponent(jLabel12))
	                        .addGap(16, 16, 16)
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
		                        .addComponent(jLabel9)
   	                            .addComponent(jTextField10, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
   	                            .addComponent(jLabel13)
	                            .addComponent(jLabel14)
	                            .addComponent(jLabel6)
	                            .addComponent(jComboBox7, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jComboBox8, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jComboBox9, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
	                        .addGap(14, 14, 14))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                        )
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)))
	                .addComponent(jTextField4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addGap(14, 14, 14)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jButton1)
	                    .addComponent(jButton2))
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
	                .addContainerGap())
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
	    }
		
	    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
	    	int Resultado = GUI.BD.AgregoVuelo(jTextField1.getText(),jComboBox1.getSelectedItem().toString(),jComboBox2.getSelectedItem().toString(),jComboBox3.getSelectedItem().toString(),
	    			jComboBox4.getSelectedItem().toString() + ":" +	jComboBox5.getSelectedItem().toString() + " " + jComboBox6.getSelectedItem().toString(),jComboBox7.getSelectedItem().toString()
	    			+ ":" +	jComboBox8.getSelectedItem().toString() + " " + jComboBox9.getSelectedItem().toString(),jComboBox10.getSelectedItem().toString() + "/"
	    			+ jComboBox11.getSelectedItem().toString() + "/" + jComboBox12.getSelectedItem().toString(),jComboBox13.getSelectedItem().toString() + "/"
	    			+ jComboBox14.getSelectedItem().toString() + "/" + jComboBox15.getSelectedItem().toString(),jTextField10.getText(),jTextField11.getText());
    	  	if (Resultado == 0) {
    	  		jTextField4.setText("El Vuelo Nro " + jTextField1.getText() + " Ha Sido Cargado En La Base De Datos");
    	  	}
	    }
        
	    public void CerrarVentana(java.awt.event.WindowEvent event) {
        	dispose();
        }	    
	}
	
	public class VentanaOpcionesGSM extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JLabel jLabel1, jLabel2; // jLabel4, jLabel5;
		private JComboBox jComboBox1, jComboBox2; //, jComboBox4, jComboBox5;
		private JButton jButton1, jButton2;
		private JPanel jPanel1;
		private int indice1, indice2;
		
		public VentanaOpcionesGSM() {
			
//	 		Opciones De Ventana "Opciones GSM" del Menu Configuraci�n
			
	        jPanel1 = new JPanel();
	        jLabel1 = new JLabel();
	        jLabel2 = new JLabel();
	        jButton1 = new JButton();
	        jButton2 = new JButton();
//	        jLabel4 = new JLabel();
//	        jLabel5 = new JLabel();
	        jComboBox1 = new JComboBox();
	        jComboBox2 = new JComboBox();
//	        jComboBox4 = new JComboBox();
//	        jComboBox5 = new JComboBox();
	        indice1 = 6;						// Selecci�n Del Puerto De Comunicaciones
	        indice2 = 1;						// Selecci�n De Velocidad De Conexi�n
       
	        setTitle("Opciones Del Dispositivo GSM");
	        setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(324, 303, 329, 176)); 
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");
	        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel1.setText("Puerto Comunicaciones");

	        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel2.setText("Velocidad (bps)");

	        jButton1.setText("Aceptar");
	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton1ActionPerformed(evt);
	            }
	        });

	        jButton2.setText("Cancelar");
	        jButton2.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton2ActionPerformed(evt);
	            }
	        });
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

//	        jLabel4.setHorizontalAlignment(SwingConstants.CENTER);
//	        jLabel4.setText("Tiempo de Lectura de SMS");

//	        jLabel5.setHorizontalAlignment(SwingConstants.CENTER);
//	        jLabel5.setText("Tiempo De Envio De SMS");

	        jComboBox1.setModel(new DefaultComboBoxModel(new String[] { "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "COM10" }));

	        jComboBox2.setModel(new DefaultComboBoxModel(new String[] { "19200", "115200", }));

//	        jComboBox3.setModel(new DefaultComboBoxModel(new String[] { "Sony Ericsson", "Nokia", "Motorola", "Samsung" }));
	        
	        jComboBox1.setSelectedIndex(indice1);
	        jComboBox2.setSelectedIndex(indice2);

//	        jComboBox4.setModel(new DefaultComboBoxModel(new String[] { "Art\u00edculo 1", "Art\u00edculo 2", "Art\u00edculo 3", "Art\u00edculo 4" }));

//	        jComboBox5.setModel(new DefaultComboBoxModel(new String[] { "Art\u00edculo 1", "Art\u00edculo 2", "Art\u00edculo 3", "Art\u00edculo 4" }));

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addGap(31, 31, 31)
	                    	.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
	                        .addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                        .addGap(31, 31, 31))
	                    .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                            .addComponent(jLabel1, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
	                            .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE))
	                            //.addComponent(jLabel4, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
	                            //.addComponent(jLabel5, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE))
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                            .addComponent(jComboBox2, GroupLayout.PREFERRED_SIZE, 124, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 124, GroupLayout.PREFERRED_SIZE))))
	                            //.addComponent(jComboBox4, GroupLayout.PREFERRED_SIZE, 124, GroupLayout.PREFERRED_SIZE)
	                            //.addComponent(jComboBox5, GroupLayout.PREFERRED_SIZE, 124, GroupLayout.PREFERRED_SIZE))))
	                .addContainerGap())
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel1)
	                    .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
	                .addGap(13, 13, 13)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel2)
	                    .addComponent(jComboBox2, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
	                .addGap(14, 14, 14)
/*	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel4)
	                    .addComponent(jComboBox4, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
	                .addGap(15, 15, 15)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jComboBox5, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                    .addComponent(jLabel5))
	                .addGap(16, 16, 16)*/
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jButton1)
	                    .addComponent(jButton2))
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
	        
		}
		
		private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        	Inicio.FijoDatosConexion(jComboBox1.getSelectedItem().toString(), jComboBox2.getSelectedItem().toString());
        	if (jComboBox1.getSelectedIndex() >= 0)	{ indice1 = jComboBox1.getSelectedIndex(); }
        	if (jComboBox2.getSelectedIndex() >= 0)	{ indice2 = jComboBox2.getSelectedIndex(); }
        	dispose();
        }
        
        private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
	        jComboBox1.setSelectedIndex(indice1);
	        jComboBox2.setSelectedIndex(indice2);
        	dispose();
        }
        
        public void CerrarVentana(java.awt.event.WindowEvent event) {
	        jComboBox1.setSelectedIndex(indice1);
	        jComboBox2.setSelectedIndex(indice2);
	        dispose();
        }
	}

	public class VentanaArchivosXML extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JCheckBox jCheckBox1, jCheckBox2;
//		private JComboBox jComboBox1, jComboBox2, jComboBox3;
		private JButton jButton1, jButton2;
		private JPanel jPanel1;
		private boolean indice1, indice2;
		
		public VentanaArchivosXML() {
			
//	 		Opciones De Ventana "Archivos XML" del Menu Configuraci�n
			
	        jPanel1 = new JPanel();
	        jCheckBox1 = new JCheckBox();
	        jCheckBox2 = new JCheckBox();
	        jButton1 = new JButton();
	        jButton2 = new JButton();
	        indice1 = indice2 = true;

	        setTitle("Opciones Para Los Archivos XML");
			setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(324, 300, 329, 182));
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");
	        
	        jCheckBox1.setText("Generar XML Para SMS Recibido");
	        jCheckBox1.setHorizontalAlignment(SwingConstants.LEFT);
	        jCheckBox1.setSelected(indice1);

	        jCheckBox2.setText("Generar XML Para SMS Enviado");
	        jCheckBox2.setHorizontalAlignment(SwingConstants.LEFT);
	        jCheckBox2.setSelected(indice2);
	        
	        jButton1.setText("Aceptar");
	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton1ActionPerformed(evt);
	            }
	        });

	        jButton2.setText("Cancelar");
	        jButton2.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton2ActionPerformed(evt);
	            }
	        });
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                    	.addGap(42, 42, 42)
	                    	.addComponent(jCheckBox1, GroupLayout.PREFERRED_SIZE, 246, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                    	.addGap(42, 42, 42)
	                    	.addComponent(jCheckBox2, GroupLayout.PREFERRED_SIZE, 246, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
		                    .addGap(43, 43, 43)
	                    	.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
		                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
		                    .addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                        .addGap(43, 43, 43)))
	                .addContainerGap())
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jCheckBox1))
	                .addGap(13, 13, 13)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jCheckBox2))
	                .addGap(15, 15, 15)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jButton1)
	                    .addComponent(jButton2))
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );						
		}
		
		private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
			if (jCheckBox1.getSelectedObjects() == null && indice1)	{ indice1 = false; }
			else if (jCheckBox1.getSelectedObjects() != null && !indice1) { indice1 = true; }
			if (jCheckBox2.getSelectedObjects() == null && indice2)	{ indice2 = false; }
			else if (jCheckBox2.getSelectedObjects() != null && !indice2) { indice2 = true; }
        	Inicio.FijoConfigXML(indice1,indice2);
        	dispose();
        }
        
        private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        	jCheckBox1.setSelected(indice1);
        	jCheckBox2.setSelected(indice2);
        	dispose();
        }
        
        public void CerrarVentana(java.awt.event.WindowEvent event) {
        	jCheckBox1.setSelected(indice1);
        	jCheckBox2.setSelected(indice2);
	        dispose();
        }    
	}	
	
	public class VentanaTiemposLectura extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JLabel jLabel1, jLabel2;
		private JComboBox jComboBox1, jComboBox2;
		private JButton jButton1, jButton2;
		private JPanel jPanel1;
		private int indice1, indice2;
		
		public VentanaTiemposLectura() {
			
//	 		Opciones De Ventana "Tiempos De Lectura" del Menu Configuraci�n
			
	        jPanel1 = new JPanel();
	        jLabel1 = new JLabel();
	        jLabel2 = new JLabel();
	        jButton1 = new JButton();
	        jButton2 = new JButton();
	        jComboBox1 = new JComboBox();
	        jComboBox2 = new JComboBox();
	        indice1 = 3;
	        indice2 = 0;

	        setTitle("Opciones De Los Tiempos De Lectura/Escritura");
			setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(273, 302, 431, 178));
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");
	        jLabel1.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel1.setText("Tiempo De Lectura De Datos Del Dispositivo GSM (seg.)");

	        jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
	        jLabel2.setText("Tiempo Entre Procesos de Mensajes SMS (seg.)");

	        jButton1.setText("Aceptar");
	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton1ActionPerformed(evt);
	            }
	        });

	        jButton2.setText("Cancelar");
	        jButton2.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton2ActionPerformed(evt);
	            }
	        });
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

	        jComboBox1.setModel(new DefaultComboBoxModel(new String[] { "5", "10", "15", "20", "25", "30", "35", "40", "80", "120" }));
	        jComboBox1.setSelectedIndex(indice1);

	        jComboBox2.setModel(new DefaultComboBoxModel(new String[] { "5", "10", "15", "20", "25", "30", "35", "40", "80", "120" }));

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
                        	.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 312, GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 5, GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
                        	.addComponent(jLabel2, GroupLayout.PREFERRED_SIZE, 312, GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 5, GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox2, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
		                    .addGap(82, 82, 82)
		                    .addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
		                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
		                    .addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
		                    .addGap(94, 94, 94)))
	                .addContainerGap())
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
		                .addComponent(jLabel1)
		                .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
	                .addGap(13, 13, 13)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
		                .addComponent(jLabel2)
		                .addComponent(jComboBox2, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
		            .addGap(15, 15, 15)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jButton1)
	                    .addComponent(jButton2))
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );		
		}
		
		private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
	    	if (jComboBox1.getSelectedIndex() >= 0)	{ indice1 = jComboBox1.getSelectedIndex(); }
	    	if (jComboBox2.getSelectedIndex() >= 0)	{ indice2 = jComboBox2.getSelectedIndex(); }
        	Inicio.FijoTiempoLecturas(jComboBox1.getSelectedItem().toString(), jComboBox2.getSelectedItem().toString());
        	dispose();
        }
		
        private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
            jComboBox1.setSelectedIndex(indice1);
            jComboBox2.setSelectedIndex(indice2);
        	dispose();
        }
        
        public void CerrarVentana(java.awt.event.WindowEvent event) {
            jComboBox1.setSelectedIndex(indice1);
            jComboBox2.setSelectedIndex(indice2);
	        dispose();
        }        
	}	
	
	public class VentanaArchivoLog extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JCheckBox jCheckBox1, jCheckBox2;
//		private JComboBox jComboBox1, jComboBox2, jComboBox3;
		private JButton jButton1, jButton2;
		private JPanel jPanel1;
		boolean indice1, indice2;
		
		public VentanaArchivoLog() {
			
//	 		Opciones De Ventana "Archivo De Log" del Menu Configuraci�n
			
	        jPanel1 = new JPanel();
	        jCheckBox1 = new JCheckBox();
	        jCheckBox2 = new JCheckBox();
	        jButton1 = new JButton();
	        jButton2 = new JButton();
	        indice1 = indice2 = true;
//	        jLabel4 = new JLabel();
//	        jLabel5 = new JLabel();

	        setTitle("Opciones Para El Archivo De Log");
			setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(320, 306, 337, 182));
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");
	        
	        jCheckBox1.setText("Generar Archivo De Log");
	        jCheckBox1.setHorizontalAlignment(SwingConstants.LEFT);
	        jCheckBox1.setSelected(indice1);

	        jCheckBox2.setText("Almacenar En Log Informaci�n De Protocolo");
	        jCheckBox2.setHorizontalAlignment(SwingConstants.LEFT);
	        jCheckBox2.setSelected(indice2);
	        
	        jButton1.setText("Aceptar");
	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton1ActionPerformed(evt);
	            }
	        });
	        
	        jButton2.setText("Cancelar");
	        jButton2.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	            	jButton2ActionPerformed(evt);
	            }
	        });
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
		                  //.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                    		.addComponent(jCheckBox1, GroupLayout.PREFERRED_SIZE, 280, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
			              //.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
	                    	.addComponent(jCheckBox2, GroupLayout.PREFERRED_SIZE, 280, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
		                    .addGap(39, 39, 39)
	                    	.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
		                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
		                    .addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                        .addGap(47, 47, 47)))
	                .addContainerGap())
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jCheckBox1))
	                .addGap(13, 13, 13)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jCheckBox2))
	                .addGap(15, 15, 15)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jButton1)
	                    .addComponent(jButton2))
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );						
		}
		
		private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
			if (jCheckBox1.getSelectedObjects() == null && indice1)	{ indice1 = false; }
			else if (jCheckBox1.getSelectedObjects() != null && !indice1) { indice1 = true; }
			if (jCheckBox2.getSelectedObjects() == null && indice2)	{ indice2 = false; }
			else if (jCheckBox2.getSelectedObjects() != null && !indice2) { indice2 = true; }
        	Inicio.FijoConfigLog(indice1,indice2);
        	dispose();
        }
        
        private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        	jCheckBox1.setSelected(indice1);
        	jCheckBox2.setSelected(indice2);
        	dispose();
        }
        
        public void CerrarVentana(java.awt.event.WindowEvent event) {
        	jCheckBox1.setSelected(indice1);
        	jCheckBox2.setSelected(indice2);
	        dispose();
        }        
	}	
	
	public class VentanaVentas extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JLabel jLabel1, jLabel2, jLabel3, jLabel4, jLabel5;
		private JTextField jTextField1, jTextField2 ,jTextField3, jTextField4;
		private JComboBox jComboBox1;
		private JButton jButton1, jButton2, jButton3;
		private JPanel jPanel1;
		
		public VentanaVentas() {

//	 		Opciones De Ventana Del Bot�n "Abrir" De La Parte De Reservas De La Ventana Principal
			
	        jPanel1 = new JPanel();
	        jLabel1 = new JLabel();
	        jTextField1 = new JTextField();
	        jTextField2 = new JTextField();
	        jTextField3 = new JTextField();
	        jTextField4 = new JTextField();
	        jLabel2 = new JLabel();
	        jLabel3 = new JLabel();
	        jButton1 = new JButton();
	        jButton2 = new JButton();
	        jButton3 = new JButton();
//	        jButton3 = new JButton();
	        jLabel4 = new JLabel();
	        jLabel5 = new JLabel();
	        jComboBox1 = new JComboBox();
	        
	        jComboBox1.setModel(new DefaultComboBoxModel(new String[] { "Tarjeta De Cr�dito", "Efectivo", "Dep�sito Bancario" }));
			    
	        setTitle("Finalizar Reserva De Vuelos");
	        setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(307, 236, 363, 325));
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");
	        
	        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel1.setText("Nombre Del Cliente");

	        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel2.setText("Documento N�mero");

	        jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel3.setText("N�mero De Reserva");
	        
	        jLabel4.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel4.setText("Precio Final");

	        jLabel5.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel5.setText("M�todo De Pago");
	        
	        jButton1.setText("Generar Venta");

//	        jTextField4.setEditable(false);

	        jButton2.setText("Cancelar Reserva");
	        
	        jButton3.setText("Salir Sin Modificar");
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addComponent(jLabel4, GroupLayout.PREFERRED_SIZE, 113, Short.MAX_VALUE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                        .addComponent(jTextField4, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
                    		.addComponent(jLabel1, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    		.addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
                    	.addGroup(jPanel1Layout.createSequentialGroup()
                    		.addComponent(jLabel5, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    		.addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()	                        
	                        .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
	                    	.addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
		                    .addComponent(jLabel3, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
	                    	.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
		                    .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)))	                            	                            
	                .addContainerGap())
	            .addGroup(jPanel1Layout.createSequentialGroup()
	            	.addContainerGap()
	                .addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)
	                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
	                .addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap())
	            .addGroup(jPanel1Layout.createSequentialGroup()
		            .addContainerGap()
	            	.addGap(91, 91, 91)
	            	.addComponent(jButton3, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)
	            	.addGap(91, 91, 91)
	            	.addContainerGap())
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel1)
	                    .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                	.addComponent(jLabel2)
		                .addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
	                .addGap(16, 16, 16)	                
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel3)
	                    .addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
		                .addComponent(jLabel4)
	                	.addComponent(jTextField4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
	                .addGap(16, 16, 16)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
			            .addComponent(jLabel5)
	                	.addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
	                .addGap(14, 14, 14)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jButton1)
	                    .addComponent(jButton2))
	                .addGap(12, 12, 12)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jButton3))
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap())
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
		}
		
        public void CerrarVentana(java.awt.event.WindowEvent event) {
        	dispose();
        }       
	}
	
	public class VentanaAccesoBD extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JLabel jLabel1, jLabel2;
		private JButton jButton1;
		private JTextField jTextField1;
		private JPasswordField jPasswordField1;
		private JPanel jPanel1;
		
		public VentanaAccesoBD() {
			
//	 		Opciones De Ventana De Opci�n "Conectar" del Menu Base De Datos
			
	        jPanel1 = new JPanel();
	        jLabel1 = new JLabel();
	        jLabel2 = new JLabel();
	        jButton1 = new JButton();
	        jTextField1 = new JTextField();
	        jPasswordField1 = new JPasswordField();

	        setTitle("Acceso A La Base De Datos");
			setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(321, 300, 335, 180));
	        setFocusCycleRoot(false);
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");
	        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel1.setText("Nombre Usuario");

	        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel2.setText("Contrase\u00f1a");

	        jButton1.setText("Aceptar");

	        jTextField1.setText("jTextField1");

	        jPasswordField1.setText("jPasswordField1");
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
	                            .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
	                            .addComponent(jLabel1, GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE))
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
	                            .addComponent(jPasswordField1)
	                            .addComponent(jTextField1, GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE))
	                        .addContainerGap())
	                    .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
	                        .addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
	                        .addGap(97, 97, 97))))
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel1)
	                    .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
	                .addGap(13, 13, 13)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel2)
	                    .addComponent(jPasswordField1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
	                .addGap(14, 14, 14)
	                .addComponent(jButton1)
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );			
		}
		
        public void CerrarVentana(java.awt.event.WindowEvent event) {
        	dispose();
        }
	}
	
	public class VentanaCargarContactos extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JLabel jLabel1;
		private JButton jButton1;
		private JComboBox jComboBox1;
		private JPanel jPanel1;
		
		public VentanaCargarContactos() {
			
//	 		Opciones De Ventana "Cargar Contactos" Del Boton Cargar (Contactos) De La Ventana Principal
	
	        jPanel1 = new JPanel();
	        jLabel1 = new JLabel();
	        jButton1 = new JButton();
	        jComboBox1 = new JComboBox();

	        setTitle("Cargar Grupo De Contactos");
			setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(339, 291, 300, 185));
	        setFocusCycleRoot(false);
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");
	        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel1.setText("Seleccionar Grupo De Contactos");
//	        jLabel1.setBorder(BorderFactory.createEtchedBorder());

			for (int i=0;i<Inicio.GrupoContactos.size();i++) {
				jComboBox1.addItem(Inicio.GrupoContactos.get(i));	
			}
			
	        jButton1.setText("Aceptar");
	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton1ActionPerformed(evt);
	            }
	        });
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                        .addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 243, GroupLayout.PREFERRED_SIZE)
	                        .addContainerGap())
	                    .addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.CENTER, false)
	                        	.addGroup(jPanel1Layout.createSequentialGroup()
	                        		.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE))
	                            .addComponent(jComboBox1, GroupLayout.Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE))
	                        .addGap(78, 78, 78))))
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jLabel1)
	                .addGap(16, 16, 16)
	                .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
	                .addGap(17, 17, 17)
	                .addComponent(jButton1)
	                .addContainerGap(19, GroupLayout.PREFERRED_SIZE))
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
	                .addContainerGap())
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
		}
		
	    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {  
			Inicio.CargarContactos(jComboBox1.getSelectedItem(), GUI.SampleModel);
			//CargarContactos.StringjComboBox1 = StringjComboBox1 + "a";   
			//CargarContactos.jComboBox1.setModel(new DefaultComboBoxModel(new String[] { "Art\u00edculo 1", "Art\u00edculo 2", "Art\u00edculo 3", "Art\u00edculo 4" }));
			setVisible(false);
	    }
		
        public void CerrarVentana(java.awt.event.WindowEvent event) {
        	dispose();
        }
	}
	
	public class VentanaGuardarContactos extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JLabel jLabel1, jLabel2;
		private JButton jButton1;
		private JTextField jTextField1;
		private JComboBox jComboBox1;
		private JPanel jPanel1;
		
		public VentanaGuardarContactos() {
			
//	 		Opciones De Ventana "Guardar Contactos" Del Boton Guardar (Contactos) De La Ventana Principal			
			
	        jPanel1 = new JPanel();
	        jLabel1 = new JLabel();
	        jLabel2 = new JLabel();
	        jButton1 = new JButton();
	        jTextField1 = new JTextField();
	        jComboBox1 = new JComboBox();

	        setTitle("Guardar Grupo De Contactos");
			setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(339, 291, 300, 185));
	        setFocusCycleRoot(false);
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");
	        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel1.setText("Grupo Nuevo");

	        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel2.setText("Grupo Actual");

	        jButton1.setText("Aceptar");
	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                jButton1ActionPerformed(evt);
	            }
	        });
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

	        jTextField1.setText("");

//	        jComboBox1.setModel(new DefaultComboBoxModel(new String[] { "Art\u00edculo 1", "Art\u00edculo 2", "Art\u00edculo 3", "Art\u00edculo 4" }));
			for (int i=0;i<Inicio.GrupoContactos.size();i++) {
				jComboBox1.addItem(Inicio.GrupoContactos.get(i));	
			}

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
		                    .addGap(36, 36, 36)
	                    	.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                            .addComponent(jLabel2, GroupLayout.DEFAULT_SIZE, 120, GroupLayout.DEFAULT_SIZE)
	                            .addComponent(jLabel1, GroupLayout.DEFAULT_SIZE, 120, GroupLayout.DEFAULT_SIZE))
	                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 5, GroupLayout.PREFERRED_SIZE)
	                        .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
	                            .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)
	                            .addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE))
			                .addGap(36, 36, 36))         
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                    	.addGap(84, 84, 84)
	                        .addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)))
	                .addContainerGap())
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
		                .addComponent(jLabel2)
		                .addComponent(jComboBox1, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE))
	                .addGap(18, 18, 18)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                	.addComponent(jLabel1)
		                .addComponent(jTextField1))
	                .addGap(18, 18, 18)
	                .addComponent(jButton1)
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
		}

//		private Object makeObj(String item)  {
//			return new Object() { public String toString() { return item; } };
//		}
		
	    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {  
	    	if (!(jTextField1.getText().compareTo("") == 0)) {
	    		Inicio.GuardarContactos(GUI.jList1.getSelectedIndices(), jTextField1.getText(),0);
	    	}
	    	else {
	    		Inicio.GuardarContactos(GUI.jList1.getSelectedIndices(), jComboBox1.getSelectedItem().toString(),1);
	    	}
			//CargarContactos.StringjComboBox1 = StringjComboBox1 + "a";   
			//CargarContactos.jComboBox1.setModel(new DefaultComboBoxModel(new String[] { "Art\u00edculo 1", "Art\u00edculo 2", "Art\u00edculo 3", "Art\u00edculo 4" }));
			setVisible(false);
	    }
        
	    public void CerrarVentana(java.awt.event.WindowEvent event) {
        	dispose();
        }
	}
	
	public class VentanaAcercaDe extends JDialog {

		private static final long serialVersionUID = 1L;
		
		private JLabel jLabel1, jLabel2, jLabel3;
		private JButton jButton1;
		private JPanel jPanel1;
		
		public VentanaAcercaDe() {
			
//	 		Opciones De Ventana "Mi Trabajo Final de Carrera" del Menu Acerca De
			
	        jPanel1 = new JPanel();
	        jLabel1 = new JLabel();
	        jLabel2 = new JLabel();
	        jLabel3 = new JLabel();
	        jButton1 = new JButton();
	        
	        setTitle("Acerca De Mi Trabajo Final De Carrera");
			setModalityType(java.awt.Dialog.ModalityType.APPLICATION_MODAL);
	        setResizable(false);
	        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
	        setBounds(new java.awt.Rectangle(289, 235, 400, 300));
	        jPanel1.setBorder(BorderFactory.createEtchedBorder());
	        jPanel1.setName("");

	        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 24));
	        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel1.setText("Servidor de SMS");
	        
	        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12));
	        jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel2.setText("Maurix Corp");

	        jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
	        jLabel3.setText("Version 1.0");

	        jButton1.setText("Aceptar");
	        jButton1.setHorizontalTextPosition(SwingConstants.CENTER);
/*	        jButton1.addActionListener(new java.awt.event.ActionListener() {
	        	public void actionPerformed(java.awt.event.ActionEvent evt) {
	        		jButton3ActionPerformed(evt);
	        	}
	        });*/
	        
	        addWindowListener( new java.awt.event.WindowAdapter() {
	        	public void windowClosing(java.awt.event.WindowEvent event) {
	        		CerrarVentana(event);
	        	}
	        });

	        GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
	        jPanel1.setLayout(jPanel1Layout);
	        jPanel1Layout.setHorizontalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	                    .addGroup(jPanel1Layout.createSequentialGroup()
		                  //.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                    		.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 343, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
			              //.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
	                    	.addComponent(jLabel2, GroupLayout.PREFERRED_SIZE, 343, GroupLayout.PREFERRED_SIZE))
	                    .addGroup(jPanel1Layout.createSequentialGroup()
			              //.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
	                    	.addComponent(jLabel3, GroupLayout.PREFERRED_SIZE, 343, GroupLayout.PREFERRED_SIZE))	                    	
	                    .addGroup(jPanel1Layout.createSequentialGroup()
	                    	.addGap(121, 121, 121)
	                    	.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 101, GroupLayout.PREFERRED_SIZE)
	                    	.addGap(121, 121, 121)))
	                .addContainerGap())
	        );
	        jPanel1Layout.setVerticalGroup(
	            jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(jPanel1Layout.createSequentialGroup()
	                .addContainerGap()
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel1))
	                .addGap(13, 13, 13)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel2))
   	                .addGap(13, 13, 13)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                	.addComponent(jLabel3))
	                .addGap(15, 15, 15)
	                .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
	                    .addComponent(jButton1))
	                .addContainerGap())
	        );

	        GroupLayout layout = new GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addContainerGap()
	                .addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
	                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
	        );
		}
		
		public void CerrarVentana(java.awt.event.WindowEvent event) {
	    	dispose();
	    }
	}
	
	// Otras Ventanas...
	
}

