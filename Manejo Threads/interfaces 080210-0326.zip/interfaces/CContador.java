package interfaces;

public class CContador extends Thread {

	int Valor;
		
	public CContador() {
		Valor = 0; // Minutos del Contador
	}

	public int ObtenerContador() { return Valor; }
	
	public void run() {
		while (Valor < 15) {
			try { sleep(60000); } catch (Exception e) {}
			Valor++;
		}
	}
}
