package interfaces;

//import CMessage;
//import CService;

public class Productor {
	
	private ColaSalida Cola2;
	public int idsal = 100;
	InterfazPreFinal V1;
	
	public Productor (ColaSalida Cola11, InterfazPreFinal V11) {
		Cola2 = Cola11;
		V1 = V11;
	}

	public void EnvioSMS(String Envio, String Cel) {
		//System.out.println("Productor: Duermo Productor 23 Segundos...");
		//try { sleep(23000); } catch (Exception e) {}
		//String Envio = "Mauro, al final te quedas para la despedida del gordo? Saludos.";
		String NroCel = "+";
		//System.out.println("Cel: " + Cel);
		//Nrocel.concat(Cel);
		NroCel = "+" + Cel;
		//System.out.println("NroCel: " + NroCel);
		COutgoingMessage msgsal = new COutgoingMessage(NroCel, Envio, idsal);
		V1.FijoTexto1("Envio Mensaje: \n" + Envio);
		V1.FijoTexto1("Envio Mensaje a: " + NroCel);
		msgsal.setMessageEncoding(CMessage.MESSAGE_ENCODING_UNICODE);
		System.out.println(msgsal);
		Cola2.Agregar(msgsal);
		System.out.println("Productor: Mande Mensaje a la Cola...");
		V1.FijoTexto1("Productor: Mande Mensaje a la Cola...");
		System.out.println("Productor: Tama�o Cola Salida: "+Cola2.Tama�oCola());
		V1.FijoTexto1("Productor: Tama�o Cola Salida: "+Cola2.Tama�oCola());
	}
	//public static void main(String[] args) {
	//}

}
