package interfaces;

import java.util.*;

public class CProtocolMessage extends CMessage {
	/**
		This class represents a Protocol Message Between The InterfazHWVer3 & Consumidor
	*/
	public static final int CLASS_ALL = 0;	
	public static final int CLASS_REC_UNREAD = 1;
	public static final int CLASS_REC_READ = 2;
	public static final int CLASS_STO_UNSENT = 3;
	public static final int CLASS_STO_SENT = 4;

	public CProtocolMessage(Date date, String originator, String text, int memindex, int superid) {
		super(TYPE_PROTOCOL, date, originator, null, text, memindex , superid);
	}

	public void setOriginator(String originator) { this.originator = originator; }
	
	public String getOriginator() { return originator; }

}


