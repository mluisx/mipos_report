package interfaces;

import java.util.Calendar;
import java.util.Date;

public class ProbarCosas {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		
		Date Fecha = new Date();
		//Calendar Ort = null;
		//Ort.setTime(Fecha);
        Date now = Calendar.getInstance().getTime();
        System.out.println("Calendar.getInstance().getTime() : " + now);
        System.out.println();
		System.out.println("DATE() = " + Fecha);
		//System.out.println("CALENDAR() = " + Ort.getTime());
		// TODO Auto-generated method stub

	}

}
