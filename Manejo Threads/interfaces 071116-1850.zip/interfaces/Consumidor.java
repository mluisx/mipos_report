package interfaces;

public class Consumidor extends Thread {

	private ColaEntrada Cola1;
	public CMessage msginput;
	public int flag = 0;
	
	public Consumidor (ColaEntrada Cola11) {
		Cola1 = Cola11;
	}
	
	public void ModificarFlag (int alta) {
		flag = alta;
	}
	
	public int ObtenerFlag () {
		return flag;
	}
	
	public void run(){
		
		int corrida = 1, superid = 0, memIndexVar = 1;
		//boolean Conexion = false;
		//CIncomingMessage msg;
		System.out.println("Tama�o Cola: "+Cola1.Tama�oCola());
		System.out.println("Consumidor: Duermo Consumidor 30 Segundos...");
		//try { sleep(30000); } catch (Exception e) {}
		while (corrida < 250) {
		//while (corrida < 4) {
			if (flag == 1) {
				if (Cola1.Tama�oCola()>0) {
					// Saco el mensaje de la cola y lo imprimo en pantalla
					// msginput = Cola1.Sacar();
					for (int i = 1; i < 2 ; i++){
						// msg = Cola1.Obtener(i);
						msginput = Cola1.Sacar();
						superid = msginput.getId();
						memIndexVar = msginput.getMemIndex();		
						System.out.println("Consumidor: ID SMS: "+superid);
						System.out.println("Consumidor: MEM INDEX: "+memIndexVar);
						System.out.println(msginput);
						if (msginput.getText().contains("Testeo 5")){
							System.out.println("Ringgggggggg...Alarma...!!!");
						}
					}
					System.out.println("Consumidor: Saque un mensaje de la cola");
					System.out.println("Consumidor: Tama�o Cola: " + Cola1.Tama�oCola());
				}
			}
			System.out.println("Consumidor: Duermo Consumidor 10 Segundos...");
			try { sleep(10000); } catch (Exception e) {}
			corrida++;
			//if (Maurix.
		}
		System.out.println("Termina Consumidor");
	}
}
