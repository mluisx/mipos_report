package interfaces;

import java.util.LinkedList;

public class CInicio {

	public CInicio(InterfazGrafica V1){
		
		this.V1 = V1;
		ListaContactos = new LinkedList<CContacto>();
		GrupoContactos = new LinkedList<Object>();
		ListaReservas  = new LinkedList<Integer>();
		BD = V1.BD;
		Cola1 = new ColaEntrada();
		Cola2 = new ColaSalida();
		Maurix = new InterfazHard(Cola1, Cola2);
		Consu = new Consumidor(Cola1,BD,this);
		Prod = new Productor(Cola2, this);
		ModeloLista2 = V1.ModeloLista2; //Cargo El Modelo Que Uso Para La Lista De Reservas	
		CodigoReserva = 0; //Inicializo El Nro De Reserva Que Muestro En La Lista De Reservas
		Reserva = null;
//		Contador = new CContador();
	
	};
	
	public InterfazGrafica V1;
	public Consumidor Consu;
	public Productor Prod;
	public CBaseDatos BD;
	public ColaEntrada Cola1;
	public ColaSalida  Cola2;
	public LinkedList<CContacto> ListaContactos;
	public LinkedList<Object> GrupoContactos;
	public LinkedList<Integer> ListaReservas;
	public CContacto Contacto;
	public InterfazHard Maurix;
	public javax.swing.DefaultListModel ModeloLista2;
	public int CodigoReserva;
	public CReserva Reserva;
//	public CContador Contador;
	
	public void Conexion() {
		FijoTexto2("Cola de Entrada: Activado");
		FijoTexto2("Cola de Salida : Activado");
		FijoTexto2("Interfaz HW : Activado");
		FijoTexto2("Consumidor : Activado");
		FijoTexto2("Productor : Activado");
		Maurix.start();
		Consu.start();
		FijoTexto2("Interfaz de Hardware Con Cel Iniciado");		
	}
	
	public void Desconexion(){
		Maurix.Desconectar();
	}
	
//	public void AjustoConsu(Consumidor Consu){this.Consu = Consu;}
//	public void AjustoProd(Productor Prod){this.Prod = Prod;}

	public int ActivoConsumidor() {
		int i = Consu.ObtenerFlag();
		if (i == 0) { 
			Consu.ModificarFlag(1);
			System.out.println("Consumidor Activado");
//			V1.jRadioButton1.setSelected(true);
		}
		else { 
			Consu.ModificarFlag(0);
			System.out.println("Consumidor Desactivado");
//			V1.jRadioButton1.setSelected(false);
		}
	return i;
	}
	
    public void FijoTexto1(String Texto){
    	String Temp = V1.jTextArea1.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	V1.jTextArea1.setText(Temp);
    }
    
    public void FijoTexto2(String Texto){
    	String Temp = V1.jTextArea2.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	V1.jTextArea2.setText(Temp);
    }
    
/*  public void FijoTexto3(String Texto){
    	String Temp = V1.jTextArea3.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	V1.jTextArea3.setText(Temp);
    }*/
    
    public void HabilitoConexion(){
    	V1.jMenuItem2.setEnabled(false);
    	V1.jMenuItem1.setEnabled(true);	
    }
	
	public void EnviarMensaje(int indice[]) {
		String Envio = V1.jTextArea1.getText();
		for (int i=0;i<indice.length;i++) {
			Contacto = ListaContactos.get(indice[i]);
			String Cel = Contacto.ObtenerNumeroCel();
			System.out.println("Numero a Enviar : " + Cel);
			Cel = "+" + Cel;
			Prod.EnvioSMS(Envio,Cel);
		}
	}
	
	public void ProcesarSMSTipo1(CDatos Datos) {
		String Envio, Cel;
		int TipoDato = 10;
		Cel = Datos.ObtenerNroCelOrigen();
		System.out.println("NUMERO DE CEL DE PERSONA QUE HIZO PEDIDO: " + Cel);
		Envio = BD.BuscoVuelo(Datos);
		System.out.println("Envio Al Que Hizo Pedido: " + Envio);
		BD.AlmacenoPedido(Datos);
		BD.AlmacenoSMSSalientes(Datos, Envio, TipoDato);
//		(MODIF) Las Variables Envio y Cel Junto a la Variable TipoDato ponerlas todas en una sola variable global
//		ActivoContador();
//		Contador = new CContador();
//		Contador.run();
//		Prod.EnvioSMS(Envio,Cel);
	}
	
	public void ProcesarSMSTipo2(CDatos Datos) {
		String Envio, Cel;
		int TipoDato = 10;
		Cel = Datos.ObtenerNroCelOrigen();
		System.out.println("NUMERO DE CEL DE PERSONA QUE HIZO PEDIDO: " + Cel);
		Envio = BD.BuscoVueloIdaRetorno(Datos);
		System.out.println("Envio Al Que Hizo Pedido: " + Envio);
		BD.AlmacenoPedido(Datos);
		BD.AlmacenoSMSSalientes(Datos, Envio, TipoDato);
//		ActivoContador();
//		Contador = new CContador();
//		Contador.run();
//		Prod.EnvioSMS(Envio,Cel);
	}
	
	public void ProcesarSMSTipo4(CDatos Datos) {
		String Envio, Cel;
		int TipoDato = 13;
		Cel = Datos.ObtenerNroCelOrigen();
//		Envio = BD.BuscoTipoAyuda(Datos);
		System.out.println("NUMERO DE CEL DE PERSONA QUE HIZO PEDIDO DE AYUDA: " + Cel);
		Envio = "Bienvenido a IguazuAir - Para ver vuelos disponibles, env�e \"Vuelo\" + \"Desde\" + \"Ciudad Origen\" + \"Ciudad Destino\" + \"Fecha Ida\" + \"Fecha Retorno\" (opcional)";
		System.out.println("Envio Al Que Hizo Pedido: " + Envio);
//		Verificar si la ayuda es del tipo 1 o 2 viendo las filas de la tabla pedidos (MODIF)
//		Prod.EnvioSMS(Envio,Cel);
		Envio = "Bienvenido a IguazuAir - Para ver vuelos disponibles, env�e \\\"Vuelo\\\" + \\\"Desde\\\" + \\\"Ciudad Origen\\\" + \\\"Ciudad Destino\\\" + \\\"Fecha Ida\\\" + \\\"Fecha Retorno\\\" (opcional)";
		BD.AlmacenoSMSSalientes(Datos, Envio, TipoDato);
	}
	
	public void ProcesarSMSTipo8(CDatos Datos) {
		String Envio, Cel;
		int TipoDato = 15;
		Cel = Datos.ObtenerNroCelOrigen();
//		Envio = BD.BuscoTipoAyuda(Datos);
		System.out.println("NUMERO DE CEL DE PERSONA QUE HIZO PEDIDO ERRONEO DE VUELOS: " + Cel);
		Envio = "Para ver vuelos disponibles, env�e \"Vuelo\" + \"Desde\" + \"Ciudad Origen\" + \"Ciudad Destino\" + \"Fecha Ida\" + \"Fecha Retorno\" (El retorno es opcional)";
		System.out.println("Envio Al Que Hizo Pedido: " + Envio);
//		Verificar si la ayuda es del tipo 1 o 2 viendo las filas de la tabla pedidos (MODIF)
//		Prod.EnvioSMS(Envio,Cel);
		Envio = "Para ver vuelos disponibles, env�e \\\"Vuelo\\\" + \\\"Desde\\\" + \\\"Ciudad Origen\\\" + \\\"Ciudad Destino\\\" + \\\"Fecha Ida\\\" + \\\"Fecha Retorno\\\" (El retorno es opcional)";
		BD.AlmacenoSMSSalientes(Datos, Envio, TipoDato);
	}
	
	public void ProcesarSMSTipo9(CDatos Datos) {
		String Envio, Cel;
		int TipoDato = 16;
		Cel = Datos.ObtenerNroCelOrigen();
//		Envio = BD.BuscoTipoAyuda(Datos);
		System.out.println("NUMERO DE CEL DE PERSONA QUE MANDO SMS CONFIRMACION ERRONEO: " + Cel);
		Envio = "Env�e \"Reservar\" + \"Vuelo\" + \"Nro\" para confirmar reserva / Para estados de vuelos, env�e \"Estado\" + \"Vuelo\" + \"Nro\" / Para m�s vuelos env�e \"Otros Vuelos\"";
		System.out.println("Envio Al Que Hizo Pedido: " + Envio);
//		Verificar si la ayuda es del tipo 1 o 2 viendo las filas de la tabla pedidos (MODIF)
//		Prod.EnvioSMS(Envio,Cel);
		Envio = "Env�e \\\"Reservar\\\" + \\\"Vuelo\\\" + \\\"Nro\\\" para confirmar reserva / Para estados de vuelos, env�e \\\"Estado\\\" + \\\"Vuelo\\\" + \\\"Nro\\\" / Para m�s vuelos env�e \\\"Otros Vuelos\\\"";
		BD.AlmacenoSMSSalientes(Datos, Envio, TipoDato);
	}
	
	public void ProcesarSMSTipo10(CDatos Datos) {
		String Envio, Cel;
		int TipoDato = 17;
		Cel = Datos.ObtenerNroCelOrigen();
//		Envio = BD.BuscoTipoAyuda(Datos);
		System.out.println("NUMERO DE CEL DE PERSONA QUE HIZO PEDIDO AYUDA ESTADOS DE VUELOS: " + Cel);
		Envio = "Bienvenido a IguazuAir - Para conocer el estado de su vuelo, env�e las palabras \"Estado\" + \"Vuelo\" + \"Nro De Vuelo\"";
		System.out.println("Envio Al Que Hizo Pedido: " + Envio);
//		Verificar si la ayuda es del tipo 1 o 2 viendo las filas de la tabla pedidos (MODIF)
//		Prod.EnvioSMS(Envio,Cel);
		Envio = "Bienvenido a IguazuAir - Para conocer el estado de su vuelo, env�e las palabras \\\"Estado\\\" + \\\"Vuelo\\\" + \\\"Nro De Vuelo\\\"";
		BD.AlmacenoSMSSalientes(Datos, Envio, TipoDato);
	}
	
//		Este Procedimiento todavia no lo uso (MODIF)
//		Borrar
	public void EnviarAyudaTipo2(CDatos Datos) {
		String Envio, Cel;
		int TipoDato = 13;
		Cel = Datos.ObtenerNroCelOrigen();
		System.out.println("NUMERO DE CEL DE PERSONA QUE HIZO PEDIDO ERRONEO: " + Cel);
		Envio = "Env�e \"Reservar\" + \"Vuelo\" + \"Nro\" para confirmar reserva / Para conocer estados de vuelos, env�e \"Estado\" + \"Vuelo\" + \"Nro\" / Para m�s vuelos env�e \"Otros Vuelos\"";
		System.out.println("Envio Al Que Hizo Pedido: " + Envio);
		BD.AlmacenoSMSSalientes(Datos, Envio, TipoDato);
//		Prod.EnvioSMS(Envio,Cel);
	}
//		Borrar (MODIF)
	
	public void ProcesarSMSTipo5(CDatos Datos) {
		String Envio, Cel, Agrego;
		int TipoDato = 14;
//		Envio = "CONFIRMO VUELO";
		Envio = BD.ConfirmarVuelo(Datos);
		Cel = Datos.ObtenerNroCelOrigen();
		System.out.println("NUMERO DE CEL DE PERSONA QUE HIZO PEDIDO DE CONFIRMACION: " + Cel);
		System.out.println("Envio Al Que Hizo Pedido: " + Envio);
		BD.AlmacenoSMSSalientes(Datos, Envio, TipoDato);
//		Contacto = new CContacto(Nombre, NumeroCel);
//		ListaContactos.add(Contacto);
//  	Almaceno Reserva En BD - Tabla reservas
		if (CodigoReserva!=0) { 
			Agrego = "Cel: " + Cel + " - Reserva Nro: " + CodigoReserva;
			ModeloLista2.addElement(Agrego);
			ListaReservas.add(CodigoReserva);
			BD.AlmacenoReserva(Datos);
		}
//		Prod.EnvioSMS(Envio,Cel);
	}
/*	
	public void ProcesarSMSTipo6(CDatos Datos) {
		String Envio, Cel;
		Cel = Datos.ObtenerNroCelOrigen();
		System.out.println("NUMERO DE CEL DE PERSONA QUE HIZO PEDIDO: " + Cel);
//		Envio = BD.BuscoVuelo(Datos);
//		System.out.println("Envio Al Que Hizo Pedido: " + Envio);
//		Prod.EnvioSMS(Envio,Cel);	
	}*/
	
	public void ProcesarSMSTipo7(CDatos Datos) {
		String Envio, Cel;
		int TipoDato = 12;
		Cel = Datos.ObtenerNroCelOrigen();
		System.out.println("NUMERO DE CEL DE PERSONA QUE HIZO PEDIDO DE ESTADOS DE VUELOS: " + Cel);
		Envio = BD.BuscoEstadoVuelo(Datos);
		System.out.println("Envio Al Que Hizo Pedido: " + Envio);
		BD.AlmacenoPedido(Datos);
		BD.AlmacenoSMSSalientes(Datos, Envio, TipoDato);
//		Prod.EnvioSMS(Envio,Cel);	
	}

//	Verificar si el mensaje con error es de un cliente que ya hizo un pedido de vuelos o si proviene de un celular cualquiera (MODIF)
	public void ProcesarSMSTipo3(CDatos Datos) {
		String Envio, Cel;
		int TipoDato = 16;
		int TipoError;
		Cel = Datos.ObtenerNroCelOrigen();
		TipoError = BD.BuscoTipoAyuda(Datos);
		System.out.println("NUMERO DE CEL DE PERSONA QUE MANDO SMS ERRONEO TOTAL: " + Cel);
		if (TipoError==2) {
        	Envio = "Env�e \"Reservar\" + \"Vuelo\" + \"Nro\" para confirmar reserva / Para estados de vuelos, env�e \"Estado\" + \"Vuelo\" + \"Nro\" / Para m�s vuelos env�e \"Otros Vuelos\"";
			System.out.println("Envio Al Que Hizo Pedido: " + Envio);
//			Prod.EnvioSMS(Envio,Cel);			
        	Envio = "Env�e \\\"Reservar\\\" + \\\"Vuelo\\\" + \\\"Nro\\\" para confirmar reserva / Para estados de vuelos, env�e \\\"Estado\\\" + \\\"Vuelo\\\" + \\\"Nro\\\" / Para m�s vuelos env�e \\\"Otros Vuelos\\\"";
			BD.AlmacenoSMSSalientes(Datos, Envio, TipoDato);
		}
		else {
			System.out.println("Se Recibio Un SMS Basura De Esta Persona");
		}
//		Verificar si la ayuda es del tipo 1 o 2 viendo las filas de la tabla pedidos (MODIF)
//		Prod.EnvioSMS(Envio,Cel);
	}
	
	public void IngresoContacto(String Nombre, String NumeroCel, javax.swing.DefaultListModel SModel) {
		Contacto = new CContacto(Nombre, NumeroCel);
		ListaContactos.add(Contacto);
		String Agrego = Contacto.ObtenerNombre() + " : " + Contacto.ObtenerNumeroCel();
	    SModel.addElement(Agrego);
    }

	public void BorrarContacto(int indice[], javax.swing.DefaultListModel SModel) {
		for (int i=0;i<indice.length;i++) {
			System.out.println("Indice: " + indice[i]);
			ListaContactos.remove(indice[i]-i);
			SModel.remove(indice[i]-i);
		}
	}

//  Creo Un M�todo Para Pasar Strings a Objetos y Poder Grabarlos En Una Cola De Objetos De Nombres De Grupos De Contactos
	
	public Object makeObj(final String item) { 
	return new Object() { 
		public String toString() { return item; } };
	}	

//  Guardo Contactos Seleccionados En La BD Con Un Nombre De Grupo
	
	public void GuardarContactos(int indice[], String NombreGrupo, int flag) {
		int Resultado = 0;
		for (int i=0;i<indice.length;i++) {
			String Cel, Nombre;
			Contacto = ListaContactos.get(indice[i]);
			Cel = Contacto.ObtenerNumeroCel();
			Nombre = Contacto.ObtenerNombre();
			Resultado = Resultado + BD.AlmacenoContacto(NombreGrupo,Nombre,Cel);
		}
		if (Resultado == indice.length && Resultado != 0 && flag == 0) {
			GrupoContactos.add(makeObj(NombreGrupo));
		}
		else if (indice.length == 0) {
			System.out.println("Debe Seleccionar Contactos Para Poder Guardarlos En Un Grupo");
		}
	}
	
//  Cargo Grupo De Contactos Almacenado En La BD En Ventana Principal
	
	public void CargarContactos(Object Grupo,javax.swing.DefaultListModel SModel) {
		String NombreGrupo = Grupo.toString();
		BD.CargarContactos(NombreGrupo, SModel);
	}

	
	public void ImprimirConsolaConsumidor(String Texto) {
		String TextoFull;
		TextoFull = V1.jTextArea6.getText();
    	if (TextoFull.length() > 0) {TextoFull = TextoFull + "\n";}
    	TextoFull = TextoFull + Texto;
    	V1.jTextArea6.setText(TextoFull);
	}
	
	public void ImprimirConsolaProductor(String Texto) {
		String TextoFull;
		TextoFull = V1.jTextArea7.getText();
    	if (TextoFull.length() > 0) {TextoFull = TextoFull + "\n";}
    	TextoFull = TextoFull + Texto;
    	V1.jTextArea7.setText(TextoFull);
	}
	
	public void ImprimirConsolaReservas(String Texto) {
		String TextoFull;
		TextoFull = V1.jTextArea9.getText();
    	if (TextoFull.length() > 0) {TextoFull = TextoFull + "\n";}
    	TextoFull = TextoFull + Texto;
    	V1.jTextArea9.setText(TextoFull);
	}
	
	public void ImprimirReserva(int indice[]) {
		for (int i=0;i<indice.length;i++) {
			Reserva = BD.BuscoReserva(ListaReservas.get(indice[i]));
			ImprimirConsolaReservas("-----------------/ Reserva Nro " + Reserva.ObtenerNroPedido() + " /-----------------");
			ImprimirConsolaReservas("Cliente: " + Reserva.ObtenerCliente());
			ImprimirConsolaReservas("Numero Celular: " + Reserva.ObtenerNroCelular());
			ImprimirConsolaReservas("Numero Vuelo 1: " + Reserva.ObtenerVuelo1());
			ImprimirConsolaReservas("Fecha Salida: " + Reserva.ObtenerFechaSalidaVuelo1());
			ImprimirConsolaReservas("Fecha Llegada: " + Reserva.ObtenerFechaLlegadaVuelo1());
			ImprimirConsolaReservas("Hora Salida: " + Reserva.ObtenerHorarioSalidaVuelo1());
			ImprimirConsolaReservas("Hora Llegada: " + Reserva.ObtenerHorarioLlegadaVuelo1());
			ImprimirConsolaReservas("Ciudad Origen: " + Reserva.ObtenerCiudadOrigenVuelo1());
			ImprimirConsolaReservas("Ciudad Destino: " + Reserva.ObtenerCiudadDestinoVuelo1());
			ImprimirConsolaReservas("Precio: " + Reserva.ObtenerPrecioVuelo1());
			ImprimirConsolaReservas("Asientos Libres: " + Reserva.ObtenerAsientosLibresVuelo1());
			ImprimirConsolaReservas("Tipo Avion: " + Reserva.ObtenerAvionVuelo1());
			ImprimirConsolaReservas("Estado Vuelo: " + Reserva.ObtenerEstadoVuelo1());
			if (!(Reserva.ObtenerVuelo2().compareTo("-") == 0 )) {
				ImprimirConsolaReservas("Numero Vuelo 2: " + Reserva.ObtenerVuelo2());
				ImprimirConsolaReservas("Fecha Salida: " + Reserva.ObtenerFechaSalidaVuelo2());
				ImprimirConsolaReservas("Fecha Llegada: " + Reserva.ObtenerFechaLlegadaVuelo2());
				ImprimirConsolaReservas("Hora Salida: " + Reserva.ObtenerHorarioSalidaVuelo2());
				ImprimirConsolaReservas("Hora Llegada: " + Reserva.ObtenerHorarioLlegadaVuelo2());
				ImprimirConsolaReservas("Ciudad Origen: " + Reserva.ObtenerCiudadOrigenVuelo2());
				ImprimirConsolaReservas("Ciudad Destino: " + Reserva.ObtenerCiudadDestinoVuelo2());
				ImprimirConsolaReservas("Precio: " + Reserva.ObtenerPrecioVuelo2());
				ImprimirConsolaReservas("Asientos Libres: " + Reserva.ObtenerAsientosLibresVuelo2());
				ImprimirConsolaReservas("Tipo Avion: " + Reserva.ObtenerAvionVuelo2());
				ImprimirConsolaReservas("Estado Vuelo: " + Reserva.ObtenerEstadoVuelo2());
			}
		}
	}
	
	public void BorrarReserva(int indice[]) {
		ImprimirConsolaReservas("-----------------/ Reserva Nro 12 /-----------------");
		ImprimirConsolaReservas("Cliente: ");
		ImprimirConsolaReservas("Numero Celular: ");
		ImprimirConsolaReservas("Numero Vuelo 1: ");
		ImprimirConsolaReservas("Fecha Salida: ");
		ImprimirConsolaReservas("Fecha Llegada: ");
		ImprimirConsolaReservas("Hora Salida: ");
		ImprimirConsolaReservas("Hora Llegada: ");
		ImprimirConsolaReservas("Ciudad Origen: ");
		ImprimirConsolaReservas("Ciudad Destino: ");
		ImprimirConsolaReservas("Precio: ");
		ImprimirConsolaReservas("Asientos Libres: ");
		ImprimirConsolaReservas("Tipo Avion: ");
		ImprimirConsolaReservas("Estado Vuelo: ");
	}
/*	public void EscriboLog(String S) throws IOException {
		FileOutputStream MyLog;
		MyLog = new FileOutputStream("Log.txt");
        int b = 0;
        int i = 0;
        while ((i < ( -1)) && 
                ( ( b = System.in.read() ) != '\n' ) )
                linea[i++] = (byte)b;
            linea[i] = (byte)0;
        }
        
		MyLog.write(b);
	}*/
}	




