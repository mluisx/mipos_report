package interfaces;

import java.sql.*;
import java.util.LinkedList;
import java.io.*; 

public class CBaseDatos {
	
	public String url, CiudadOrigen, CiudadDestino, FechaIda, FechaRetorno, CiudadOrigenRet, CiudadDestinoRet; 
	public String qs, HorarioSalida, HorarioLlegada, Envio, HorarioSalidaRet, HorarioLlegadaRet;
	public Statement stmt;
	public ResultSet rs;
	public Connection connection;
	public int NroVuelo, Precio, NroVueloRet, PrecioRet;
	public int PedidoNro = 1, Flag1 = 1;
	public int SMSSalida = 1;
	public CContador Contador;
	public CInicio Inicio;
	public CReserva Reserva;
	
	public CBaseDatos() {
		CiudadOrigen = CiudadDestino = FechaIda = FechaRetorno = CiudadOrigenRet = CiudadDestinoRet = "";
		HorarioSalida = HorarioLlegada = Envio = HorarioSalidaRet = HorarioLlegadaRet = "";
		NroVuelo = Precio = NroVueloRet = PrecioRet = 0;
		Contador = new CContador(this);
		Reserva  = new CReserva();
	};
	
	public void SetearDatos() {
		CiudadOrigen = CiudadDestino = FechaIda = FechaRetorno = CiudadOrigenRet = CiudadDestinoRet = "";
		HorarioSalida = HorarioLlegada = Envio = HorarioSalidaRet = HorarioLlegadaRet = "";
		NroVuelo = Precio = NroVueloRet = PrecioRet = 0;
	}
	
	public void activarbd() throws ClassNotFoundException,IOException  {
		
		try {

		Class.forName("com.mysql.jdbc.Driver");
        url = "jdbc:mysql://localhost/maurixdb?user=root&password=glendora";        
	    connection = DriverManager.getConnection(url);
        /*qs = "select * from usuarios";
        stmt = connection.createStatement();
        rs = stmt.executeQuery(qs);
        System.out.println("nombre"+"\t   "+"edad");           
	    while (rs.next()){   
	         	    System.out.println(rs.getString( "nombre" ) +"\t\t"+
	         	                           rs.getInt( "edad" ));
        } */        
		}
		
		catch (SQLException sqle) { 
		
			sqle.printStackTrace();
				
		while (sqle != null) {
			String logMessage = "\n SQL Error: "+
			sqle.getMessage() + "\n\t\t"+
			"Error code: "+sqle.getErrorCode() + "\n\t\t"+
			"SQLState: "+sqle.getSQLState()+"\n";
			System.out.println(logMessage);
			sqle = sqle.getNextException();
			}
		}
		
		// Limpio Las tablas pedidos - smsinbox - smsoutbox - reservas
		
		int Resultado = 0;
		try {
			qs = "delete from smsinbox";
			stmt = connection.createStatement();
			Resultado+= stmt.executeUpdate(qs);
			qs = "delete from smsoutbox";
			stmt = connection.createStatement();
			Resultado+= stmt.executeUpdate(qs);		
			qs = "delete from reservas";
			stmt = connection.createStatement();
			Resultado+= stmt.executeUpdate(qs);
			if (Resultado == 0) {
				System.out.println("YAHOO!");
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		try {
			qs = "select NroPedido from pedidos order by NroPedido desc";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) {
				PedidoNro = rs.getInt(1) + 1;
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public void desactivarbd() {
		try {
			rs.close();
			stmt.close();
			connection.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public String PasoMinusculas(String Ciudad) {
		int x=0,y=1;
		String Caracter = "";
		String MiniCiudad = Ciudad;
		MiniCiudad = MiniCiudad.toLowerCase();
		Ciudad = "";
		while (y < MiniCiudad.length()){
			Caracter = MiniCiudad.substring(x,y);
			Caracter = Caracter.toUpperCase();
			Ciudad = Ciudad + Caracter;
			x = y;
			y = MiniCiudad.indexOf(" ");
			if (y<0) {
				y = MiniCiudad.length();
				Ciudad = Ciudad + MiniCiudad.substring(x);
			}
			else {
				Ciudad = Ciudad + MiniCiudad.substring(x,y) + " ";
				MiniCiudad = MiniCiudad.substring(y+1);
				x = 0;
				y = 1;
			}
		}
		return Ciudad;
	}
	
/*	public int buscovuelo(CDatos Datos) { 
		CiudadOrigen = Datos.ObtenerCiudadOrigen();
		CiudadDestino = Datos.ObtenerCiudadDestino();
		try {
        	qs = "select * from vuelos where CodigoAeropuertoOrigen = ( " +
        				"select Codigo from aeropuertos where Ciudad = \"" + CiudadOrigen + "\" ) and CodigoAeropuertoDestino = ( " + 
        				"select Codigo from aeropuertos where Ciudad = \"" + CiudadDestino + "\" )";
        	stmt = connection.createStatement();
            rs = stmt.executeQuery(qs);
            rs.next();
            NroVuelo = rs.getInt("NroVuelo");
        } catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	    return NroVuelo;
	}*/
//  TENGO QUE VER EL CASO DE VARIOS VUELOS EN TABLA (Muestra los 3 vuelos mas baratos - A partir del vuelo 4 se complica)	
	public String BuscoVuelo(CDatos Datos) {
		int filas = 0;
		SetearDatos();
		CiudadOrigen = Datos.ObtenerCiudadOrigen();
		CiudadDestino = Datos.ObtenerCiudadDestino();
		FechaIda = Datos.ObtenerFechaIda();
		try {
        	qs = "select * from vuelos where CodigoAeropuertoOrigen = ( " +
        				"select CodigoAeropuerto from aeropuertos where CodigoCiudad = ( select CodigoCiudad from ciudades where Ciudad = \"" + CiudadOrigen + "\" ) ) and CodigoAeropuertoDestino = ( " +        				
        				"select CodigoAeropuerto from aeropuertos where CodigoCiudad = ( select CodigoCiudad from ciudades where Ciudad = \"" + CiudadDestino + "\" ) ) and FechaSalida = \"" + FechaIda + "\" and AsientosLibres > 1 Order by Precio";
        	stmt = connection.createStatement();
            rs = stmt.executeQuery(qs);
            Envio = "IguazuAir ";
            while (rs.next()) {
            	filas++;
            	System.out.println("Busco Vuelo IDA - Numero de Fila En Curso: " + filas);
            	if (filas>0 && filas<4) {
            		if (filas == 1) {
                        CiudadOrigen = PasoMinusculas(CiudadOrigen);
                        CiudadDestino = PasoMinusculas(CiudadDestino);
            			Envio = Envio + "- " + CiudadOrigen + " a " + CiudadDestino + " - " + FechaIda;
            		}
            		NroVuelo = rs.getInt("NroVuelo");
            		HorarioSalida = rs.getString("HorarioSalida");
            		Precio = rs.getInt("Precio");
            		Envio = Envio + " - Vuelo " + NroVuelo + ", " + HorarioSalida + ", $" + Precio;
            		if (filas == 1) {Datos.FijoVuelo1(NroVuelo);}
            		else if (filas == 2) {Datos.FijoVuelo2(NroVuelo);}
            		else {Datos.FijoVuelo3(NroVuelo);}
//            		HorarioSalida = HorarioSalida.substring(0,5) + " Hs";
            	}
            }
        	if (filas == 0) {
        		Envio = Envio + "Le Informa Que No Hay Vuelos Disponibles Para El Destino y La Fecha Deseados";
        	}
        } catch (SQLException sqle) {
			sqle.printStackTrace();
		}
        return Envio;	
	}
//	TENGO QUE VER EL CASO DE VARIOS VUELOS EN TABLA	(Muestra 1 solo vuelo de ida y de retorno, siendo los dos vuelos los mas baratos disponibles)
	public String BuscoVueloIdaRetorno(CDatos Datos) {
		SetearDatos();
		CiudadOrigen = Datos.ObtenerCiudadOrigen();
		CiudadDestino = Datos.ObtenerCiudadDestino();
		FechaIda = Datos.ObtenerFechaIda();
		try {
        	qs = "select * from vuelos where CodigoAeropuertoOrigen = ( " +
        				"select CodigoAeropuerto from aeropuertos where CodigoCiudad = ( select CodigoCiudad from ciudades where Ciudad = \"" + CiudadOrigen + "\" ) ) and CodigoAeropuertoDestino = ( " + 
        				"select CodigoAeropuerto from aeropuertos where CodigoCiudad = ( select CodigoCiudad from ciudades where Ciudad = \"" + CiudadDestino + "\" ) ) and FechaSalida = \"" + FechaIda + "\" and AsientosLibres > 1 Order by Precio";
        	stmt = connection.createStatement();
            rs = stmt.executeQuery(qs);
            if (rs.next()) {    
            	NroVuelo = rs.getInt("NroVuelo");
            	HorarioSalida = rs.getString("HorarioSalida");
//           	HorarioSalida = HorarioSalida.substring(0,5) + " Hs";
            	Precio = rs.getInt("Precio");
            	Envio = "IguazuAir - Ida, Vuelo " + NroVuelo + ", " + PasoMinusculas(CiudadOrigen) + " a " + PasoMinusculas(CiudadDestino) + ", " + FechaIda + ", " + HorarioSalida + ", $" + Precio;
            	Datos.FijoVuelo1(NroVuelo);
            }
            else { 
        	Envio = "IguazuAir - No hay Vuelo Disponible Para La Fecha De Ida";
            }
        } catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	    CiudadOrigenRet = CiudadDestino;
	    CiudadDestinoRet = CiudadOrigen;
	    FechaRetorno = Datos.ObtenerFechaRetorno();
		try {
        	qs = "select * from vuelos where CodigoAeropuertoOrigen = ( " +
        				"select CodigoAeropuerto from aeropuertos where CodigoCiudad = ( select CodigoCiudad from ciudades where Ciudad = \"" + CiudadOrigenRet + "\" ) ) and CodigoAeropuertoDestino = ( " + 
        				"select CodigoAeropuerto from aeropuertos where CodigoCiudad = ( select CodigoCiudad from ciudades where Ciudad = \"" + CiudadDestinoRet + "\" ) ) and FechaSalida = \"" + FechaRetorno + "\" and AsientosLibres > 1 Order by Precio";
        	stmt = connection.createStatement();
            rs = stmt.executeQuery(qs);
            if (rs.next()) {
            	NroVueloRet = rs.getInt("NroVuelo");
            	HorarioSalidaRet = rs.getString("HorarioSalida");
//            	HorarioSalidaRet = HorarioSalidaRet.substring(0,5) + " Hs";
            	PrecioRet = rs.getInt("Precio");
            	Envio = Envio + " - Retorno, Vuelo " + NroVueloRet + ", " + PasoMinusculas(CiudadOrigenRet) + " a " + PasoMinusculas(CiudadDestinoRet) + ", " + FechaRetorno + ", " + HorarioSalidaRet + ", $" + PrecioRet;
            	Datos.FijoVuelo2(NroVueloRet);
            }
            else {
            	Envio = Envio + " - Para El Retorno No Hay Vuelos Disponibles";
            }
        } catch (SQLException sqle) {
			sqle.printStackTrace();
		}
        return Envio;				
	}
	
	public String BuscoEstadoVuelo(CDatos Datos) {
		SetearDatos();
		try {
			qs = "select * from vuelos where NroVuelo = " + Datos.ObtenerNroVuelo();
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) { 
            	HorarioSalida = rs.getString("HorarioSalida");
//				HorarioSalida = HorarioSalida.substring(0,5) + " Hs";
				Envio = "IguazuAir - Vuelo " + Datos.ObtenerNroVuelo() + " - " + rs.getString("FechaSalida") + " - " + HorarioSalida + " - Estado Del Vuelo: " + rs.getString("Estado");  
			}
			else {
				Envio = "IguazuAir - Vuelo " + Datos.ObtenerNroVuelo() + " - No Esta Programado En El Calendario De Vuelos";
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		return Envio;
	}
	
	public void AlmacenoPedido(CDatos Datos) {
		SetearDatos();
		int Resultado;
		String Cliente = "";
//		Verifico si el originador es cliente de la empresa
		try {
			qs = "select * from clientes where NroCelular = \"" + Datos.ObtenerNroCelOrigen() + "\"";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) { Cliente = "S"; }
			else { Cliente = "N"; }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
//		Arranco el contador que borra registros viejos
		if (Flag1 == 1) {
			Contador.start();
			Flag1 = 0;
		}
//		Almaceno pedido en Base de Datos
		if (Datos.ObtenerTipoDato() == 1 || Datos.ObtenerTipoDato() == 2) {
			try {
				qs = "insert into pedidos values (\"" + Datos.ObtenerNroCelOrigen() + "\",10," + Datos.ObtenerTipoDato() + ",\"" + Cliente +
				"\"," + PedidoNro + "," + Contador.ObtenerContador() + "," + Datos.ObtenerVuelo1() + "," + Datos.ObtenerVuelo2()+ "," + Datos.ObtenerVuelo3() + ")" ;
				stmt = connection.createStatement();
				Resultado = stmt.executeUpdate(qs);
				if (Resultado != 1 ) {
					System.out.println("Resultado BD: " + Resultado);            	
					System.out.println("Error Al Cargar Datos en BD - Tabla pedidos");
				}
				else { PedidoNro++; }
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		}
		if (Datos.ObtenerTipoDato() == 7) {
			try {
				qs = "insert into pedidos values (\"" + Datos.ObtenerNroCelOrigen() + "\",12," + Datos.ObtenerTipoDato() + ",\"" + Cliente +
				"\"," + PedidoNro + "," + Contador.ObtenerContador()+ ",0,0,0)" ;
				stmt = connection.createStatement();
				Resultado = stmt.executeUpdate(qs);
				if (Resultado != 1 ) {
					System.out.println("Resultado BD: " + Resultado);            	
					System.out.println("Error Al Cargar Datos en BD - Tabla pedidos");
				}
				else { PedidoNro++; }
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		}	
	}
	
	//Funciones Que No Utilizo Todavia (MODIF)
	public void ActualizoPedido(int TipoAct) {
		SetearDatos();	
	}
	
	public void BorrarPedido(int NroPedido)  {
		SetearDatos();
	}
	//Funciones Que No Utilizo Todavia (MODIF)
	
	public void BorrarPedidoPorTimeOut(long Tiempo) {
		int Resultado;
		try {
			qs = "delete from pedidos where Hora < " + Tiempo; 
			stmt = connection.createStatement();
			Resultado = stmt.executeUpdate(qs);
            if (Resultado != 0 ) {          	
            	System.out.println("Se Borraron " + Resultado + " pedidos");
            }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public void AlmacenoSMSEntrantes(CIncomingMessage SMS,CDatos Datos) {
		SetearDatos();
		int Resultado;
		try {
			qs = "insert into smsinbox values (" + SMS.getId() + "," + SMS.getMemIndex() + ",\"" + SMS.getText() + "\",\"" + SMS.getOriginator() +
			"\",\"" + Datos.ObtenerTipoTicket() + "\"," + Datos.ObtenerTipoDato() + ")";
        	stmt = connection.createStatement();
            Resultado = stmt.executeUpdate(qs);
            if (Resultado != 1 ) {
            	System.out.println("Resultado BD: " + Resultado);            	
            	System.out.println("Error Al Cargar Datos en BD - Tabla smsinbox");
            }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}

	// Almaceno SMS que son enviados a los clientes en la tabla smsoutbox
	public void AlmacenoSMSSalientes(CDatos Datos, String Texto, int TipoDato) {
		SetearDatos();
		int Resultado;
		try {
			qs = "insert into smsoutbox values (" + SMSSalida + ",\"" + Texto + "\"," + TipoDato + ")";
        	stmt = connection.createStatement();
            Resultado = stmt.executeUpdate(qs);
            if (Resultado != 1 ) {
            	System.out.println("Resultado BD: " + Resultado);            	
            	System.out.println("Error Al Cargar Datos en BD - Tabla smsoutbox");
            }
            else {
            	SMSSalida++;
            }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}

	// Actualizo tablas para confirmar el vuelo requerido por el usuario
	public String ConfirmarVuelo(CDatos Datos) {
		SetearDatos();
		int Resultado, CodigoReserva, Col, VueloReserva, Flag1, Flag2; //CodigoReserva es el NroPedido que se genero para el cliente y se almaceno en la tabla pedidos
		String Reserva1 ,Reserva2; //Los numeros de los vuelos a reservar
		Reserva1 = Reserva2 = "";
		Col = 7; Flag1 = Flag2 = 0;
		try {
			qs = "select * from pedidos where NroCelular = \"" + Datos.ObtenerNroCelOrigen() + "\" and TipoUltimoSMSEnviado = 10";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) {
				CodigoReserva = rs.getInt(5); 
//				Verifico nro vuelo si concuerda con pedido.
				VueloReserva = Integer.parseInt(Datos.ObtenerReserva());
				while (Col < 10) {					
					if (VueloReserva == rs.getInt(Col)) {Flag1 = 1;}
					Col++;
				}
				if (Flag1 == 1) {
					qs = "update vuelos set AsientosLibres = AsientosLibres - 1 where NroVuelo = " + Datos.ObtenerReserva();
					stmt = connection.createStatement();
					Resultado = stmt.executeUpdate(qs);
					if (Resultado == 1) {
						Reserva1 = Datos.ObtenerReserva();
						System.out.println("Se Actualizo Tabla Vuelos");
					}
				}
//				Verifico nro vuelo si concuerda con pedido.
				if (!Datos.ObtenerReserva2().isEmpty()) {
					Col = 7;
					VueloReserva = Integer.parseInt(Datos.ObtenerReserva2());
					while (Col < 10) {					
						if (VueloReserva == rs.getInt(Col)) {Flag2 = 1;}
						Col++;
					}
					if (Flag2 == 1) {
						qs = "update vuelos set AsientosLibres = AsientosLibres - 1 where NroVuelo = " + Datos.ObtenerReserva2(); 
						stmt = connection.createStatement();
						Resultado = stmt.executeUpdate(qs);
						if (Resultado == 1) {
							Reserva2 = Datos.ObtenerReserva2();
							System.out.println("Se Actualizo Tabla Vuelos");
						}
					}
				}
				if (!Reserva1.isEmpty() && !Reserva2.isEmpty()) {
					Datos.FijoCodigoReserva(CodigoReserva);
					Envio = "Sus Vuelos Nro " + Reserva1 + " y " + Reserva2 + " Han Sido Confirmados - Su Codigo De Reserva Es " + CodigoReserva + " - Un Agente Se Comunicara Con Usted En Las Proximas Horas - Muchas Gracias";					
				}
				else {
//					if (Reserva1.isEmpty()) { Reserva1 = Reserva2; }
					/*					if (!Reserva1.isEmpty() && Datos.ObtenerReserva2().isEmpty()) {
						Inicio.CodigoReserva = CodigoReserva;
						Envio = "Su Vuelo Nro " + Reserva1 + " Ha Sido Confirmado - Su Codigo De Reserva Es " + CodigoReserva + " - Un Agente Se Estara Comunicando Con Usted En Las Proximas Horas - Muchas Gracias";
					}
					else {
						System.out.println("No Se Actualiz� La Tabla Vuelos - Se Enviar� SMS De Error De Confirmaci�n"); // Aca tengo que ver que hago para volver atras las tablas (MODIF)
						if (!Datos.ObtenerReserva().isEmpty() && !Datos.ObtenerReserva2().isEmpty()) {
							Envio = "Sus Numeros De Vuelos Son Incorrectos, Por Favor, Env�e \"Reservar\" + \"Vuelo\" + \"NroVuelo1\" + \"Y\" + \"NroVuelo2\" Para Confirmar Las Reservas";
						}
						else {
							Envio = "Su Numero De Vuelo Es Incorrecto, Por Favor, Env�e \"Reservar\" + \"Vuelo\" + \"NroVuelo\" Para Confirmar La Reserva";
						}
					}
				}		
			}*/
					if ((!Reserva1.isEmpty() && Reserva2.isEmpty()) || (Reserva1.isEmpty() && !Reserva2.isEmpty())) {
						Datos.FijoCodigoReserva(CodigoReserva);
						if  (Reserva1.isEmpty()) {
							Reserva1 = Reserva2;
							Datos.FijoReserva(Datos.ObtenerReserva2());
						}
						Datos.FijoReserva2("");
						Envio = "Su Vuelo Nro " + Reserva1 + " Ha Sido Confirmado - Su Codigo De Reserva Es " + CodigoReserva + " - Un Agente Se Comunicara Con Usted En Las Proximas Horas - Muchas Gracias";
					}
					else {
						// System.out.println("No Se Actualiz� La Tabla Vuelos - Se Enviar� SMS De Error De Confirmaci�n");
						// Aca tengo que ver que hago para volver atras las tablas (MODIF)
						if (Flag1 == 0 && Flag2 == 0 && !Datos.ObtenerReserva2().isEmpty()) { //El cero indica que el nro de vuelo es incorrecto
							Envio = "Sus Numeros De Vuelos Son Incorrectos, Por Favor, Env�e \"Reservar\" + \"Vuelo\" + \"NroVuelo1\" + \"Y\" + \"NroVuelo2\" Para Confirmar Las Reservas";
						}
						else {
							Envio = "Su Numero De Vuelo Es Incorrecto, Por Favor, Env�e \"Reservar\" + \"Vuelo\" + \"NroVuelo\" Para Confirmar La Reserva";
						}
					}
				}		
			}
			else {
            	System.out.println("No Se Encontr� Pedido Del Cliente");	
            	Envio = "No Se Encontr� Su Pedido De Vuelos Previo. Realize Un Pedido De Vuelos Antes De Confirmar. Muchas Gracias.";
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		return Envio;
	}
	
	public int BuscoTipoAyuda(CDatos Datos) {
		SetearDatos();
		int TipoSMS; // Ultimo SMS Enviado al Usuario
		int TipoError = 1;
		try {
			qs = "select * from pedidos where NroCelular = \"" + Datos.ObtenerNroCelOrigen() + "\"";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) {
				TipoSMS = rs.getInt(2);
				if (TipoSMS == 10 || TipoSMS == 11) { //Ver si no hay que agregar otras ayudas (MODIF)
					TipoError = 2;
	            }	
			}	
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		return TipoError;
	}
	
	// Almaceno Lista De Contactos
	public int AlmacenoContacto(String NombreGrupo, String Nombre, String Cel) {
		SetearDatos();
		int Resultado;
		try {
			qs = "insert into contactos values (\"" + NombreGrupo + "\",\"" + Nombre + "\",\"" + Cel + "\")";
        	stmt = connection.createStatement();
            Resultado = stmt.executeUpdate(qs);
            if (Resultado != 1 ) {
            	System.out.println("Resultado BD: " + Resultado);            	
            	System.out.println("Error Al Cargar Datos en BD - Tabla \"contactos\"");
            	return 0;
            }
            else {
        		System.out.println("Contacto " + Nombre + " Guardado");
            }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
        	return 0;
		}
		return 1;
	}

//  Creo Un M�todo Para Pasar Strings a Objetos y Poder Grabarlos En Una Cola De Objetos De Nombres De Grupos De Contactos
	
	public Object makeObj(final String item) { 
	return new Object() { 
		public String toString() { return item; } };
	}	
	
// Cargo Nombres De Grupos De Contactos En Cola De Objetos De Strings
	
	public void CargarGrupoContactos(LinkedList<Object> GrupoContactos) {
		SetearDatos();
		try {
			qs = "select NombreGrupo from contactos group by NombreGrupo";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			while (rs.next()) {
            	GrupoContactos.add(makeObj(rs.getString(1)));
            }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
// Cargo Grupo De Contactos En Ventana Principal
	
	public void CargarContactos(String NombreGrupo, javax.swing.DefaultListModel SModel) {
		SetearDatos();
		try {
			qs = "select * from contactos where NombreGrupo = \"" + NombreGrupo + "\"";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			while (rs.next()) {
				Inicio.IngresoContacto(rs.getString(2), rs.getString(3), SModel);
            }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
//  Almaceno Reserva De Vuelos Confirmada
	public void AlmacenoReserva(CDatos Datos) {
		SetearDatos();
		String Cliente = "";
		String Vuelo2 = "-";
//		Verifico si el originador es cliente de la empresa
		try {
			qs = "select * from clientes where NroCelular = \"" + Datos.ObtenerNroCelOrigen() + "\"";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) { Cliente = "S"; }
			else { Cliente = "N"; }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		if (!(Datos.ObtenerReserva2().isEmpty())) { Vuelo2 = Datos.ObtenerReserva2(); }	
//		Almaceno Datos De La Reserva En La Base De Datos		
		int Resultado;
		try {
			qs = "insert into reservas values (\"" + Datos.ObtenerNroCelOrigen() + "\"," + Datos.ObtenerCodigoReserva() + ",\"" + Datos.ObtenerReserva() + "\",\"" + Vuelo2 + "\",\"" + Cliente +  "\")";
        	stmt = connection.createStatement();
            Resultado = stmt.executeUpdate(qs);
            if (Resultado != 1 ) {
            	System.out.println("Resultado BD: " + Resultado);            	
            	System.out.println("Error Al Cargar Datos en BD - Tabla \"reservas\"");
            }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
//  Busco Reserva En BD
	
	public CReserva BuscoReserva(int CodigoReserva) {
		SetearDatos();
		Reserva.Limpiar();
//		Cargo Valor del resultado de la busqueda de la reserva en el objeto CReserva
		try {
			qs = "select * from reservas where NroPedido = " + CodigoReserva;
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) { 
				Reserva.FijoNroCelular(rs.getString(1));
				Reserva.FijoVuelo1(rs.getString(3));
				Reserva.FijoVuelo2(rs.getString(4));
				Reserva.FijoCliente(rs.getString(5));
				Reserva.FijoNroPedido(rs.getInt(2));
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		try {
			qs = "select * from vuelos where NroVuelo = " + Reserva.ObtenerVuelo1();
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) {
				Reserva.FijoHorarioSalidaVuelo1(rs.getString(2));
				Reserva.FijoHorarioLlegadaVuelo1(rs.getString(3));
				Reserva.FijoFechaSalidaVuelo1(rs.getString(8));
				Reserva.FijoFechaLlegadaVuelo1(rs.getString(9));
				Reserva.FijoCiudadOrigenVuelo1(rs.getString(6));
				Reserva.FijoCiudadDestinoVuelo1(rs.getString(7));
				Reserva.FijoAvionVuelo1(rs.getString(5));
				Reserva.FijoAsientosLibresVuelo1(rs.getInt(4));
				Reserva.FijoEstadoVuelo1(rs.getString(11));
				Reserva.FijoPrecioVuelo1(rs.getInt(10));
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		if (!(Reserva.ObtenerVuelo2().compareTo("-") == 0)) {
			try {
				qs = "select * from vuelos where NroVuelo = " + Reserva.ObtenerVuelo2();
				stmt = connection.createStatement();
				rs = stmt.executeQuery(qs);
				if (rs.next()) {
					Reserva.FijoHorarioSalidaVuelo2(rs.getString(2));
					Reserva.FijoHorarioLlegadaVuelo2(rs.getString(3));
					Reserva.FijoFechaSalidaVuelo2(rs.getString(8));
					Reserva.FijoFechaLlegadaVuelo2(rs.getString(9));
					Reserva.FijoCiudadOrigenVuelo2(rs.getString(6));
					Reserva.FijoCiudadDestinoVuelo2(rs.getString(7));
					Reserva.FijoAvionVuelo2(rs.getString(5));
					Reserva.FijoAsientosLibresVuelo2(rs.getInt(4));
					Reserva.FijoEstadoVuelo2(rs.getString(11));
					Reserva.FijoPrecioVuelo2(rs.getInt(10));
				}
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		}
	return Reserva;
	}
	
  	public int AgregoVuelo(String Nro,String CiudadOrigen,String CiudadDestino,String CodigoAvion,String HoraSalida,String HoraLlegada,
  							String FechaSalida, String FechaLlegada,String Precio,String Asientos) {
  		
  		int NroVuelo = Integer.parseInt(Nro);
  		int PrecioFinal = Integer.parseInt(Precio);
  		int AsientosLibres = Integer.parseInt(Asientos);
  		int Resultado;
		try {
			qs = "select CodigoAeropuerto from aeropuertos where CodigoCiudad = ( select CodigoCiudad from ciudades where Ciudad = \"" + CiudadOrigen + "\" )";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) { 
				CiudadOrigen = rs.getString(1);
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		try {
			qs = "select CodigoAeropuerto from aeropuertos where CodigoCiudad = ( select CodigoCiudad from ciudades where Ciudad = \"" + CiudadDestino + "\" )";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) { 
				CiudadDestino = rs.getString(1);
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		try {
			qs = "insert into vuelos values (" + NroVuelo + ",\"" + HoraSalida + "\",\"" + HoraLlegada + "\"," + AsientosLibres + ",\"" + CodigoAvion +  "\",\""
											   + CiudadOrigen + "\",\"" + CiudadDestino + "\",\"" + FechaSalida +  "\",\"" + FechaLlegada + "\"," + PrecioFinal + ",\"En Horario\")";
        	stmt = connection.createStatement();
            Resultado = stmt.executeUpdate(qs);
            if (Resultado != 1 ) {
            	System.out.println("Resultado BD: " + Resultado);            	
            	System.out.println("Error Al Cargar Datos en BD - Tabla \"vuelos\"");
            	return 1;
            }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		return 0;
  	}
	
//  Busco Ciudades Para Colocar En Ventanas Extras
  	
	public LinkedList<Object> BuscoCiudades() {
		LinkedList<Object> Ciudades = new LinkedList<Object>();
		try {
			qs = "select Ciudad from ciudades";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			while (rs.next()) {
				Ciudades.add(makeObj(rs.getString(1)));
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	return Ciudades;
	}
	
/*	public int buscodato(String nombre) {
        
		int resultado = 0;
		
		try {
        	qs = "select edad from usuarios where nombre = \"" + nombre + "\"";
        	stmt = connection.createStatement();
            rs = stmt.executeQuery(qs);
            rs.next();
            resultado = rs.getInt("edad");
        } catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	    return resultado;
	} */
}
