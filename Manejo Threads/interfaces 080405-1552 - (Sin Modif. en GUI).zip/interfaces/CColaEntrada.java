package interfaces;

import java.util.*;

public class CColaEntrada {

	CColaEntrada() {
	};

	LinkedList<CMessage> ColaEnt = new LinkedList<CMessage>();

	public CMessage Temporal;

	public void Agregar(CMessage Mensaje) {
		ColaEnt.add(Mensaje);
	}

	// public void AgregarPro(CProtocolMessage Info)
	// {
	// ColaEnt.add(Info);
	// }

	public CMessage Obtener(int i) {
		Temporal = ColaEnt.get(i);
		return Temporal;
	}

	public CMessage Sacar() {
		Temporal = ColaEnt.remove();
		return Temporal;
	}

	public void Limpiar() {
		ColaEnt.clear();
	}

	public int Tama�oCola() {
		return ColaEnt.size();
	}

	public CMessage UltimoCola() {
		return ColaEnt.getLast();
	}

	public boolean EstaVacio() {
		return ColaEnt.isEmpty();
	}
}
