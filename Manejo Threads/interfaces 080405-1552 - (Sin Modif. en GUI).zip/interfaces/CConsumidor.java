package interfaces;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Date;

public class CConsumidor extends Thread {

	private CColaEntrada Cola1;
	public CMessage msg;
	public CIncomingMessage msginput;
	public CProtocolMessage msgprotocol;
	public int flag = 0;
	public CBaseDatos BD;
	public CInicio Inicio;
	public CParseo Parseo;
	public CDatos Datos;
	public File xmlFile;
	public PrintWriter out;
	public Date Fecha;
	public String FechaLog;
	
	public CConsumidor(CColaEntrada Cola11, CBaseDatos BD, CInicio Inicio) {
		Cola1 = Cola11;
		this.BD = BD;
		this.Inicio = Inicio;
		Parseo = new CParseo();
		Datos = new CDatos();
		msginput = null;
		msgprotocol = null;
	}
	
	public void ModificarFlag(int alta) {
		flag = alta;
	}
	
	public int ObtenerFlag() {
		return flag;
	}
	
	public void EscriboLog(CProtocolMessage msg) {
		Fecha = new Date();
		FechaLog = Fecha.toString();
		FechaLog = FechaLog.replace(':','-');
		System.out.println("FECHALOG: " + FechaLog);
//	 	Creo el Log
		try {
			xmlFile = File.createTempFile("Log - " + FechaLog, ".xml", new File("C:\\Mensajes\\Logs\\"));
			out = new PrintWriter(new FileWriter(xmlFile.getCanonicalPath()));
			out.println("<?xml version='1.0' encoding='iso-8859-7'?>");
			out.println("<message>");
			out.println("	<originator> " + msg.getOriginator() + " </originator>");
			out.println("	<date> " + msg.getDate() + " </date>");
			out.println("	<ID> " + msg.getId() + " </ID>");
			out.println("	<text> " + msg.getText() + " </text>");
			out.println("	<SMSLeidos> " + msg.getSMSLeidos() + " </SMSLeidos>");
			out.println("	<NroLectura> " + msg.getNroLectura() + " </NroLectura>");		
			out.println("	<SMSEnviados> " + msg.getSMSEnviados() + " </SMSEnviados>");
			out.println("</message>");	
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void run() {
		
		int superid = 0, memIndexVar = 1;
		//boolean Conexion = false;
		//CIncomingMessage msg;
		//System.out.println("Tama�o Cola: "+Cola1.Tama�oCola());
		//System.out.println("Consumidor: Duermo Consumidor 30 Segundos...");
		//try { sleep(30000); } catch (Exception e) {}
		// Modificar Valor de la Corrida en el While (MODIF)
		while (true) {
		//while (corrida < 4) {
//			if (flag == 1) {
				if (Cola1.Tama�oCola()>0) {
//					msgprotocol = (CProtocolMessage) Cola1.UltimoCola();		
// 					Saco el mensaje de la cola y lo imprimo en pantalla
					for (int i = 1; i < 2 ; i++){
						msg = Cola1.Sacar();
//						msg = Cola1.UltimoCola();
						if (msg.getMemIndex() != 0) {
							msginput = (CIncomingMessage) msg;
							superid = msginput.getId();
							memIndexVar = msginput.getMemIndex();		
							Inicio.ImprimirConsolaConsumidor("Consumidor: ID SMS: "+superid);
							Inicio.ImprimirConsolaConsumidor("Consumidor: MEM INDEX: "+memIndexVar);
							Inicio.ImprimirConsolaConsumidor(msginput.toString());
//							if (msginput.getText().contains("Vuelo") || msginput.getText().contains("Ayuda") || msginput.getText().contains("IguazuAir")) {
//								Inicio.ImprimirConsolaConsumidor("Ringgggggggg...Alarma...!!!");
							Datos.Limpiar();
							Datos = Parseo.Parsear(msginput, Datos);
							BD.AlmacenoSMSEntrantes(msginput, Datos);
//							Almaceno en Base Datos el SMS
							if (Datos.ObtenerTipoDato() == 1) {
								Inicio.ProcesarSMSTipo1(Datos);
//								int aux = BD.buscovuelo(Datos);
//								Inicio.ImprimirConsolaConsumidor("Usted Puede viajar en vuelo nro: " + aux);
//								Pedido de Vuelo con fecha unica de ida								
							}
							else if (Datos.ObtenerTipoDato() == 2) {
								Inicio.ProcesarSMSTipo2(Datos);
//								Pedido de Vuelo con fecha de ida y de retorno (2 vuelos)										
							}
							else if (Datos.ObtenerTipoDato() == 4) {
								Inicio.ProcesarSMSTipo4(Datos);
//								Generar SMS Ayuda Pedido Vuelos (Palabra IguazuAir)
								}
							else if (Datos.ObtenerTipoDato() == 5) {
								Inicio.ProcesarSMSTipo5(Datos);
//								Generar SMS Final Confirmaci�n Vuelo
								}
							else if (Datos.ObtenerTipoDato() == 6) {
//								Inicio.ProcesarSMSTipo6(Datos);
//								Generar SMS Mas Vuelos Pedidos
								}
							else if (Datos.ObtenerTipoDato() == 7) {
								Inicio.ProcesarSMSTipo7(Datos);
//								Generar SMS Estado Vuelo
								}
							else if (Datos.ObtenerTipoDato() == 8) {
								Inicio.ProcesarSMSTipo8(Datos);
//								Generar SMS Ayuda Pedido Vuelos (Mal Envio de SMS de Pedido de Vuelo)
								}
							else if (Datos.ObtenerTipoDato() == 9) {
								Inicio.ProcesarSMSTipo9(Datos);
//								Generar SMS Ayuda Confirmaci�n Vuelos (Mal Envio de SMS de Confirmaci�n de Vuelo)
								}
							else if (Datos.ObtenerTipoDato() == 10) {
								Inicio.ProcesarSMSTipo10(Datos);
//								Generar SMS Ayuda de Pedido de Estados De Vuelos
								}
							else if (Datos.ObtenerTipoDato() == 3) { 
								Inicio.ProcesarSMSTipo3(Datos);
//								Inicio.EnviarAyudaTipo2(Datos);
//								Generar SMS Ayuda Si Es Necesario (Si el SMS no es basura)							
								}
						}
//						}
						else {
//							escribe mensaje de protocolo en LOG
							msgprotocol = (CProtocolMessage) msg;
							superid = msgprotocol.getId();
							memIndexVar = msgprotocol.getMemIndex();
							Inicio.ImprimirConsolaConsumidor("/---------------------------/");
							Inicio.ImprimirConsolaConsumidor("Consumidor: ID SMS: "+superid);
							Inicio.ImprimirConsolaConsumidor("Consumidor: MEM INDEX: "+memIndexVar);
							Inicio.ImprimirConsolaConsumidor(msgprotocol.toString());
							Inicio.ImprimirConsolaConsumidor("/---------------------------/");
							EscriboLog(msgprotocol);
						}
						Inicio.ImprimirConsolaConsumidor("/---------------------------/");
						Inicio.ImprimirConsolaConsumidor("Consumidor: Saque un mensaje de la cola");
						Inicio.ImprimirConsolaConsumidor("Consumidor: Tama�o Cola: " + Cola1.Tama�oCola());
						Inicio.ImprimirConsolaConsumidor("/---------------------------/");
					}
					Inicio.ImprimirConsolaConsumidor("Consumidor: Duermo Consumidor 5 Segundos...");
					try { sleep(5000); } catch (Exception e) {}
				}
				else {
					Inicio.ImprimirConsolaConsumidor("No hay Mensaje en Cola De Entrada");
					Inicio.ImprimirConsolaConsumidor("Consumidor: Duermo Consumidor 10 Segundos...");
					try { sleep(10000); } catch (Exception e) {}
				}
		}
	}
}
	

