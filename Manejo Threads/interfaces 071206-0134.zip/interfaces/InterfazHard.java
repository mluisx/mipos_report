package interfaces;

import java.util.Date;

//import CMessage;
//import COutgoingMessage;
//import CService;

public class InterfazHard extends Thread {
	
	private ColaEntrada Cola1;
	private ColaSalida  Cola2;
	CService srv;
	int status;
	boolean Conexion;
	
	public InterfazHard (ColaEntrada Cola11, ColaSalida Cola22) {
		Cola1 = Cola11;
		Cola2 = Cola22;
		srv = new CService("com7",115200);
		status = 0;
		Conexion = false;
	}
	
	public void Conectar() {
		try	{
			srv.initialize();
			srv.setCacheDir(".\\");
			status = srv.connect();
			if (status == CService.ERR_OK){
				srv.setOperationMode(CService.MODE_PDU);
				srv.setSmscNumber("");
				Conexion = true;
			}
			else {
				System.out.println("Connection to mobile failed, error: " + status);
				Conexion = false;
			}
		}
		catch (Exception e)	{
			e.printStackTrace();
		}
	}
	
	public void Desconectar() {
		status = srv.disconnect();
		Conexion = false;
		System.out.println("InterfazHWVer3 : Desconexion");
	}
	
	public void run(){
		int antid = 0, superid = 0, recorrido = 1, memIndexVar = 1;
		int smsleidos, smsenviados = 0;
		CMessage msg = null;
		COutgoingMessage msgsal;
		Cola1.Limpiar();
		
		Conectar();
		
		if (Conexion) {
			while (recorrido < 21) {
				if (Conexion) {
					//Lectura Mensajes Entrantes
					if (srv.readMessages(Cola1, CIncomingMessage.CLASS_ALL, superid+1, memIndexVar) == CService.ERR_OK) {
						//for (int i = superid; i < size ; i++){
						System.out.println("InterfazHWVer3 : Leo Datos del Celular");	
						msg = Cola1.UltimoCola();
						//System.out.println(msg);
						superid = msg.getId(); // Ultimo ID
						memIndexVar = msg.getMemIndex(); //Ultimo MemIndex
						//}
					}
					if (recorrido > 1 && antid < superid) {
						System.out.println("Nuevo Mensaje Recibido!!!");
					}
					smsleidos = superid - antid;
					if (recorrido == 1) {System.out.println("InterfazHWVer3 : " + recorrido + " Lectura. SMS Leidos: " + smsleidos);}
					else {System.out.println("InterfazHWVer3 : " + recorrido + " Lectura. SMS Leidos: " + smsleidos);}
					System.out.println("InterfazHWVer3 : " + "Tama�o Cola Entrada : " + Cola1.Tama�oCola() + " Mensajes");
					msg = Cola1.UltimoCola();
//					System.out.println("InterfazHWVer3: " + "Ultimo SMS Cola Entrada:\n" + msg.getText());
//					System.out.println("InterfazHWVer3: " + "Ultimo SMS Cola Entrada MemIndex: " + msg.getMemIndex());
					//System.out.println("Interfaz: Tama�o Cola Entrada: " + Cola1.Tama�oCola());
					//Maurix
					//System.out.println("Interfaz: Lectura Realizada Nro: " + recorrido);
					//Maurix
					//System.out.println("Interfaz: memIndexVar: "+memIndexVar);
					//System.out.println("Interfaz: SuperID: " + superid);
					//Envio Mensajes en Cola de Salida
					if (!Cola2.EstaVacio()) {
						//Maurix
						System.out.println("Hay Mensaje Para Enviar...!!!!");
						msgsal = Cola2.Sacar();
						int x = srv.sendMessage(msgsal);
						if (x == CService.ERR_OK) {
							System.out.println("InterfazHWVer3 : Envio Mensaje SMS a la red GSM");
							System.out.println("InterfazHWVer3 : Tama�o Cola Salida : " + Cola2.Tama�oCola());
							smsenviados++;
						}
						else { System.out.println("Se produjo un error con el tama�o del mensaje a enviar: Valor X: " + x); }
						//Maurix
					}
					if (recorrido == 1) {
						superid++;
						Date Fecha = new Date();
						String De = "Interfaz De Hard Con Celu";
						String Info = "Realize Recorrido Nro 3";
						int superidp = superid;
						CProtocolMessage A1 = new CProtocolMessage(Fecha, De, Info, 0, superidp, recorrido, smsleidos, smsenviados);
						Cola1.Agregar(A1);
						System.out.println("InterfazHWVer3 : Envio Mensaje Protocolo a la Cola de Entrada");
					}
				}
				System.out.println("InterfazHWVer3 : Duermo InterfazHW 20 Segundos...");
				msg = Cola1.UltimoCola();
				antid = msg.getId();
				try { sleep(20000); } catch (Exception e) {}
				recorrido++;
			}
			srv.disconnect();
			System.out.println("Termina Interfaz");
		}
		else {
			System.out.println("No se Pudo Conectar...Verifique Datos Configuracion");
		}
	System.out.println("Ejecuci�n Servidor Finalizada");
	//Date FechaFin;
	//V1.FijoTexto3(Date)
	}
}

