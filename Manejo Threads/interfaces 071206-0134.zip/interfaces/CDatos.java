package interfaces;

public class CDatos {
	
	String TipoTicket, CiudadOrigen, CiudadDestino, FechaIda, FechaRetorno, FechaIdaDia, Cel;
	String FechaIdaMes, FechaIdaAnio, FechaRetornoDia, FechaRetornoMes, FechaRetornoAnio, Reserva, EstadoVuelo;
	int TipoDato; 

	//   TipoDato 1 = Datos completos pedido de vuelos sin fecha de retorno
	//   TipoDato 2 = Datos completos pedido de vuelos con fecha de retorno
	//   TipoDato 3 = Datos incompletos - Mensaje erroneo
	//   TipoDato 4 = Pedido de ayuda de adquisicion de vuelos
	//   TipoDato 5 = Confirmaci�n reserva de vuelo
	//   TipoDato 6 = Pedido de mas vuelos disponibles
	//   TipoDato 7 = Pedido de estado de vuelo
	
	public CDatos() {
		TipoTicket = CiudadOrigen = CiudadDestino = FechaIdaDia = FechaIdaMes = "";
		FechaIdaAnio = FechaRetornoDia = FechaRetornoMes = FechaRetornoAnio = "";
		FechaIda = FechaRetorno = Cel = Reserva = EstadoVuelo = "";
		TipoDato = 0;
	}
	
	public void Limpiar() {
		TipoTicket = CiudadOrigen = CiudadDestino = FechaIdaDia = FechaIdaMes = "";
		FechaIdaAnio = FechaRetornoDia = FechaRetornoMes = FechaRetornoAnio = "";
		FechaIda = FechaRetorno = Cel = Reserva = EstadoVuelo = "";
		TipoDato = 0;
	}
	
	public void FijoTipoTicket(String A1) {	TipoTicket = A1; }
	public void FijoCiudadOrigen(String A1) { CiudadOrigen = A1; }
	public void FijoCiudadDestino(String A1) { CiudadDestino = A1; }
	public void FijoFechaIda(String A1) { FechaIda = A1; }
	public void FijoFechaRetorno(String A1) { FechaRetorno = A1; }
	public void FijoNroCelOrigen(String A1) { Cel = A1; }
	public void FijoTipoDato(int TD) { TipoDato = TD; }
	public void FijoReserva(String A1) { Reserva = A1; }
	public void FijoNroVuelo(String A1) { EstadoVuelo = A1; }
/*	public void FijoFechaIdaDia(String A1) { FechaIdaDia = A1; }
	public void FijoFechaIdaMes(String A1) { FechaIdaMes = A1; }
	public void FijoFechaIdaAnio(String A1) { FechaIdaAnio = A1; }
	public void FijoFechaRetornoDia(String A1) { FechaRetornoDia = A1; }
	public void FijoFechaRetornoMes(String A1) { FechaRetornoMes = A1; }
	public void FijoFechaRetornoAnio(String A1) { FechaRetornoAnio = A1; } */

    public String ObtenerTipoTicket() { return TipoTicket; }
    public String ObtenerCiudadOrigen() { return CiudadOrigen; }
    public String ObtenerCiudadDestino() { return CiudadDestino; }
    public String ObtenerFechaIda() { return FechaIda; }
    public String ObtenerFechaRetorno() { return FechaRetorno; }
    public String ObtenerNroCelOrigen() { return Cel; }
    public int ObtenerTipoDato() { return TipoDato; }
    public String ObtenerReserva() { return Reserva; }
    public String ObtenerNroVuelo() { return EstadoVuelo; }
/*  public String ObtenerFechaIdaDia() { return FechaIdaDia; }
    public String ObtenerFechaIdaMes() { return FechaIdaMes; }
    public String ObtenerFechaIdaAnio() { return FechaIdaAnio; }
    public String ObtenerFechaRetornoDia() { return FechaRetornoDia; }
    public String ObtenerFechaRetornoMes() { return FechaRetornoMes; }
    public String ObtenerFechaRetornoAnio() { return FechaRetornoAnio; } */

}

