package interfaces;

import java.sql.*;
import java.io.*; 

public class CBaseDatos {
	
	public String url, CiudadOrigen, CiudadDestino; 
	public String qs;
	public Statement stmt;
	public ResultSet rs;
	public Connection connection;
	public int VueloNro;
	
	public CBaseDatos() {
		CiudadOrigen = "";
		CiudadDestino = "";
	};
	
	public void activarbd() throws ClassNotFoundException,IOException  {
		
		try {

		Class.forName("com.mysql.jdbc.Driver");
        url = "jdbc:mysql://localhost/maurixdb?user=root&password=glendora";        
	    connection = DriverManager.getConnection(url);
        /*qs = "select * from usuarios";
        stmt = connection.createStatement();
        rs = stmt.executeQuery(qs);
        System.out.println("nombre"+"\t   "+"edad");           
	    while (rs.next()){   
	         	    System.out.println(rs.getString( "nombre" ) +"\t\t"+
	         	                           rs.getInt( "edad" ));
        } */        
		}
		
		catch (SQLException sqle) { 
		
			sqle.printStackTrace();
				
		while (sqle != null) {
			String logMessage = "\n SQL Error: "+
			sqle.getMessage() + "\n\t\t"+
			"Error code: "+sqle.getErrorCode() + "\n\t\t"+
			"SQLState: "+sqle.getSQLState()+"\n";
			System.out.println(logMessage);
			sqle = sqle.getNextException();
			}
		}  
	}
	
	public void desactivarbd() {
		try {
			rs.close();
			stmt.close();
			connection.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public int buscovuelo(CDatos Datos) { 
		VueloNro = 0;
		CiudadOrigen = Datos.ObtenerCiudadOrigen();
		CiudadDestino = Datos.ObtenerCiudadDestino();
		try {
        	qs = "select * from vuelos where CodigoAeropuertoOrigen = ( " +
        				"select Codigo from aeropuertos where Ciudad = \"" + CiudadOrigen + "\" ) and CodigoAeropuertoDestino = ( " + 
        				"select Codigo from aeropuertos where Ciudad = \"" + CiudadDestino + "\" )";
        	stmt = connection.createStatement();
            rs = stmt.executeQuery(qs);
            rs.next();
            VueloNro = rs.getInt("NroVuelo");
        } catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	    return VueloNro;
/*		*/   
	}
	
/*	public int buscodato(String nombre) {
        
		int resultado = 0;
		
		try {
        	qs = "select edad from usuarios where nombre = \"" + nombre + "\"";
        	stmt = connection.createStatement();
            rs = stmt.executeQuery(qs);
            rs.next();
            resultado = rs.getInt("edad");
        } catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	    return resultado;
	} */
}
