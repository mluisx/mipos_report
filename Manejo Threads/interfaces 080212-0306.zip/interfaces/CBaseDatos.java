package interfaces;

import java.sql.*;
import java.io.*; 

public class CBaseDatos {
	
	public String url, CiudadOrigen, CiudadDestino, FechaIda, FechaRetorno, CiudadOrigenRet, CiudadDestinoRet; 
	public String qs, HorarioSalida, HorarioLlegada, Envio, HorarioSalidaRet, HorarioLlegadaRet;
	public Statement stmt;
	public ResultSet rs;
	public Connection connection;
	public int NroVuelo, Precio, NroVueloRet, PrecioRet;
	public int PedidoNro = 1000;
	public int SMSSalida = 1;
	public CContador Contador;
	
	public CBaseDatos() {
		CiudadOrigen = CiudadDestino = FechaIda = FechaRetorno = CiudadOrigenRet = CiudadDestinoRet = "";
		HorarioSalida = HorarioLlegada = Envio = HorarioSalidaRet = HorarioLlegadaRet = "";
		NroVuelo = Precio = NroVueloRet = PrecioRet = 0;
		Contador = new CContador(this);
	};
	
	public void SetearDatos() {
		CiudadOrigen = CiudadDestino = FechaIda = FechaRetorno = CiudadOrigenRet = CiudadDestinoRet = "";
		HorarioSalida = HorarioLlegada = Envio = HorarioSalidaRet = HorarioLlegadaRet = "";
		NroVuelo = Precio = NroVueloRet = PrecioRet = 0;
	}
	
	public void activarbd() throws ClassNotFoundException,IOException  {
		
		try {

		Class.forName("com.mysql.jdbc.Driver");
        url = "jdbc:mysql://localhost/maurixdb?user=root&password=glendora";        
	    connection = DriverManager.getConnection(url);
        /*qs = "select * from usuarios";
        stmt = connection.createStatement();
        rs = stmt.executeQuery(qs);
        System.out.println("nombre"+"\t   "+"edad");           
	    while (rs.next()){   
	         	    System.out.println(rs.getString( "nombre" ) +"\t\t"+
	         	                           rs.getInt( "edad" ));
        } */        
		}
		
		catch (SQLException sqle) { 
		
			sqle.printStackTrace();
				
		while (sqle != null) {
			String logMessage = "\n SQL Error: "+
			sqle.getMessage() + "\n\t\t"+
			"Error code: "+sqle.getErrorCode() + "\n\t\t"+
			"SQLState: "+sqle.getSQLState()+"\n";
			System.out.println(logMessage);
			sqle = sqle.getNextException();
			}
		}  
	}
	
	public void desactivarbd() {
		try {
			rs.close();
			stmt.close();
			connection.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public String PasoMinusculas(String Ciudad) {
		int x=0,y=1;
		String Caracter = "";
		String MiniCiudad = Ciudad;
		MiniCiudad = MiniCiudad.toLowerCase();
		Ciudad = "";
		while (y < MiniCiudad.length()){
			Caracter = MiniCiudad.substring(x,y);
			Caracter = Caracter.toUpperCase();
			Ciudad = Ciudad + Caracter;
			x = y;
			y = MiniCiudad.indexOf(" ");
			if (y<0) {
				y = MiniCiudad.length();
				Ciudad = Ciudad + MiniCiudad.substring(x);
			}
			else {
				Ciudad = Ciudad + MiniCiudad.substring(x,y) + " ";
				MiniCiudad = MiniCiudad.substring(y+1);
				x = 0;
				y = 1;
			}
		}
		return Ciudad;
	}
	
/*	public int buscovuelo(CDatos Datos) { 
		CiudadOrigen = Datos.ObtenerCiudadOrigen();
		CiudadDestino = Datos.ObtenerCiudadDestino();
		try {
        	qs = "select * from vuelos where CodigoAeropuertoOrigen = ( " +
        				"select Codigo from aeropuertos where Ciudad = \"" + CiudadOrigen + "\" ) and CodigoAeropuertoDestino = ( " + 
        				"select Codigo from aeropuertos where Ciudad = \"" + CiudadDestino + "\" )";
        	stmt = connection.createStatement();
            rs = stmt.executeQuery(qs);
            rs.next();
            NroVuelo = rs.getInt("NroVuelo");
        } catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	    return NroVuelo;
	}*/
//  TENGO QUE VER EL CASO DE VARIOS VUELOS EN TABLA (Muestra los 3 vuelos mas baratos - A partir del vuelo 4 se complica)	
	public String BuscoVuelo(CDatos Datos) {
		int filas = 0;
		SetearDatos();
		CiudadOrigen = Datos.ObtenerCiudadOrigen();
		CiudadDestino = Datos.ObtenerCiudadDestino();
		FechaIda = Datos.ObtenerFechaIda();
		try {
        	qs = "select * from vuelos where CodigoAeropuertoOrigen = ( " +
        				"select Codigo from aeropuertos where Ciudad = \"" + CiudadOrigen + "\" ) and CodigoAeropuertoDestino = ( " + 
        				"select Codigo from aeropuertos where Ciudad = \"" + CiudadDestino + "\" ) and FechaSalida = \"" + FechaIda + "\" and AsientosLibres > 1 Order by Precio";
        	stmt = connection.createStatement();
            rs = stmt.executeQuery(qs);
            Envio = "IguazuAir ";
            while (rs.next()) {
            	filas++;
            	System.out.println("Busco Vuelo IDA - Numero de Fila En Curso: " + filas);
            	if (filas>0 && filas<4) {
            		if (filas == 1) {
                        CiudadOrigen = PasoMinusculas(CiudadOrigen);
                        CiudadDestino = PasoMinusculas(CiudadDestino);
            			Envio = Envio + "- " + CiudadOrigen + " a " + CiudadDestino + " - " + FechaIda;        			
            		}
            		NroVuelo = rs.getInt("NroVuelo");
            		HorarioSalida = rs.getString("HorarioSalida");
//            		HorarioSalida = HorarioSalida.substring(0,5) + " Hs";
            		Precio = rs.getInt("Precio");
            		Envio = Envio + " - Vuelo " + NroVuelo + ", " + HorarioSalida + ", $" + Precio;
            	}
            }
        	if (filas == 0) {
        		Envio = Envio + "Le Informa Que No Hay Vuelos Disponibles Para El Destino y La Fecha Deseados";
        	}
        } catch (SQLException sqle) {
			sqle.printStackTrace();
		}
        return Envio;	
	}
//	TENGO QUE VER EL CASO DE VARIOS VUELOS EN TABLA	(Muestra 1 solo vuelo de ida y de retorno, siendo los dos vuelos los mas baratos disponibles)
	public String BuscoVueloIdaRetorno(CDatos Datos) {
		SetearDatos();
		CiudadOrigen = Datos.ObtenerCiudadOrigen();
		CiudadDestino = Datos.ObtenerCiudadDestino();
		FechaIda = Datos.ObtenerFechaIda();
		try {
        	qs = "select * from vuelos where CodigoAeropuertoOrigen = ( " +
        				"select Codigo from aeropuertos where Ciudad = \"" + CiudadOrigen + "\" ) and CodigoAeropuertoDestino = ( " + 
        				"select Codigo from aeropuertos where Ciudad = \"" + CiudadDestino + "\" ) and FechaSalida = \"" + FechaIda + "\" and AsientosLibres > 1 Order by Precio";
        	stmt = connection.createStatement();
            rs = stmt.executeQuery(qs);
            if (rs.next()) {    
            	NroVuelo = rs.getInt("NroVuelo");
            	HorarioSalida = rs.getString("HorarioSalida");
//           	HorarioSalida = HorarioSalida.substring(0,5) + " Hs";
            	Precio = rs.getInt("Precio");
            	Envio = "IguazuAir - Ida, Vuelo " + NroVuelo + ", " + PasoMinusculas(CiudadOrigen) + " a " + PasoMinusculas(CiudadDestino) + ", " + FechaIda + ", " + HorarioSalida + ", $" + Precio;
            }
            else { 
        	Envio = "IguazuAir - No hay Vuelo Disponible Para La Fecha De Ida";
            }
        } catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	    CiudadOrigenRet = CiudadDestino;
	    CiudadDestinoRet = CiudadOrigen;
	    FechaRetorno = Datos.ObtenerFechaRetorno();
		try {
        	qs = "select * from vuelos where CodigoAeropuertoOrigen = ( " +
        				"select Codigo from aeropuertos where Ciudad = \"" + CiudadOrigenRet + "\" ) and CodigoAeropuertoDestino = ( " + 
        				"select Codigo from aeropuertos where Ciudad = \"" + CiudadDestinoRet + "\" ) and FechaSalida = \"" + FechaRetorno + "\" and AsientosLibres > 1 Order by Precio";
        	stmt = connection.createStatement();
            rs = stmt.executeQuery(qs);
            if (rs.next()) {
            	NroVueloRet = rs.getInt("NroVuelo");
            	HorarioSalidaRet = rs.getString("HorarioSalida");
//            	HorarioSalidaRet = HorarioSalidaRet.substring(0,5) + " Hs";
            	PrecioRet = rs.getInt("Precio");
            	Envio = Envio + " - Retorno, Vuelo " + NroVueloRet + ", " + PasoMinusculas(CiudadOrigenRet) + " a " + PasoMinusculas(CiudadDestinoRet) + ", " + FechaRetorno + ", " + HorarioSalidaRet + ", $" + PrecioRet;    
            }
            else {
            	Envio = Envio + " - Para El Retorno No Hay Vuelos Disponibles";
            }
        } catch (SQLException sqle) {
			sqle.printStackTrace();
		}
        return Envio;				
	}
	
	public String BuscoEstadoVuelo(CDatos Datos) {
		SetearDatos();
		try {
			qs = "select * from vuelos where NroVuelo = " + Datos.ObtenerNroVuelo();
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) { 
            	HorarioSalida = rs.getString("HorarioSalida");
//				HorarioSalida = HorarioSalida.substring(0,5) + " Hs";
				Envio = "IguazuAir - Vuelo " + Datos.ObtenerNroVuelo() + " - " + rs.getString("FechaSalida") + " - " + HorarioSalida + " - Estado Del Vuelo: " + rs.getString("Estado");  
			}
			else {
				Envio = "IguazuAir - Vuelo " + Datos.ObtenerNroVuelo() + " - No Esta Programado En El Calendario De Vuelos";
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		return Envio;
	}
	
	public void AlmacenoPedido(CDatos Datos) {
		SetearDatos();
		int Resultado;
		String Cliente = "";
//		Verifico si el originador es cliente de la empresa
		try {
			qs = "select * from clientes where NroCelular = \"" + Datos.ObtenerNroCelOrigen() + "\"";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) { Cliente = "S"; }
			else { Cliente = "N"; }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
//		Arranco el contador que borra registros viejos
		if (PedidoNro==1000) {Contador.start();}
//		Almaceno pedido en Base de Datos
		if (Datos.ObtenerTipoDato() == 1 || Datos.ObtenerTipoDato() == 2) {
			try {
				qs = "insert into pedidos values (\"" + Datos.ObtenerNroCelOrigen() + "\",10," + Datos.ObtenerTipoDato() + ",\"" + Cliente +
				"\"," + PedidoNro + "," + Contador.ObtenerContador()+ ")" ;
				stmt = connection.createStatement();
				Resultado = stmt.executeUpdate(qs);
				if (Resultado != 1 ) {
					System.out.println("Resultado BD: " + Resultado);            	
					System.out.println("Error Al Cargar Datos en BD - Tabla pedidos");
				}
				else { PedidoNro++; }
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		}
		if (Datos.ObtenerTipoDato() == 7) {
			try {
				qs = "insert into pedidos values (\"" + Datos.ObtenerNroCelOrigen() + "\",12," + Datos.ObtenerTipoDato() + ",\"" + Cliente +
				"\"," + PedidoNro + "," + Contador.ObtenerContador()+ ")" ;
				stmt = connection.createStatement();
				Resultado = stmt.executeUpdate(qs);
				if (Resultado != 1 ) {
					System.out.println("Resultado BD: " + Resultado);            	
					System.out.println("Error Al Cargar Datos en BD - Tabla pedidos");
				}
				else { PedidoNro++; }
			} catch (SQLException sqle) {
				sqle.printStackTrace();
			}
		}	
	}
	
	//Funciones Que No Utilizo Todavia (MODIF)
	public void ActualizoPedido(int TipoAct) {
		SetearDatos();	
	}
	
	public void BorrarPedido(int NroPedido)  {
		SetearDatos();
	}
	//Funciones Que No Utilizo Todavia (MODIF)
	
	public void BorrarPedidoPorTimeOut(long Tiempo) {
		int Resultado;
		try {
			qs = "delete from pedidos where Hora < " + Tiempo; 
			stmt = connection.createStatement();
			Resultado = stmt.executeUpdate(qs);
            if (Resultado != 0 ) {          	
            	System.out.println("Se Borraron " + Resultado + " pedidos");
            }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public void AlmacenoSMSEntrantes(CIncomingMessage SMS,CDatos Datos) {
		SetearDatos();
		int Resultado;
		try {
			qs = "insert into smsinbox values (" + SMS.getId() + "," + SMS.getMemIndex() + ",\"" + SMS.getText() + "\",\"" + SMS.getOriginator() +
			"\",\"" + Datos.ObtenerTipoTicket() + "\"," + Datos.ObtenerTipoDato() + ")";
        	stmt = connection.createStatement();
            Resultado = stmt.executeUpdate(qs);
            if (Resultado != 1 ) {
            	System.out.println("Resultado BD: " + Resultado);            	
            	System.out.println("Error Al Cargar Datos en BD - Tabla smsinbox");
            }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}

	// Almaceno SMS que son enviados a los clientes en la tabla smsoutbox
	public void AlmacenoSMSSalientes(CDatos Datos, String Texto, int TipoDato) {
		SetearDatos();
		int Resultado;
		try {
			qs = "insert into smsoutbox values (" + SMSSalida + ",\"" + Texto + "\"," + TipoDato + ")";
        	stmt = connection.createStatement();
            Resultado = stmt.executeUpdate(qs);
            if (Resultado != 1 ) {
            	System.out.println("Resultado BD: " + Resultado);            	
            	System.out.println("Error Al Cargar Datos en BD - Tabla smsoutbox");
            }
            else {
            	SMSSalida++;
            }
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}

	// Actualizo tablas para confirmar el vuelo requerido por el usuario
	public String ConfirmarVuelo(CDatos Datos) {
		SetearDatos();
		int Resultado, CodigoReserva; //CodigoReserva es el NroPedido que se genero para el cliente y se almaceno en la tabla pedidos
		String Reserva1 ,Reserva2; //Los numeros de los vuelos a reservar
		Reserva1 = Reserva2 = "";
		try {
			qs = "select * from pedidos where NroCelular = \"" + Datos.ObtenerNroCelOrigen() + "\" and TipoUltimoSMSEnviado = 10";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) {
				CodigoReserva = rs.getInt(5);
				qs = "update vuelos set AsientosLibres = AsientosLibres - 1 where NroVuelo = " + Datos.ObtenerReserva();
				stmt = connection.createStatement();
				Resultado = stmt.executeUpdate(qs);
				if (Resultado == 1) {
					Reserva1 = Datos.ObtenerReserva();
    				System.out.println("Se Actualizo Tabla Vuelos");
				}
				if (!Datos.ObtenerReserva2().isEmpty()) {
    				qs = "update vuelos set AsientosLibres = AsientosLibres - 1 where NroVuelo = " + Datos.ObtenerReserva2();
    				stmt = connection.createStatement();
    				Resultado = stmt.executeUpdate(qs);
    				if (Resultado == 1) {
    					Reserva2 = Datos.ObtenerReserva2();
	    				System.out.println("Se Actualizo Tabla Vuelos");
    				}
				}
				if (!Reserva1.isEmpty() && !Reserva2.isEmpty()) {
					Envio = "Sus Vuelos Nro " + Reserva1 + " y " + Reserva2 + " Han Sido Confirmados - Su Codigo De Reserva Es " + CodigoReserva + " - Un Agente Se Estara Comunicando Con Usted En Las Proximas Horas - Muchas Gracias";					
				}
				else {
					if (Reserva1.isEmpty()) { Reserva1 = Reserva2; }
					if (!Reserva1.isEmpty()) {
						Envio = "Su Vuelo Nro " + Reserva1 + " Ha Sido Confirmado - Su Codigo De Reserva Es " + CodigoReserva + " - Un Agente Se Estara Comunicando Con Usted En Las Proximas Horas - Muchas Gracias";
					}
					else {
						System.out.println("No Se Actualizo La Tabla Vuelos - Se Enviar� Un SMS Vacio"); //Aca tengo que ver si Mando SMS Vacio (MODIF)
					}
				}		
			}
			else {
            	System.out.println("No Se Encontro Pedido Del Cliente");				
			}
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		return Envio;
	}
	
	public int BuscoTipoAyuda(CDatos Datos) {
		SetearDatos();
		int TipoSMS; // Ultimo SMS Enviado al Usuario
		int TipoError = 1;
		try {
			qs = "select * from pedidos where NroCelular = \"" + Datos.ObtenerNroCelOrigen() + "\"";
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qs);
			if (rs.next()) {
				TipoSMS = rs.getInt(2);
				if (TipoSMS == 10 || TipoSMS == 11) { //Ver si no hay que agregar otras ayudas (MODIF)
					TipoError = 2;
	            }	
			}	
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
		return TipoError;
	}
/*	public int buscodato(String nombre) {
        
		int resultado = 0;
		
		try {
        	qs = "select edad from usuarios where nombre = \"" + nombre + "\"";
        	stmt = connection.createStatement();
            rs = stmt.executeQuery(qs);
            rs.next();
            resultado = rs.getInt("edad");
        } catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	    return resultado;
	} */
}
