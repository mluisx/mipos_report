package interfaces;
import java.util.Date;
import java.sql.*;

public class CContador extends Thread {

	int Ciclo;
	//String qs;
	//public Statement stmt;
	//public ResultSet rs;
	public Connection connection;
	long ValorMilis;
	long Lapso;
	public CBaseDatos BD;
	String HoraInicioClock; 
	//String Reloj;
	
	public CContador(CBaseDatos BaseDatos) {
		Lapso = 120000;
		Ciclo = 1;
		BD = BaseDatos;
	}

	public long ObtenerContador() { 
		long Valor;
		Date Hora;
		Hora = new Date();		
		Valor = Hora.getTime(); // Minutos Del Contador En Milisegundos
		return Valor;
	}
	
	public String ObtenerHora() {
		Date Hora;
		Hora = new Date();
		String Tiempo;
		Tiempo = Hora.toString();
		Tiempo = Tiempo.substring(11, 19);
		return Tiempo;
	}
	// Modificar Valor del Ciclo en el While (MODIF)
	public void run() {
		HoraInicioClock = ObtenerHora();
		while (Ciclo < 15) {
			try { sleep(Lapso); } catch (Exception e) {}
			System.out.println("HORA INICIO CLOCK: " + HoraInicioClock);
			ValorMilis = ObtenerContador();
			System.out.println("HORA ACTUAL VALOR: " + ValorMilis);
			ValorMilis = ValorMilis - Lapso;
			//Borro Todos los registros de 1 hora atras (en el ejemplo 120 seg)
			System.out.println("HORA BORRO REGISTROS DE 120 SEG ANTES: VALORMILIS: " + ValorMilis);
			BD.BorrarPedidoPorTimeOut(ValorMilis);
			Ciclo++;
		}
	}
}
