package interfaces;

import java.util.LinkedList;

public class CColaSalida {
	
	CColaSalida(){};
	LinkedList<COutgoingMessage> ColaSal = new LinkedList<COutgoingMessage>();
	public COutgoingMessage Temporal;
	
	public void Agregar(COutgoingMessage Mensaje)
		{
		ColaSal.add(Mensaje);
		}
	
	public COutgoingMessage Obtener(int i)
	{
		Temporal = ColaSal.get(i);
		return Temporal;
	}
	
	public COutgoingMessage Sacar()
	{
		Temporal = ColaSal.remove();
		return Temporal;
	}
	
	public void Limpiar()
	{
		ColaSal.clear();	
	}
	
	public int Tama�oCola()
	{
		return ColaSal.size();
	}

	public COutgoingMessage UltimoCola()
	{
		return ColaSal.getLast();
	}
	
	public boolean EstaVacio()
	{
		return ColaSal.isEmpty();
	}
}
