package interfaces;

import java.io.IOException;
//import javax.swing.*;
import java.util.Date;

public class CInterfazGrafica extends javax.swing.JFrame {

	private static final long serialVersionUID = 1L;

    public CInterfazGrafica() {
        initComponents();
        BD = new CBaseDatos();
        Inicio = new CInicio(this);
        Ventanas = new CVentanas(Inicio,this);		// Inicio Objeto Creador De Ventanas
        BD.Inicio = Inicio;
    }
    // Maurix
    public javax.swing.JFrame VentanaPrincipal;
    public CProductor Prod1;
    public CConsumidor Consu1;
    public CService Srv1;
    public CBaseDatos BD;
	public CInicio Inicio;
    public javax.swing.DefaultListModel SampleModel,ModeloLista2;
    private CVentanas Ventanas;						// Declaro Objeto Que Dibuja Ventanas De Dialogo
//  private CDeviceInfo InfoDispositivo;			// Declaro un Objeto Que Tiene Info Del Celular 
    // Maurix
    
    // Declaro Variables
    private javax.swing.JButton jButton1; 			// Boton "ACT/DES"
    private javax.swing.JButton jButton2;			// Boton "Boton 2"
//  private javax.swing.JButton jButton3;			// Boton (Ventana "Acerca De") "OK"
    private javax.swing.JButton jButton4;			// Boton "Enviar SMS"
    private javax.swing.JButton jButton5;			// Boton "Agregar" (Contactos)
    private javax.swing.JButton jButton6;			// Boton "Remover" (Contactos)
    private javax.swing.JButton jButton7;			// Boton "Guardar" (Contactos)
    private javax.swing.JButton jButton8;			// Boton "Cargar"  (Contactos)
    private javax.swing.JButton jButton9;			// Boton de Reservas
    private javax.swing.JButton jButton10;			// Boton de Reservas
//  private javax.swing.JButton jButton11;			// Boton Que No Se Que Voy A Hacer
    private javax.swing.JLabel jLabel1;
//  private javax.swing.JLabel jLabel2;
//  private javax.swing.JLabel jLabel3;
//  private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;				// Label de "Reservas"
    private javax.swing.JLabel jLabel8;// Prueba (MODIF)
    private javax.swing.JLabel jLabel9;// Prueba (MODIF)
    private javax.swing.JLabel jLabel10;// Prueba (MODIF)
    private javax.swing.JLabel jLabel11;// Prueba (MODIF)
    private javax.swing.JLabel jLabel12;// Prueba (MODIF)
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    public  javax.swing.JList jList1;				// Lista De Contactos
    public  javax.swing.JList jList2;				// Lista De Reservas
    private javax.swing.JMenu jMenu1;				// Menu "Servidor"
    private javax.swing.JMenu jMenu2;				// Menu "Configuraci�n"
    private javax.swing.JMenu jMenu3;				// Menu "Acerca De"
    private javax.swing.JMenu jMenu4; 				// Menu "Base De Datos"
    private javax.swing.JMenu jMenu5; 				// Menu "Base De Datos" - Menu "Agregar"
    private javax.swing.JMenuBar jMenuBar1;			// Barra Menu
    public  javax.swing.JMenuItem jMenuItem1;		// Menu "Menu Principal" - Opcion "Conectar"
    public  javax.swing.JMenuItem jMenuItem2;       // Menu "Base De Datos" - Opcion "Desconectar"
    private javax.swing.JMenuItem jMenuItem3;		// Menu "Menu Principal" - Opcion "Salir"
    private javax.swing.JMenuItem jMenuItem4;		// Menu "Base De Datos" - Opcion "Conectar" 
    private javax.swing.JMenuItem jMenuItem5;		// Menu "Acerca De" - Opcion "Maurix Corp"
    private javax.swing.JMenuItem jMenuItem6;		// Menu "Menu Principal" - Opcion "Desconectar"
    private javax.swing.JMenuItem jMenuItem7; 		// Menu "Base De Datos" - Opcion "Aeropuertos"
    private javax.swing.JMenuItem jMenuItem8; 		// Menu "Base De Datos" - Opcion "Aviones"
    private javax.swing.JMenuItem jMenuItem9;		// Menu "Base De Datos" - Opcion "Clientes"
    private javax.swing.JMenuItem jMenuItem10;		// Menu "Base De Datos" - Opcion "Destinos"
    private javax.swing.JMenuItem jMenuItem11;		// Menu "Base De Datos" - Opcion "Vuelos"
    private javax.swing.JMenuItem jMenuItem12;		// Menu "Configuracion" - Opcion "Dispositivo GSM"
    private javax.swing.JMenuItem jMenuItem13;		// Menu "Configuracion" - Opcion "Archivos XML"
    private javax.swing.JMenuItem jMenuItem14;		// Menu "Configuracion" - Opcion "Tiempos De Lectura"
    private javax.swing.JMenuItem jMenuItem15;		// Menu "Configuracion" - Opcion "Archivo De Log"
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
/*  private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JProgressBar jProgressBar2;
    private javax.swing.JProgressBar jProgressBar3;
    public  javax.swing.JRadioButton jRadioButton1;*/
    private javax.swing.JScrollPane jScrollPane1;   // Panel Escritura 0,0
    private javax.swing.JScrollPane jScrollPane2;	// Panel Escritura 1,1
    private javax.swing.JScrollPane jScrollPane3;   // Panel Reservas
//  private javax.swing.JScrollPane jScrollPane4;	// Panel Escritura 1,0
//  private javax.swing.JScrollPane jScrollPane5;   
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;	// Panel Grande
    private javax.swing.JSeparator jSeparator1;
    public  javax.swing.JTextArea jTextArea1;
    public  javax.swing.JTextArea jTextArea2;
//  public  javax.swing.JTextArea jTextArea3;
//  public  javax.swing.JTextArea jTextArea4;
//  public  javax.swing.JTextArea jTextArea5;
    public  javax.swing.JTextArea jTextArea6;
    public  javax.swing.JTextArea jTextArea7;
    public  javax.swing.JTextArea jTextArea9;		// Area De Texto Asociado Al Panel 9
    public  javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;		// Prueba (MODIF)
    private javax.swing.JTextField jTextField6;		// Prueba (MODIF)
    private javax.swing.JTextField jTextField7;		// Prueba (MODIF)
    private javax.swing.JTextField jTextField8;		// Prueba (MODIF)
    private javax.swing.JTextField jTextField9;		// Prueba (MODIF)
    private javax.swing.JTextField jTextField10;	// Coloco Cantidad de SMS Entrantes
    private javax.swing.JTextField jTextField11;	// Coloco Cantidad de SMS Salientes
    private javax.swing.JTextField jTextField12;
    // Declaro Variables       
    
    private void initComponents() {
    	
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
//      jRadioButton1 = new javax.swing.JRadioButton();
        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton2 = new javax.swing.JButton();
//      jProgressBar1 = new javax.swing.JProgressBar();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
//      jTextArea3 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
//      jProgressBar2 = new javax.swing.JProgressBar();
//      jProgressBar3 = new javax.swing.JProgressBar();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
//      jScrollPane4 = new javax.swing.JScrollPane();
//      jTextArea4 = new javax.swing.JTextArea();
//      jScrollPane5 = new javax.swing.JScrollPane(); (MODIF)
//      jTextArea5 = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextArea6 = new javax.swing.JTextArea();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTextArea7 = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jScrollPane8 = new javax.swing.JScrollPane();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTextArea9 = new javax.swing.JTextArea();
        jList1 = new javax.swing.JList();
        jList2 = new javax.swing.JList();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
//      jButton11 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
//		Barra Menu
        jMenuBar1 = new javax.swing.JMenuBar();
//		Menu "Menu Principal"
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        jMenuItem3 = new javax.swing.JMenuItem();
//		Menu "Configuraci�n"
        jMenu2 = new javax.swing.JMenu();
        jMenuItem12 = new javax.swing.JMenuItem();
        jMenuItem13 = new javax.swing.JMenuItem();
        jMenuItem14 = new javax.swing.JMenuItem();
        jMenuItem15 = new javax.swing.JMenuItem();
//		Menu "Base De Datos"
        jMenu4 = new javax.swing.JMenu();
        jMenuItem4 = new javax.swing.JMenuItem();
//		Menu "Base De Datos" - "Agregar"
        jMenu5 = new javax.swing.JMenu();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem10 = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
//		Menu "Acerca De"        
        jMenu3 = new javax.swing.JMenu();
        jMenuItem5 = new javax.swing.JMenuItem();
               
//		Opciones De Ventana Principal
        
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Servidor De SMS - IguazuAir S.A.");
        setResizable(false);
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jButton1.setText("ACT/DES");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	jButton1ActionPerformed(evt);
            }
        });

//      jRadioButton1.setText("BD Activado");
//      jRadioButton1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
//      jRadioButton1.setMargin(new java.awt.Insets(0, 0, 0, 0));

        jTextField1.setText("Mensaje - Caracteres Restantes: 160");
        jTextField1.setEditable(false);
        
        
        jTextArea1.setColumns(20);
        jTextArea1.setEditable(true);
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setMinimumSize(new java.awt.Dimension(164, 22));
        jTextArea1.setText("Escriba Aqui SMS a Enviar");
        jScrollPane1.setViewportView(jTextArea1);
 
        jTextArea1.addKeyListener(new java.awt.event.KeyAdapter() {
        	public void keyReleased(java.awt.event.KeyEvent event) {
        		jTextArea1ActionPerformed(event);
        	}
        });

        jButton2.setText("Boton 2");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

//      jProgressBar1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
//      jProgressBar2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
//      jProgressBar3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        
        jTextArea2.setColumns(20);
        jTextArea2.setEditable(false);
        jTextArea2.setLineWrap(true);
        jTextArea2.setRows(3);
        jTextArea2.setMinimumSize(new java.awt.Dimension(164, 14));
        jScrollPane2.setViewportView(jTextArea2);

/*      jTextArea3.setColumns(20);
        jTextArea3.setEditable(false);
        jTextArea3.setLineWrap(true);
        jTextArea3.setRows(5);
        jTextArea3.setMinimumSize(new java.awt.Dimension(164, 22)); (MODIF) */
//      jScrollPane3.setViewportView(jTextArea3);(MODIF)

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 24));
        jLabel1.setText("Servidor SMS 1.0");
//      jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
 

        jButton4.setText("Enviar SMS");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

/*      jTextArea4.setColumns(20);
        jTextArea4.setRows(5);
        jTextArea4.setLineWrap(true);
        jTextArea4.setMinimumSize(new java.awt.Dimension(164, 22));
        jScrollPane4.setViewportView(jTextArea4);*/
        
//		jList2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        ModeloLista2 = new javax.swing.DefaultListModel();
        jList2.setModel(ModeloLista2);
        jScrollPane3.setViewportView(jList2);
        
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Reservas");
        jLabel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        
        jLabel9.setText("On Line Desde:");
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel11.setText("Estado Servidor:");
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel8.setText("Base De Datos:");
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel10.setText("Proceso De SMS:");
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel12.setText("Potencia Se�al:");
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel13.setText("Nivel De Bater�a:");
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel14.setText("SMS Recibidos:");
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel15.setText("SMS Enviados:");
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        
        jTextField5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jTextField5.setText("Desconectado");
        jTextField5.setFont(jLabel9.getFont());
        jTextField5.setEditable(false);
        
        jTextField6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jTextField6.setText("Desactivado");
        jTextField6.setFont(jLabel9.getFont());
        jTextField6.setEditable(false);
        
        jTextField7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jTextField7.setText("Desactivado");
        jTextField7.setFont(jLabel9.getFont());
        jTextField7.setEditable(false);
        
        jTextField8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jTextField8.setText("-");
        jTextField8.setFont(jLabel9.getFont());
        jTextField8.setEditable(false);
        
        jTextField9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jTextField9.setText("-");
        jTextField9.setFont(jLabel9.getFont());
        jTextField9.setEditable(false);
        
        jTextField10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jTextField10.setText("-");
        jTextField10.setFont(jLabel9.getFont());
        jTextField10.setEditable(false);
        
        jTextField11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jTextField11.setText("-");
        jTextField11.setFont(jLabel9.getFont());
        jTextField11.setEditable(false);
        
        jTextField12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jTextField12.setText("-");
        jTextField12.setFont(jLabel9.getFont());
        jTextField12.setEditable(false);
        
/*      jTextArea5.setColumns(20);
        jTextArea5.setRows(5);
        jTextArea5.setLineWrap(true);
        jTextArea5.setMinimumSize(new java.awt.Dimension(164, 22));
        jScrollPane5.setViewportView(jTextArea5); (MODIF)*/
        
        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                	.addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)))
//                          .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)))
/*                      .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(jRadioButton1))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                        	.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        	.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jProgressBar1, 0, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jProgressBar2, 0, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jProgressBar3, 0, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))))*/
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)                  
                    .addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
//              .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
//              .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createSequentialGroup()
//                  .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE /*javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE*/)
//                  .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                	.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)            		
                		.addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                			.addGroup(jPanel1Layout.createSequentialGroup()
                				.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                					.addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                					//.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                				.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                					.addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                					.addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
//                  .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE) (MODIF)
//                  .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)) (MODIF)
                	.addComponent(jScrollPane3,javax.swing.GroupLayout.PREFERRED_SIZE,222,javax.swing.GroupLayout.PREFERRED_SIZE)
                	.addComponent(jLabel7,javax.swing.GroupLayout.DEFAULT_SIZE,220,Short.MAX_VALUE)
                	.addGroup(jPanel1Layout.createSequentialGroup()
                		.addComponent(jButton9,javax.swing.GroupLayout.PREFERRED_SIZE,107,javax.swing.GroupLayout.PREFERRED_SIZE)
                		.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                		.addComponent(jButton10,javax.swing.GroupLayout.PREFERRED_SIZE,107,javax.swing.GroupLayout.PREFERRED_SIZE)))          	
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
//              .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
//                  .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 134, Short.MAX_VALUE) (MODIF)
/*                  .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                    	.addComponent(jLabel7)
                    	.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    	.addComponent(jScrollPane3,javax.swing.GroupLayout.PREFERRED_SIZE,206,javax.swing.GroupLayout.PREFERRED_SIZE)
                    	.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    	.addComponent(jButton9)
                    	.addComponent(jButton10)))*/
                	.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    	.addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                    	  	.addComponent(jLabel7)
                    	  	.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    	  	.addComponent(jScrollPane3,javax.swing.GroupLayout.PREFERRED_SIZE,240,javax.swing.GroupLayout.PREFERRED_SIZE)
                    	  	.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    	  	.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    	  		.addComponent(jButton9)
                    	  		.addComponent(jButton10)))
                    	.addGroup(jPanel1Layout.createSequentialGroup()
                    		.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    			.addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                    				.addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    				.addComponent(jButton1)
		             				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
//                 					.addComponent(jProgressBar1, javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE)
                       				.addComponent(jButton2)
                       				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    				.addComponent(jButton4)//, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)	
                    				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    				.addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    				.addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, Short.MAX_VALUE))
//                  					.addComponent(jProgressBar2,javax.swing.GroupLayout.DEFAULT_SIZE, 23, Short.MAX_VALUE))
//                    				.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
//                    				.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
//                    				    .addComponent(jButton11)))
//                      				.addComponent(jProgressBar3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
//                    			.addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 134, Short.MAX_VALUE))
                        		.addGroup(jPanel1Layout.createSequentialGroup()
                            		.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                		.addComponent(jTextField9)
                                		.addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                                	.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)	
                        			.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        				.addComponent(jTextField5)
                        				.addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        			.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        			.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        				.addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        				.addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        			.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            		.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                		.addComponent(jTextField7)
                                		.addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                                	.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        			.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            			.addComponent(jTextField8)
                            			.addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                            		.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            		.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                		.addComponent(jTextField10)
                                		.addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                                		.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                	.addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    	.addComponent(jTextField11)
                                    	.addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))                      			
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    	.addComponent(jTextField12)
                                    	.addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))                      			
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED) //, 5, Short.MAX_VALUE)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))))                                	
                .addContainerGap())
        );

        jTextArea6.setColumns(20);
        jTextArea6.setRows(5);
        jScrollPane6.setViewportView(jTextArea6);
        
        jScrollPane7.setVerifyInputWhenFocusTarget(false);
        jTextArea7.setColumns(20);
        jTextArea7.setRows(5);
//      jTextArea7.setFont(new java.awt.Font("Tahoma", 1, 12));
        jTextArea7.setFont(jLabel9.getFont());
        jScrollPane7.setViewportView(jTextArea7);

        
        jTextArea9.setColumns(20);
        jTextArea9.setRows(5);
        jTextArea9.setFont(jLabel9.getFont());
        jScrollPane9.setViewportView(jTextArea9);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
            .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
            .addComponent(jScrollPane7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
            .addComponent(jScrollPane9, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
//      jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(),"Contactos"));
        jTextField2.setText("Nombre");

        jTextField3.setText("Celular Sin 15");

        jLabel5.setText("Persona");

        jLabel6.setText("Nro Celular");

        jTextField4.setText("Area");

        /*jList1.setModel(new javax.swing.AbstractListModel() {
			private static final long serialVersionUID = 1L;
			public String[] strings = {"Agenda De Contactos"};
			public void FijoDato(String[] strings) { this.strings = strings; };
			public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
    	});*/   
        SampleModel = new javax.swing.DefaultListModel();
        //String[] entries = {"Agenda De Contactos"};
        	//SampleModel.addElement(entries[0]);
            jList1.setModel(SampleModel);
        
        jScrollPane8.setViewportView(jList1);

        jButton5.setText("Agregar");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("Remover");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        
        jButton7.setText("Guardar");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setText("Cargar");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt); 
            }
        });
        
        jButton9.setText("Mostrar");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt); 
            }
        });
        
        jButton10.setText("Abrir");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt); 
            }
        });
        
//      jButton11.setText("");

//		Opciones Del Panel 3        
        
        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 196, Short.MAX_VALUE)
//                  .addComponent(jButton5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE,196, Short.MAX_VALUE)
//                  .addComponent(jButton5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
//                  .addComponent(jButton7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField3))
                            .addComponent(jTextField2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                    	.addComponent(jButton5,javax.swing.GroupLayout.PREFERRED_SIZE,106, javax.swing.GroupLayout.PREFERRED_SIZE)
                    	.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    	.addComponent(jButton7,javax.swing.GroupLayout.PREFERRED_SIZE,106, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                    	.addComponent(jButton6,javax.swing.GroupLayout.PREFERRED_SIZE,106, javax.swing.GroupLayout.PREFERRED_SIZE)
                    	.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    	.addComponent(jButton8,javax.swing.GroupLayout.PREFERRED_SIZE,106, javax.swing.GroupLayout.PREFERRED_SIZE))                    	              	
                    .addComponent(jButton6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 196, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                	.addComponent(jButton5)
                	.addComponent(jButton7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)                	
                	.addComponent(jButton6)
                	.addComponent(jButton8))
                .addContainerGap())
        );
        
//		Opciones De Menu "Menu Principal"
        
        jMenu1.setText("Servidor");
        jMenuItem1.setText("Conectar");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });

        jMenu1.add(jMenuItem1);
//      jMenuItem1.getAccessibleContext().setAccessibleName("Encender Servidor");       

        jMenuItem6.setText("Desconectar");
        jMenuItem6.setEnabled(false);
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        
        jMenu1.add(jMenuItem6);

        jMenu1.add(jSeparator1);

        jMenuItem3.setText("Salir");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });

        jMenu1.add(jMenuItem3);

        jMenuBar1.add(jMenu1);
        
//		Opciones De Menu "Configuraci�n"        

        jMenu2.setText("Configuraci\u00f3n");
        jMenuItem12.setText("Dispositivo GSM");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem12);
       
        jMenuItem13.setText("Archivos XML");
        jMenuItem13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem13ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem13);
       
        jMenuItem14.setText("Tiempos De Lectura");
        jMenuItem14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem14ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem14);
        
        jMenuItem15.setText("Archivo De Log");
        jMenuItem15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem15ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem15);
        
        jMenuBar1.add(jMenu2);

// 		Opciones de Menu "Base De Datos"
        
        jMenu4.setText("Base De Datos");
        jMenuItem4.setText("Conectar");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem4);
        
        jMenuItem2.setText("Desconectar");
        jMenuItem2.setEnabled(false);
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu4.add(jMenuItem2);

        jMenu5.setText("Agregar Datos");
        jMenuItem7.setText("Aeropuertos");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });       
        jMenu5.add(jMenuItem7);
        
        jMenuItem8.setText("Aviones");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem8);
        
        jMenuItem9.setText("Clientes");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem9);
        
        jMenuItem10.setText("Destinos");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem10);
        
        jMenuItem11.setText("Vuelos");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        jMenu5.add(jMenuItem11);
        
        jMenu4.add(jMenu5);
        
        jMenuBar1.add(jMenu4);
        
//		Opciones De Menu "Acerca De"              

        jMenu3.setText("Acerca De");
        jMenuItem5.setText("Mi Trabajo Final de Carrera");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });

        jMenu3.add(jMenuItem5);

        jMenuBar1.add(jMenu3);

//		Opciones de Barra Menu
        
        setJMenuBar(jMenuBar1);
        
//		Opciones de Agregado De Paneles 1,2 y 3 A La IG        

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap())
        );
        pack();
                         
}// </editor-fold>                        

//  Metodos que manejan eventos

//  Boton "Agregar (Contactos)"
    
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
    	String NumeroCel = jTextField4.getText() + jTextField3.getText();
    	Inicio.IngresoContacto(jTextField2.getText(), NumeroCel, SampleModel);	
    }

//  Boton "Remover (Contactos)"
    
    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
    Inicio.BorrarContacto(jList1.getSelectedIndices(), SampleModel);	
    }

//  Menu "Base De Datos" - Opcion "Activar Base Datos" 
    
    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {                                           
    	Ventanas.AccesoBD = Ventanas.new VentanaAccesoBD();   	
    	Ventanas.AccesoBD.setVisible(true);    	
    	try {
        	BD.activarbd();
        	BD.CargarGrupoContactos(Inicio.GrupoContactos);
//			FijoTexto2("Base Datos Activada");
        	jTextField6.setText("Activado");
        	} catch (ClassNotFoundException Error1) {
        		FijoTexto2("Error en Base de Datos 1");
        	} catch (IOException Error2) {
        		FijoTexto2("Error en Base de Datos 2");
        }
        jMenuItem4.setEnabled(false);
        jMenuItem2.setEnabled(true);        
    }

//  Menu "Acerca De" - Opci�n "Mi T.F.C."    
    
    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {                                           
//      jDialog1.setVisible(true);
    	Ventanas.AcercaDe = Ventanas.new VentanaAcercaDe();   	
    	Ventanas.AcercaDe.setVisible(true);
    }

//  Menu "Base De Datos" - Opci�n "Aeropuertos"
    
    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {
//      jDialog2.setVisible(true);
//    	if (Ventanas.Aeropuertos == null) {Ventanas.Aeropuertos = Ventanas.new VentanaAeropuertos();}
    	Ventanas.Aeropuertos = Ventanas.new VentanaAeropuertos();   	
    	Ventanas.Aeropuertos.setVisible(true);
//    	if (Ventanita == null) {Ventanita = new VentanaAeropuertos();}    	
//    	Ventanita.setVisible(true);
    }  

//  Indicador De Caracteres Faltantes Para SMS A Enviar
    
    private void jTextArea1ActionPerformed(java.awt.event.KeyEvent event) {
    	String Texto = jTextArea1.getText();
    	int Largo = Texto.length();
    	int Caracteres = 160 - Largo;
		jTextField1.setText("Mensaje - Caracteres Restantes: " + Caracteres);
    }
    
//	Boton "ACT/DES"
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
    	int i = Inicio.ActivoConsumidor();
    	if (i == 0) {jTextField7.setText("Activado");}
    	else {jTextField7.setText("Desactivado");}
    }

//	Boton "Boton 2"
    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
    	//int Se�al = Srv1.getDeviceInfo().getSignalLevel();
//    	jProgressBar2.setMaximum(100);
    	//Falta Codigo...!!!
    	//public void setSignalIndicator(int signal) { this.pgbSignal.setValue(signal); }
//    	jProgressBar2.setValue(80);
    }

//  Boton "Enviar SMS"    
    
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {                                               
    	System.out.println("Enviar SMS");
    	Inicio.EnviarMensaje(jList1.getSelectedIndices());
    }                                              

//  Boton "Guardar" (Contactos)
    
    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {  
    	Ventanas.GuardarContactos = Ventanas.new VentanaGuardarContactos();   	
    	Ventanas.GuardarContactos.setVisible(true);
    }

//  Boton "Cargar" (Contactos) 
    
    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {   
    	Ventanas.CargarContactos = Ventanas.new VentanaCargarContactos();   	
    	Ventanas.CargarContactos.setVisible(true);
    }

//  Boton "Mostrar (En Pantalla)" (Reservas) 
    
    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {
    	Inicio.ImprimirReserva(jList2.getSelectedIndices());
    }
    
//  Boton "Abrir" (Reservas) 
    
    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {
    	Inicio.BorrarReserva(jList2.getSelectedIndices());
    }
    
//  Menu "Menu Principal" - Opci�n "Salir"
    
    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {                                           
    	Inicio.CierroLog();
    	System.exit(0);
    }                                          

//  Menu "Base De Datos" - Opci�n "Desconectar"
    
    public void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {                                           
//    	FijoTexto2("Base De Datos Desactivada");
    	jTextField6.setText("Desactivado");
        BD.desactivarbd();
        jMenuItem4.setEnabled(true);
    }                

//  Menu "Menu Principal" - Opci�n "Desconectar"    
    
    public void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {                                           
    	FijoTexto2("Desactivo Servidor");
    	jMenuItem1.setEnabled(true);
    	jMenuItem6.setEnabled(false);
    	Inicio.Desconexion();
    }          

//  Menu "Menu Principal" - Opci�n "Conectar"    
    
    public void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {                                          
        
    	String Fecha; //, Se�al, Bateria;
//    	Se�al = Bateria = "0";
    	jMenuItem6.setEnabled(true);
    	jMenuItem1.setEnabled(false);
        jTextField5.setText("Conectado");
		Fecha = CrearFecha();
        jTextField9.setText(Fecha);
        Inicio.EscriboLog("Servidor Conectado");
        Inicio.EscriboLog("Fecha Conexi�n: " + Fecha);
    	Inicio.Conexion();
/*    	InfoDispositivo = Inicio.Maurix.srv.getDeviceInfo();
    	while (Se�al.contains("0") && Bateria.contains("0")) {
    		Se�al = Integer.toString(InfoDispositivo.getSignalLevel());
    		jTextField8.setText(Se�al);
    		Bateria = Integer.toString(InfoDispositivo.getBatteryLevel());
    		jTextField10.setText(Bateria);
    	}*/
    }

//  Menu "Configuraci�n" - Opci�n "Dispositivo GSM"  
    
    public void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {
    	Ventanas.OpcionesGSM = Ventanas.new VentanaOpcionesGSM();   	
    	Ventanas.OpcionesGSM.setVisible(true);
    }

//  Menu "Configuraci�n" - Opci�n "Archivos XML"
    
    public void jMenuItem13ActionPerformed(java.awt.event.ActionEvent evt) {
    	Ventanas.ArchivosXML = Ventanas.new VentanaArchivosXML();   	
    	Ventanas.ArchivosXML.setVisible(true);
    }

//  Menu "Configuraci�n" - Opci�n "Tiempos De Lectura"  
    
    public void jMenuItem14ActionPerformed(java.awt.event.ActionEvent evt) {
    	Ventanas.TiemposLectura = Ventanas.new VentanaTiemposLectura();   	
    	Ventanas.TiemposLectura.setVisible(true);
    }

//  Menu "Configuraci�n" - Opci�n "Archivo De Log"  
    
    public void jMenuItem15ActionPerformed(java.awt.event.ActionEvent evt) {
    	Ventanas.ArchivoLog = Ventanas.new VentanaArchivoLog();   	
    	Ventanas.ArchivoLog.setVisible(true);
    }
    
//  Menu "Base De Datos" - Opci�n "Aviones"   
    
    public void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {                                          
//    	Ventana.setVisible(true);
    	Ventanas.Aviones = Ventanas.new VentanaAviones();   	
    	Ventanas.Aviones.setVisible(true);
    } 
    
//  Menu "Base De Datos" - Opci�n "Clientes"
    
    public void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {                                          
//    	Ventana.setVisible(true);
    	Ventanas.Clientes = Ventanas.new VentanaClientes();   	
    	Ventanas.Clientes.setVisible(true);
    } 
    
//  Menu "Base De Datos" - Opci�n "Destinos"
    
    public void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {                                          
//    	Ventana.setVisible(true);
    	Ventanas.Destinos = Ventanas.new VentanaDestinos();   	
    	Ventanas.Destinos.setVisible(true);
    }
    
    public void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {                                          
//    	Ventana.setVisible(true);
    	Ventanas.Vuelos = Ventanas.new VentanaVuelos();   	
    	Ventanas.Vuelos.setVisible(true);
    }
    
//	Metodos Extras
    
    public String CrearFecha() {
    	String FechaTemp, FechaFinal;
    	FechaTemp = FechaFinal = "";
    	Date Fecha;
    	Fecha = new Date();
    	FechaTemp = Fecha.toString();
/*    	if (FechaTemp.contains("Sun")) {FechaFinal = "Dom";}
    	else if (FechaTemp.contains("Mon")) {FechaFinal = "Lun";}
    	else if (FechaTemp.contains("Tue")) {FechaFinal = "Mar";}
    	else if (FechaTemp.contains("Wed")) {FechaFinal = "Mie";}
    	else if (FechaTemp.contains("Thu")) {FechaFinal = "Jue";}
    	else if (FechaTemp.contains("Fri")) {FechaFinal = "Vie";}
    	else if (FechaTemp.contains("Sat")) {FechaFinal = "Sab";}*/
    	FechaFinal = FechaTemp.substring(8, 10) + "/";
    	if (FechaTemp.contains("Jan")) {FechaFinal += "01";}
    	else if (FechaTemp.contains("Feb")) {FechaFinal += "02";}
    	else if (FechaTemp.contains("Mar")) {FechaFinal += "03";}
    	else if (FechaTemp.contains("Apr")) {FechaFinal += "04";}
    	else if (FechaTemp.contains("May")) {FechaFinal += "05";}
    	else if (FechaTemp.contains("Jun")) {FechaFinal += "06";}
    	else if (FechaTemp.contains("Jul")) {FechaFinal += "07";}
    	else if (FechaTemp.contains("Aug")) {FechaFinal += "08";}
    	else if (FechaTemp.contains("Sep")) {FechaFinal += "09";}
    	else if (FechaTemp.contains("Oct")) {FechaFinal += "10";}
    	else if (FechaTemp.contains("Nov")) {FechaFinal += "11";}
    	else if (FechaTemp.contains("Dec")) {FechaFinal += "12";}
    	FechaFinal += "/" + FechaTemp.substring(32, 34) + " " + FechaTemp.substring(11, 19); 
    	return FechaFinal;
    }
     
    public void AjustoSrv(CService Srv){
    	Srv1 = Srv;
    }

    public void FijoTexto2(String Texto){
    	String Temp = jTextArea2.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	jTextArea2.setText(Temp);
    }
     
}

