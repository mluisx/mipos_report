package interfaces;

public class Consumidor extends Thread {

	private ColaEntrada Cola1;
	public CMessage msginput;
	public int flag = 0;
	public BaseDatos BD;
	public CInicio Inicio;
	
	public Consumidor (ColaEntrada Cola11, BaseDatos BD, CInicio Inicio) {
		Cola1 = Cola11;
		this.BD = BD;
		this.Inicio = Inicio;
	}
	
	public void ModificarFlag (int alta) {
		flag = alta;
	}
	
	public int ObtenerFlag () {
		return flag;
	}
	
	public void run(){
		
		int corrida = 1, superid = 0, memIndexVar = 1;
		//boolean Conexion = false;
		//CIncomingMessage msg;
		//System.out.println("Tama�o Cola: "+Cola1.Tama�oCola());
		//System.out.println("Consumidor: Duermo Consumidor 30 Segundos...");
		//try { sleep(30000); } catch (Exception e) {}
		while (corrida < 250) {
		//while (corrida < 4) {
			if (flag == 1) {
				if (Cola1.Tama�oCola()>0) {
					// Saco el mensaje de la cola y lo imprimo en pantalla
					// msginput = Cola1.Sacar();
					for (int i = 1; i < 2 ; i++){
						// msg = Cola1.Obtener(i);
						msginput = Cola1.Sacar();
						superid = msginput.getId();
						memIndexVar = msginput.getMemIndex();		
						Inicio.ImprimirConsola("Consumidor: ID SMS: "+superid);
						Inicio.ImprimirConsola("Consumidor: MEM INDEX: "+memIndexVar);
						Inicio.ImprimirConsola(msginput.toString());
						if (msginput.getText().contains("Testeo 5")){
							Inicio.ImprimirConsola("Ringgggggggg...Alarma...!!!");
							int aux = BD.buscodato("Maurix");
							Inicio.ImprimirConsola("Maurix tiene " + aux + " a�os");
						}
					}
					Inicio.ImprimirConsola("Consumidor: Saque un mensaje de la cola");
					Inicio.ImprimirConsola("Consumidor: Tama�o Cola: " + Cola1.Tama�oCola());
				}
			}
			Inicio.ImprimirConsola("Consumidor: Duermo Consumidor 40 Segundos...");
			try { sleep(40000); } catch (Exception e) {}
			corrida++;
			//if (Maurix.
		}
		Inicio.ImprimirConsola("Termina Consumidor");
	}
}
