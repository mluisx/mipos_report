package interfaces;

public class ProbarCosas2 {
	
	public static void ParsearFecha(String Fecha, int tipofecha) {
		
		int Index1 = 0, Index2 = 1, Index3 = 0;
		String MiniTexto = "", MiniTexto2 = "";
		int flag1 = 1, flag2 = 0, flag3 = 0;
		String FechaDia = "", FechaMes = "", FechaAnio = "", Simbolo = "";
		
		if (Fecha.contains("/") || Fecha.contains("-") || Fecha.contains("\\") || Fecha.contains("_")) {
			
			if (Fecha.contains("2007")) {
				Index3 = Fecha.length() - 5;
				Simbolo = Fecha.substring(Index3, Index3+1);
				//System.out.println("Simbolo : " + Simbolo);
			}
			else {
				Index3 = Fecha.length() - 3;
				Simbolo = Fecha.substring(Index3, Index3+1);
				//System.out.println("Simbolo : " + Simbolo);
			}
			
			Fecha = Fecha.concat(Simbolo);
			
			for (int i = 1 ; i<=3 ; i++) {
				Index2 = Fecha.indexOf(Simbolo,Index1);
				//System.out.println("Index2 : " + Index2 + "FechaIDA : " + FechaIda);
				MiniTexto = MiniTexto + "#" + Fecha.substring(Index1, Index2);
				MiniTexto2 = Fecha.substring(Index1, Index2);
				//Comienzo Parseo
				if (i == 1) {FechaDia = MiniTexto2;}
				else if (i == 2) {FechaMes = MiniTexto2;}
				else if (i == 3) {FechaAnio = MiniTexto2;}
				//Fin Parseo
				Index1 = Index2 + 1;
			}
		}
		else {
			while (Index1 < Fecha.length()) {
				Index2 = Fecha.indexOf(" ",Index1);
				if (Index2 > 0) {
					MiniTexto = MiniTexto + "#" + Fecha.substring(Index1, Index2);
					MiniTexto2 = Fecha.substring(Index1, Index2);
					//Comienzo Parseo
					if (flag1 == 1) {FechaDia = MiniTexto2; flag1 = 0; flag2 = 1;}
					else if (flag2 == 1 && MiniTexto2.compareTo("DE") != 0) {FechaMes = MiniTexto2; flag2 = 0; flag3 = 1;}
					else if (flag3 == 1 && MiniTexto2.compareTo("DEL") != 0) {FechaAnio = MiniTexto2; flag3 = 0;}
					//Fin Parseo
					Index1 = Index2 + 1;
				}
				else {
					Index1 = Fecha.length();
				}
			}
		}
		if (tipofecha == 0) {
			System.out.println("Mensaje Parseado Ida Dia : " + FechaDia);
			System.out.println("Mensaje Parseado Ida Mes : " + FechaMes);
			System.out.println("Mensaje Parseado Ida A�o : " + FechaAnio);
		}
		if (tipofecha == 1) {
			System.out.println("Mensaje Parseado Vuelta Dia : " + FechaDia);
			System.out.println("Mensaje Parseado Vuelta Mes : " + FechaMes);
			System.out.println("Mensaje Parseado Vuelta A�o : " + FechaAnio);
			}
	}

	public static void main(String[] args) {

		String Texto;
		String MiniTexto = "";
		String MiniTexto2 = "";
		String TipoTicket = "", CiudadOrigen = "", CiudadDestino = "", FechaIda = "", FechaRetorno = "";
		int Index1 = 0,Index2 = 1;
		int flag1 = 0, flag2 = 0, flag3 = 0, flag4 = 0;
		
		//Texto = "Vuelo desde Buenos Aires a Posadas el 4 de Noviembre del 2007";
		//Texto = "Vuelo desde Posadas a Buenos Aires el 1/10/2007";
		Texto = "Vuelo de Posadas a Buenos Aires fecha de ida 10/12/2007 fecha de retorno 10/1/07";
		Texto = Texto.trim();
		Texto = Texto + " ";
		Texto = Texto.toUpperCase();
		System.out.println("Mensaje : " + Texto);
		while (Index1 < Texto.length()) {
			Index2 = Texto.indexOf(" ",Index1);
			//System.out.println("Index1: " + Index1);
			//System.out.println("Index2: " + Index2);
			if (Index2 > 0) {
				MiniTexto = MiniTexto + "#" + Texto.substring(Index1, Index2);
				MiniTexto2 = Texto.substring(Index1, Index2);
				//Comienzo Parseo
				if (MiniTexto2.compareTo("VUELO") == 0) {TipoTicket = MiniTexto2;}
				else if (MiniTexto2.compareTo("COLECTIVO") == 0) {TipoTicket = MiniTexto2;}
				else if (MiniTexto2.compareTo("DESDE") == 0 || MiniTexto2.compareTo("ORIGEN") == 0 || (MiniTexto2.compareTo("DE") == 0 && flag3 == 0)) {flag1 = 1;}
				else if (MiniTexto2.compareTo("A") == 0 || MiniTexto2.compareTo("DESTINO") == 0 || MiniTexto2.compareTo("HACIA") == 0) {flag2 = 1; flag1 = 0;}
				else if ((MiniTexto2.compareTo("EL") == 0) || (MiniTexto2.compareTo("FECHA") == 0) || (MiniTexto2.compareTo("DE") == 0 && flag3 == 1) || 
						(MiniTexto2.compareTo("IDA") == 0) || (MiniTexto2.compareTo("Y") == 0) || (MiniTexto2.compareTo("RETORNO") == 0)) {flag2 = 0; flag3 = 1;}
				else if (flag1 == 1) {CiudadOrigen = CiudadOrigen + MiniTexto2 + " ";}
				else if (flag2 == 1) {CiudadDestino = CiudadDestino + MiniTexto2 + " ";}
				else if (flag3 == 1 && flag4 == 0) {FechaIda = FechaIda + MiniTexto2 + " "; flag4 = 1;}
				else if (flag4 == 1) {FechaRetorno = FechaRetorno + MiniTexto2 + " ";}
				//Fin Parseo
				Index1 = Index2 + 1;
			}
			else {
				Index1 = Texto.length();
			}
		}
		
		CiudadOrigen = CiudadOrigen.trim();
		CiudadDestino = CiudadDestino.trim();
		FechaIda = FechaIda.trim();
		FechaRetorno = FechaRetorno.trim();
		System.out.println("Mensaje Parseado Completo : " + MiniTexto);
		System.out.println("Mensaje Parseado TipoTicket : " + TipoTicket);
		System.out.println("Mensaje Parseado CiudadOrigen : " + CiudadOrigen);
		System.out.println("Mensaje Parseado CiudadDestino : " + CiudadDestino);
		System.out.println("Mensaje Parseado FechaIda : " + FechaIda);
		if (!FechaRetorno.isEmpty()) {System.out.println("Mensaje Parseado FechaRetorno : " + FechaRetorno);}
		
        ParsearFecha(FechaIda,0);
        ParsearFecha(FechaRetorno,1);

	}
}
