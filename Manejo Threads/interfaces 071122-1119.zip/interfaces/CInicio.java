package interfaces;

import java.util.LinkedList;

public class CInicio {

	public CInicio(InterfazPreFinal V1){
		
		this.V1 = V1;
		ListaContactos = new LinkedList<CContacto>();
		
	};
	
	public InterfazPreFinal V1;
	public Consumidor Consu;
	public Productor Prod;
	public BaseDatos BD;
	public LinkedList<CContacto> ListaContactos;
	public CContacto Contacto;
	
	public void Conexion() {

		String Temporal;
		ColaEntrada Cola1 = new ColaEntrada();
		Temporal = "Cola de Entrada: Activado\n";
		ColaSalida  Cola2 = new ColaSalida();
		Temporal = Temporal + "Cola de Salida : Activado\n";	
		InterfazHWVer3 Maurix = new InterfazHWVer3(Cola1, Cola2);
		Temporal = Temporal + "Interfaz HW : Activado\n";
		this.BD = V1.BD;
		Consu = new Consumidor(Cola1,BD,this);
		Temporal = Temporal + "Consumidor : Activado\n";
		Prod = new Productor(Cola2, this);
		Temporal = Temporal + "Productor : Activado";
		FijoTexto3(Temporal);
		Maurix.start();
		Temporal = "Interfaz de Hardware Con Cel Iniciado";
		Consu.start();
		//Temporal = Temporal + "Consumidor Mensajes Iniciado\n";
		//Prod.start();
		//Temporal = Temporal + "Productor Mensajes Iniciado\n";
		FijoTexto1(Temporal);
		
	}
	
	//public void AjustoConsu(Consumidor Consu){this.Consu = Consu;}
	//public void AjustoProd(Productor Prod){this.Prod = Prod;}

	public void ActivoConsumidor() {
		int i = Consu.ObtenerFlag();
		if (i == 0) { 
			Consu.ModificarFlag(1);
			System.out.println("Consumidor Activado");
			V1.jRadioButton1.setSelected(true);
		}
		else { 
			Consu.ModificarFlag(0);
			System.out.println("Consumidor Desactivado");
			V1.jRadioButton1.setSelected(false);
		}
	}
	
    public void FijoTexto1(String Texto){
    	String Temp = V1.jTextArea1.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	V1.jTextArea1.setText(Temp);
    }
    
    public void FijoTexto2(String Texto){
    	String Temp = V1.jTextArea2.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	V1.jTextArea2.setText(Temp);
    }
    
    public void FijoTexto3(String Texto){
    	String Temp = V1.jTextArea3.getText();
    	if (Temp.length() > 0) {Temp = Temp + "\n";}
    	Temp = Temp + Texto;
    	V1.jTextArea3.setText(Temp);
    }
    
    public void HabilitoConexion(){
    	V1.jMenuItem2.setEnabled(false);
    	V1.jMenuItem1.setEnabled(true);	
    }
	
	public void EnviarMensaje(int indice[]) {
		String Envio = V1.jTextArea4.getText();
		for (int i=0;i<indice.length;i++) {
			Contacto = ListaContactos.get(indice[i]);
			String Cel = Contacto.ObtenerCodigoArea() + Contacto.ObtenerNumeroCel();
			System.out.println("Numero a Enviar : " + Cel);
			Prod.EnvioSMS(Envio,Cel);
		}
	}
	
	public void IngresoContacto(String Nombre, String CodigoArea, String NumeroCel, javax.swing.DefaultListModel SModel) {
		Contacto = new CContacto(Nombre, CodigoArea, NumeroCel);
		ListaContactos.add(Contacto);
		String Agrego = Contacto.ObtenerNombre() + " : " + Contacto.ObtenerCodigoArea() + Contacto.ObtenerNumeroCel();
	    SModel.addElement(Agrego);
    }

	public void BorrarContacto(int indice[], javax.swing.DefaultListModel SModel) {
		for (int i=0;i<indice.length;i++) {
			System.out.println("Indice: " + indice[i]);
			ListaContactos.remove(indice[i]-i);
			SModel.remove(indice[i]-i);
		}
	}
	
	public void ImprimirConsolaConsumidor(String Texto) {
		String TextoFull;
		TextoFull = V1.jTextArea6.getText();
    	if (TextoFull.length() > 0) {TextoFull = TextoFull + "\n";}
    	TextoFull = TextoFull + Texto;
    	V1.jTextArea6.setText(TextoFull);
	}
	
	public void ImprimirConsolaProductor(String Texto) {
		String TextoFull;
		TextoFull = V1.jTextArea7.getText();
    	if (TextoFull.length() > 0) {TextoFull = TextoFull + "\n";}
    	TextoFull = TextoFull + Texto;
    	V1.jTextArea7.setText(TextoFull);
	}
}	




