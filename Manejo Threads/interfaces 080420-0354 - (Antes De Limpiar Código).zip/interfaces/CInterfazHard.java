package interfaces;

import java.util.Date;

public class CInterfazHard extends Thread {
	
	private CColaEntrada Cola1;
	private CColaSalida  Cola2;
	public  CService srv;
	int status, Vel, Tiempo;
	boolean Conexion;
	int antid, superid, recorrido, smsleidos, smsenviados, memIndexVar;
	COutgoingMessage msgsal;
	CMessage msg;
	String Com;
	
	public CInterfazHard (CColaEntrada Cola11, CColaSalida Cola22) {
		Cola1 = Cola11;
		Cola2 = Cola22;
		Cola1.Limpiar();
		srv = null;
		status = 0;
		Conexion = false;
		antid = superid = recorrido = smsleidos = smsenviados = Vel = Tiempo = 0;
		memIndexVar = 1;
		msg = null;
		Com = "";
	}
	
	public void FijoDatosConexion(String DatoPuerto, String DatoVel, int DatoTiempo) {
		boolean Cambio = false;
		if (Com.compareTo(DatoPuerto) != 0) {
			Com = DatoPuerto;
			Cambio = true;
		}
		if (DatoVel.compareTo(Integer.toString(Vel)) != 0) {
			Vel = Integer.parseInt(DatoVel);
			Cambio = true;
		}
		Com = Com.toLowerCase();
		if (srv == null) { srv = new CService(Com,Vel); }
		else if (Cambio) { srv = new CService(Com,Vel); }
		Tiempo = DatoTiempo; 
	}
	
	public void Conectar() {
		try	{
			srv.initialize();
			srv.setCacheDir(".\\");
			status = srv.connect(Cola1);
			if (status == CService.ERR_OK){
				srv.setOperationMode(CService.MODE_PDU);
				srv.setSmscNumber("");
				Conexion = true;
			}
			else {
				System.out.println("La Conexi�n Al Dispositivo GSM Fall�, Tipo De Error: " + status);
				Conexion = false;
			}
		}
		catch (Exception e)	{
			e.printStackTrace();
		}
	}
	
	public void Desconectar() {
		Conexion = false;
		System.out.println("InterfazHWVer3 : Comenzando Desconexi�n");
	}
	
	public void run() {
		Conectar();
		while (Conexion) {			//Comienzo Lectura De Mensajes Entrantes
			recorrido++;
			if (srv.readMessages(Cola1, CIncomingMessage.CLASS_ALL, superid+1, memIndexVar) == CService.ERR_OK) {
				System.out.println("/------------------------------------/");
				System.out.println("InterfazHWVer3 : Leo Datos del Celular");	
				if (Cola1.Tama�oCola()>0) {
					msg = Cola1.UltimoCola();
					superid = msg.getId(); // Ultimo ID
					memIndexVar = msg.getMemIndex(); // Ultimo MemIndex
				}
			}
			if (recorrido > 1 && antid < superid) {
				System.out.println("Nuevo Mensaje Recibido!!!");
			}
			smsleidos = superid - antid;
			System.out.println("InterfazHWVer3 : " + recorrido + " Lectura. SMS Leidos: " + smsleidos);
			System.out.println("InterfazHWVer3 : " + "Tama�o Cola Entrada : " + Cola1.Tama�oCola() + " Mensajes");
			if (!Cola2.EstaVacio()) {
				System.out.println("Hay Mensaje Para Enviar...!!!!");
				msgsal = Cola2.Sacar();
				int x = srv.sendMessage(msgsal);
				if (x == CService.ERR_OK) {
					System.out.println("InterfazHWVer3 : Envio Mensaje SMS a la red GSM");
					System.out.println("InterfazHWVer3 : Tama�o Cola Salida : " + Cola2.Tama�oCola());
					smsenviados++;
				}
				else { System.out.println("Se produjo un error con el tama�o del mensaje a enviar: Valor X: " + x); }
			}
			superid++;
			Date Fecha = new Date();
			String De = "IH";
			String Info = "Informaci�n Del Estado De La Interfaz";
//			int superidp = superid;
			CProtocolMessage A1 = new CProtocolMessage(Fecha, De, Info, 0, superid, recorrido, smsleidos, smsenviados, srv.getDeviceInfo().getSignalLevel(), srv.getDeviceInfo().getBatteryLevel()
			,Conexion);
			Cola1.Agregar(A1);
			System.out.println("InterfazHWVer3 : Envio Mensaje Protocolo a la Cola de Entrada");
			System.out.println("InterfazHWVer3 : " + "Tama�o Cola Entrada : " + Cola1.Tama�oCola() + " Mensajes");				
			System.out.println("InterfazHWVer3 : Duermo InterfazHW " + Tiempo + " Segundos...");
			System.out.println("/------------------------------------/");
			msg = Cola1.UltimoCola();
			antid = msg.getId();
			try { sleep(Tiempo*1000); } catch (Exception e) {}
			recorrido++;
		}
		if (recorrido == 0 && !Conexion) {
			System.out.println("No se Pudo Realizar La Conexi�n...Verifique Si El Dispositivo GSM Se Encuentra Conectado Y Si Los Datos De Configuraci�n Son Correctos");			
		}
		else {
			recorrido = 0;
			status = 0;
			msg = null;
			srv.disconnect();
			System.out.println("Finaliza Ejecuci�n Interfaz De Hardware");
		}
	}
}

